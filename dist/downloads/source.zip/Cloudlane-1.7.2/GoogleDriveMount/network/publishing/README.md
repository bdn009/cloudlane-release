# Cloudlane installer tooling

The current public release uses each user's own Google Desktop OAuth client. No publisher JSON or saved account data is required to build it. Application code is MIT licensed; preserve the LGPL library notices and corresponding source.

## Build

For the complete development workspace, run `python build-production.py` at the repository root, followed by `python publish-release.py`. See PRODUCTION.md. It stages a versioned release without replacing the existing test app. For the clean source ZIP, run its root Build.ps1 with .NET SDK 10 and Python 3.11+ installed.

The source ZIP includes app/shared code, vendored libraries, checks, licenses and installer scripts. Its app project has no OAuth embedding hook. The installer includes compiled app/runtime, README help and the LGPL libraries' corresponding source; the complete app source is downloaded separately from the website.

The scripts prepare-payload.py, build-msi.py and verify-msi.py run from this network project. Their version is fixed to the matching release, and they expect publish/check logs under work/. Build.ps1 creates those logs. Windows makecab.exe and msi.dll supply the native installer tools; no paid toolkit is required.

The MSI uses a per-user transaction with shortcuts, repair, upgrade and uninstall. A release refuses to overwrite an existing MSI. Production uses its own installer family and Cloudlane Production install/menu folder, separate from the older test app. Uninstall retains local client configuration, tokens, settings, pending uploads and media cache. It only removes its own app files and owned startup registration.

## Compatibility verification

The actual 64-bit CurrentBuildNumber registry value is searched before launch conditions, avoiding the compatibility WindowsBuild value reported by some legacy installer hosts. The empty Signature table is required for AppSearch's raw registry search. Native probes exercise the registry search and eight OS/maintenance conditions without running installation actions. The minimum remains Windows 11 24H2, build 26100+, x64; no earlier-Windows fallback or driver is added.

Validation checks MSI tables, UI references, component ownership, downgrade/uninstall guards, exact cabinet hashes and corresponding LGPL source. Application tests simulate Google HTTP and exercise signed loopback SMB and WPF UI. The restricted production profile explicitly skips the device namespace and DPAPI checks. This does not establish live Google authorization, full installation/uninstallation, or Windows-startup mapping; verify those from a normal user session. This build is unsigned.

Follow ../SETUP.md for user-owned Google setup. Google test-user, authorization-expiry, organization, quota and verification rules apply to each user's project.
