from pathlib import Path
import hashlib
import json
import subprocess
import uuid
from msi_api import Database, Stream

root = Path(__file__).resolve().parents[1]
version = '1.7.2'
release = root / ('release/Cloudlane-Explorer-' + version)
work = root / ('work/msi-' + version)
out = root.parents[1] / 'outputs'
work.mkdir(parents=True, exist_ok=True)
out.mkdir(exist_ok=True)
destination = out / ('Cloudlane-' + version + '-Setup.msi')
assert not destination.exists(), 'Use a fresh package path; do not overwrite a published MSI.'
database_path = work / ('build-' + uuid.uuid4().hex + '.msi')
files = sorted(p for p in release.rglob('*') if p.is_file() and p.suffix != '.pdb')
for path in files:
    relative = path.relative_to(release)
    assert not any(part.lower() in ('src', 'shared', 'tests', 'data-direct', 'cloudlanestreamingcache-v1') for part in relative.parts), relative
    assert path.suffix.lower() not in ('.cs', '.xaml', '.csproj', '.bin', '.block'), relative
assert (release / 'ThirdParty/SMBLibrary-corresponding-source.zip').is_file()
namespace = uuid.UUID('29790724-7cd1-563a-aaf7-9890e220b24c')
def guid(name): return '{' + str(uuid.uuid5(namespace, name)).upper() + '}'
def key(prefix, name): return prefix + hashlib.sha256(name.encode()).hexdigest()[:24]

rows = []
for index, path in enumerate(files, 1):
    relative = path.relative_to(release).as_posix()
    rows.append({'key': key('F', relative), 'component': key('C', relative), 'path': relative,
                 'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'sequence': index})
ddf = ['.OPTION EXPLICIT', '.Set Cabinet=on', '.Set Compress=on', '.Set CompressionType=MSZIP',
       '.Set MaxDiskSize=0', '.Set MaxCabinetSize=0', '.Set CabinetNameTemplate=cloudlane.cab',
       '.Set DiskDirectoryTemplate="' + str(work) + '"', '.Set InfFileName="' + str(work / 'cabinet.inf') + '"',
       '.Set RptFileName="' + str(work / 'cabinet.rpt') + '"']
ddf += ['"' + str(release / row['path']) + '" ' + row['key'] for row in rows]
ddf_text = '\n'.join(ddf)
cabinet_signature = hashlib.sha256(json.dumps(rows, sort_keys=True).encode()).hexdigest()
reuse_cabinet = (work / 'files.ddf').exists() and (work / 'files.ddf').read_text() == ddf_text and (work / 'cloudlane.cab').exists() and (work / 'cabinet-signature.txt').exists() and (work / 'cabinet-signature.txt').read_text() == cabinet_signature
(work / 'files.ddf').write_text(ddf_text, encoding='ascii')
if not reuse_cabinet:
    with (work / 'makecab.log').open('w') as log:
        subprocess.run(['C:\\Windows\\System32\\makecab.exe', '/F', str(work / 'files.ddf')], stdout=log, stderr=subprocess.STDOUT, check=True)
    (work / 'cabinet-signature.txt').write_text(cabinet_signature)
print('Cabinet built for ' + str(len(rows)) + ' compiled app/runtime/license files.', flush=True)

schemas = {
 'Signature': '`Signature` CHAR(72) NOT NULL, `FileName` CHAR(255) NOT NULL, `MinVersion` CHAR(20), `MaxVersion` CHAR(20), `MinSize` LONG, `MaxSize` LONG, `MinDate` LONG, `MaxDate` LONG, `Languages` CHAR(255) PRIMARY KEY `Signature`',
 'AppSearch': '`Property` CHAR(72) NOT NULL, `Signature_` CHAR(72) NOT NULL PRIMARY KEY `Property`, `Signature_`',
 'RegLocator': '`Signature_` CHAR(72) NOT NULL, `Root` SHORT NOT NULL, `Key` CHAR(255) NOT NULL, `Name` CHAR(255), `Type` SHORT PRIMARY KEY `Signature_`',
 'Property': '`Property` CHAR(72) NOT NULL, `Value` CHAR(0) LOCALIZABLE NOT NULL PRIMARY KEY `Property`',
 'Directory': '`Directory` CHAR(72) NOT NULL, `Directory_Parent` CHAR(72), `DefaultDir` CHAR(255) LOCALIZABLE NOT NULL PRIMARY KEY `Directory`',
 'Component': '`Component` CHAR(72) NOT NULL, `ComponentId` CHAR(38), `Directory_` CHAR(72) NOT NULL, `Attributes` SHORT NOT NULL, `Condition` CHAR(255), `KeyPath` CHAR(72) PRIMARY KEY `Component`',
 'Feature': '`Feature` CHAR(38) NOT NULL, `Feature_Parent` CHAR(38), `Title` CHAR(64) LOCALIZABLE, `Description` CHAR(255) LOCALIZABLE, `Display` SHORT, `Level` SHORT NOT NULL, `Directory_` CHAR(72), `Attributes` SHORT NOT NULL PRIMARY KEY `Feature`',
 'FeatureComponents': '`Feature_` CHAR(38) NOT NULL, `Component_` CHAR(72) NOT NULL PRIMARY KEY `Feature_`, `Component_`',
 'File': '`File` CHAR(72) NOT NULL, `Component_` CHAR(72) NOT NULL, `FileName` CHAR(255) LOCALIZABLE NOT NULL, `FileSize` LONG NOT NULL, `Version` CHAR(72), `Language` CHAR(20), `Attributes` SHORT, `Sequence` LONG NOT NULL PRIMARY KEY `File`',
 'Media': '`DiskId` SHORT NOT NULL, `LastSequence` LONG NOT NULL, `DiskPrompt` CHAR(64) LOCALIZABLE, `Cabinet` CHAR(255), `VolumeLabel` CHAR(32), `Source` CHAR(72) PRIMARY KEY `DiskId`',
 'Registry': '`Registry` CHAR(72) NOT NULL, `Root` SHORT NOT NULL, `Key` CHAR(255) NOT NULL, `Name` CHAR(255) LOCALIZABLE, `Value` CHAR(0) LOCALIZABLE, `Component_` CHAR(72) NOT NULL PRIMARY KEY `Registry`',
 'Shortcut': '`Shortcut` CHAR(72) NOT NULL, `Directory_` CHAR(72) NOT NULL, `Name` CHAR(128) LOCALIZABLE NOT NULL, `Component_` CHAR(72) NOT NULL, `Target` CHAR(255), `Arguments` CHAR(255), `Description` CHAR(255) LOCALIZABLE, `Hotkey` SHORT, `Icon_` CHAR(72), `IconIndex` SHORT, `ShowCmd` SHORT, `WkDir` CHAR(72), `DisplayResourceDLL` CHAR(255), `DisplayResourceId` SHORT, `DescriptionResourceDLL` CHAR(255), `DescriptionResourceId` SHORT PRIMARY KEY `Shortcut`',
 'Icon': '`Name` CHAR(72) NOT NULL, `Data` OBJECT NOT NULL PRIMARY KEY `Name`',
 'RemoveFile': '`FileKey` CHAR(72) NOT NULL, `Component_` CHAR(72) NOT NULL, `FileName` CHAR(255) LOCALIZABLE, `DirProperty` CHAR(72) NOT NULL, `InstallMode` SHORT NOT NULL PRIMARY KEY `FileKey`',
 'Upgrade': '`UpgradeCode` CHAR(38) NOT NULL, `VersionMin` CHAR(20), `VersionMax` CHAR(20), `Language` CHAR(255), `Attributes` LONG NOT NULL, `Remove` CHAR(255), `ActionProperty` CHAR(72) NOT NULL PRIMARY KEY `UpgradeCode`, `VersionMin`, `VersionMax`, `Language`, `Attributes`',
 'LaunchCondition': '`Condition` CHAR(255) NOT NULL, `Description` CHAR(255) LOCALIZABLE NOT NULL PRIMARY KEY `Condition`',
 'CustomAction': '`Action` CHAR(72) NOT NULL, `Type` SHORT NOT NULL, `Source` CHAR(72), `Target` CHAR(255) PRIMARY KEY `Action`',
 'InstallExecuteSequence': '`Action` CHAR(72) NOT NULL, `Condition` CHAR(255), `Sequence` SHORT PRIMARY KEY `Action`',
 'InstallUISequence': '`Action` CHAR(72) NOT NULL, `Condition` CHAR(255), `Sequence` SHORT PRIMARY KEY `Action`',
 'AdminExecuteSequence': '`Action` CHAR(72) NOT NULL, `Condition` CHAR(255), `Sequence` SHORT PRIMARY KEY `Action`',
 'AdminUISequence': '`Action` CHAR(72) NOT NULL, `Condition` CHAR(255), `Sequence` SHORT PRIMARY KEY `Action`',
 'Dialog': '`Dialog` CHAR(72) NOT NULL, `HCentering` SHORT NOT NULL, `VCentering` SHORT NOT NULL, `Width` SHORT NOT NULL, `Height` SHORT NOT NULL, `Attributes` LONG, `Title` CHAR(128) LOCALIZABLE, `Control_First` CHAR(50), `Control_Default` CHAR(50), `Control_Cancel` CHAR(50) PRIMARY KEY `Dialog`',
 'Control': '`Dialog_` CHAR(72) NOT NULL, `Control` CHAR(50) NOT NULL, `Type` CHAR(20) NOT NULL, `X` SHORT NOT NULL, `Y` SHORT NOT NULL, `Width` SHORT NOT NULL, `Height` SHORT NOT NULL, `Attributes` LONG, `Property` CHAR(72), `Text` CHAR(0) LOCALIZABLE, `Control_Next` CHAR(50), `Help` CHAR(50) LOCALIZABLE PRIMARY KEY `Dialog_`, `Control`',
 'ControlEvent': '`Dialog_` CHAR(72) NOT NULL, `Control_` CHAR(50) NOT NULL, `Event` CHAR(50) NOT NULL, `Argument` CHAR(255) NOT NULL, `Condition` CHAR(255), `Ordering` SHORT PRIMARY KEY `Dialog_`, `Control_`, `Event`, `Argument`, `Condition`',
 'EventMapping': '`Dialog_` CHAR(72) NOT NULL, `Control_` CHAR(50) NOT NULL, `Event` CHAR(50) NOT NULL, `Attribute` CHAR(50) NOT NULL PRIMARY KEY `Dialog_`, `Control_`, `Event`',
 'TextStyle': '`TextStyle` CHAR(72) NOT NULL, `FaceName` CHAR(32) NOT NULL, `Size` SHORT NOT NULL, `Color` LONG, `StyleBits` SHORT PRIMARY KEY `TextStyle`',
}
with Database(database_path, create=True) as db:
    for table, schema in schemas.items(): db.sql('CREATE TABLE `' + table + '` (' + schema.replace('LOCALIZABLE NOT NULL', 'NOT NULL LOCALIZABLE') + ')')
    # AppSearch requires the empty Signature table for a raw registry search.
    db.sql('ALTER TABLE `Signature` HOLD')
    props = {'ProductCode': guid('product-' + version), 'ProductName': 'Cloudlane', 'ProductVersion': version,
             'ProductLanguage': '1033', 'Manufacturer': 'Cloudlane', 'UpgradeCode': guid('upgrade'),
             'INSTALLLEVEL': '1', 'ARPNOMODIFY': '1', 'ARPPRODUCTICON': 'CloudlaneIcon',
             'SecureCustomProperties': 'OLDPRODUCTS;NEWERPRODUCTS;CLOUDLANE_OS_BUILD', 'DefaultUIFont': 'NormalFont',
             'REBOOT': 'ReallySuppress', 'MSIFASTINSTALL': '7'}
    for name, value in props.items(): db.insert('Property', (name, value))
    directories = {'.': 'INSTALLDIR'}
    for data in [('TARGETDIR', None, 'SourceDir'), ('LocalAppDataFolder', 'TARGETDIR', '.'), ('ProgramsRoot', 'LocalAppDataFolder', 'Programs'),
                 ('INSTALLDIR', 'ProgramsRoot', 'Cloudlane Production'), ('ProgramMenuFolder', 'TARGETDIR', '.'), ('CloudlaneMenu', 'ProgramMenuFolder', 'Cloudlane Production'), ('DesktopFolder', 'TARGETDIR', '.')]:
        db.insert('Directory', data)
    for row in rows:
        parent = Path(row['path']).parent
        for part in reversed([parent] + list(parent.parents)):
            value = part.as_posix()
            if value in directories: continue
            identifier = key('D', value); directories[value] = identifier
            short = 'D' + hashlib.sha256(value.encode()).hexdigest()[:7].upper()
            db.insert('Directory', (identifier, directories[part.parent.as_posix()], short + '|' + part.name))
    db.insert('Feature', ('App', None, 'Cloudlane', 'Google Drive in Windows Explorer', 1, 1, 'INSTALLDIR', 0))
    for row in rows:
        parent = Path(row['path']).parent.as_posix()
        db.insert('Component', (row['component'], guid('component/' + row['path']), directories[parent], 256, None, row['key']))
        db.insert('FeatureComponents', ('App', row['component']))
        short = 'F' + str(row['sequence']).zfill(6) + '.DAT'
        db.insert('File', (row['key'], row['component'], short + '|' + Path(row['path']).name, row['bytes'], None, None, 16384, row['sequence']))
    exe = next(row['key'] for row in rows if row['path'] == 'Cloudlane.exe')
    db.insert('Media', (1, len(rows), None, '#cloudlane.cab', None, None))
    db.insert('_Streams', ('cloudlane.cab', Stream(work / 'cloudlane.cab')))
    db.insert('Icon', ('CloudlaneIcon', Stream(root / 'src/Cloudlane/Assets/Cloudlane.ico')))
    db.insert('Component', ('Shortcuts', guid('shortcuts'), 'CloudlaneMenu', 260, None, 'InstalledMarker'))
    db.insert('FeatureComponents', ('App', 'Shortcuts'))
    db.insert('Registry', ('InstalledMarker', 1, 'Software\\Cloudlane\\Production\\Installer', 'Installed', '#1', 'Shortcuts'))
    for name, directory, label, target in [('StartMenu', 'CloudlaneMenu', 'Cloudlane Production', '[#' + exe + ']'), ('Desktop', 'DesktopFolder', 'Cloudlane Production', '[#' + exe + ']')]:
        db.insert('Shortcut', (name, directory, label, 'Shortcuts', target, None, 'Google Drive in Windows Explorer', None, 'CloudlaneIcon', 0, 1, 'INSTALLDIR', None, None, None, None))
    db.insert('RemoveFile', ('RemoveMenu', 'Shortcuts', None, 'CloudlaneMenu', 2))
    db.insert('Upgrade', (guid('upgrade'), None, version, None, 1, None, 'OLDPRODUCTS'))
    db.insert('Upgrade', (guid('upgrade'), version, None, None, 2, None, 'NEWERPRODUCTS'))
    # Windows Installer can expose compatibility-version values. Read the actual
    # build from the 64-bit Windows registry before evaluating LaunchConditions.
    db.insert('RegLocator', ('RealWindowsBuild', 2, 'SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion', 'CurrentBuildNumber', 18))
    db.insert('AppSearch', ('CLOUDLANE_OS_BUILD', 'RealWindowsBuild'))
    db.insert('LaunchCondition', ('Installed OR (VersionNT64 AND CLOUDLANE_OS_BUILD >= 26100)', 'Cloudlane requires Windows 11 24H2 or newer (build 26100+) on an x64 PC.'))
    db.insert('LaunchCondition', ('NOT ALLUSERS', 'Install Cloudlane for your current Windows user.'))
    db.insert('LaunchCondition', ('Installed OR NOT NEWERPRODUCTS', 'A newer Cloudlane version is already installed.'))
    db.insert('CustomAction', ('RemoveOwnedStartup', 18, exe, '--remove-owned-startup'))
    db.insert('CustomAction', ('SetInstallLocation', 51, 'ARPINSTALLLOCATION', '[INSTALLDIR]'))
    # Standard MSI actions provide rollback, repair and registered uninstallation.
    actions = [('FindRelatedProducts', 25), ('AppSearch', 50), ('LaunchConditions', 100), ('ValidateProductID', 700), ('CostInitialize', 800), ('FileCost', 900), ('CostFinalize', 1000),
               ('MigrateFeatureStates', 1200), ('InstallValidate', 1400), ('InstallInitialize', 1500), ('RemoveExistingProducts', 1510), ('ProcessComponents', 1600),
               ('UnpublishFeatures', 1800), ('RemoveRegistryValues', 2600), ('RemoveShortcuts', 3200), ('RemoveFiles', 3500), ('RemoveFolders', 3600),
               ('CreateFolders', 3700), ('InstallFiles', 4000), ('CreateShortcuts', 4500), ('WriteRegistryValues', 5000), ('RegisterUser', 6000),
               ('RegisterProduct', 6100), ('PublishFeatures', 6300), ('PublishProduct', 6400), ('InstallFinalize', 6600)]
    for action, sequence in actions: db.insert('InstallExecuteSequence', (action, None, sequence))
    db.insert('InstallExecuteSequence', ('SetInstallLocation', None, 1100))
    db.insert('InstallExecuteSequence', ('RemoveOwnedStartup', 'REMOVE="ALL" AND NOT UPGRADINGPRODUCTCODE', 3450))
    for action, sequence in [('FindRelatedProducts', 25), ('AppSearch', 50), ('LaunchConditions', 100), ('ValidateProductID', 700), ('CostInitialize', 800), ('FileCost', 900), ('CostFinalize', 1000), ('MigrateFeatureStates', 1200), ('ExecuteAction', 1300)]:
        db.insert('InstallUISequence', (action, None, sequence))
    db.insert('InstallUISequence', ('WelcomeDlg', 'NOT Installed', 1100))
    db.insert('InstallUISequence', ('ProgressDlg', None, 1250))
    db.insert('InstallUISequence', ('FinishedDlg', None, -1))
    for action, sequence in [('CostInitialize', 800), ('FileCost', 900), ('CostFinalize', 1000), ('InstallValidate', 1400), ('InstallInitialize', 1500), ('InstallAdminPackage', 3900), ('InstallFiles', 4000), ('InstallFinalize', 6600)]:
        db.insert('AdminExecuteSequence', (action, None, sequence))
    db.insert('AdminUISequence', ('ExecuteAction', None, 1300))
    db.insert('TextStyle', ('NormalFont', 'Segoe UI', 9, 0, 0))
    db.insert('TextStyle', ('TitleFont', 'Segoe UI', 15, 0, 1))
    for dialog, modal, button, title, text in [
        ('WelcomeDlg', 3, 'Install', 'Install Cloudlane', 'Install Cloudlane for your Windows account.\n\nAfter installation, open Cloudlane and click Sign in with Google. Your Google files stay in your own account.\n\nExit any running Cloudlane copy before continuing.'),
        ('ProgressDlg', 1, 'Cancel', 'Cloudlane Setup', 'Please wait while Windows installs or removes Cloudlane.'),
        ('FinishedDlg', 3, 'Finish', 'Cloudlane setup completed', 'You can open Cloudlane from the Start menu or desktop.\n\nAfter removal, your local sign-in/settings and cache are retained. Your Google Drive files are unchanged.')]:
        db.insert('Dialog', (dialog, 50, 50, 370, 245, modal, '[ProductName] Setup', button, button, 'Cancel' if dialog != 'FinishedDlg' else 'Finish'))
        db.insert('Control', (dialog, 'Title', 'Text', 20, 18, 330, 30, 3, None, '{\\TitleFont}' + title, None, None))
        db.insert('Control', (dialog, 'Body', 'Text', 20, 58, 330, 125, 3, None, text, None, None))
        db.insert('Control', (dialog, button, 'PushButton', 280, 215, 70, 18, 3, None, button, 'Cancel' if button == 'Install' else button, None))
        db.insert('ControlEvent', (dialog, button, 'EndDialog', 'Exit' if button == 'Cancel' else 'Return', '1', 1))
        if dialog == 'WelcomeDlg':
            db.insert('Control', (dialog, 'Cancel', 'PushButton', 200, 215, 70, 18, 3, None, 'Cancel', 'Install', None))
            db.insert('ControlEvent', (dialog, 'Cancel', 'EndDialog', 'Exit', '1', 1))
    db.insert('Control', ('ProgressDlg', 'Progress', 'ProgressBar', 20, 175, 330, 15, 3, None, None, None, None))
    db.insert('EventMapping', ('ProgressDlg', 'Progress', 'SetProgress', 'Progress'))
    db.summary({2: 'Cloudlane Setup', 3: 'Google Drive in Windows Explorer', 4: 'Cloudlane', 7: 'x64;1033', 9: '{' + str(uuid.uuid4()).upper() + '}', 14: 500, 15: 10, 18: 'Cloudlane native MSI builder'})
    db.commit()
(work / 'payload-manifest.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
import shutil
shutil.copy2(database_path, destination)
print('Created ' + str(destination), flush=True)
