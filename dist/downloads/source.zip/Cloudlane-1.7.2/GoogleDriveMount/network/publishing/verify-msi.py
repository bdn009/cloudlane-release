from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import zipfile
from msi_api import Database

root = Path(__file__).resolve().parents[1]
package = root.parents[1] / 'outputs/Cloudlane-1.7.2-Setup.msi'
work = root / 'work/msi-1.7.2'
manifest = json.loads((work / 'payload-manifest.json').read_text())
checks = []
def check(ok, name):
    assert ok, name
    checks.append(name)
    print('PASS ' + name, flush=True)

with Database(package) as db:
    properties = dict(db.sql('SELECT `Property`,`Value` FROM `Property`'))
    check(properties['ProductVersion'] == '1.7.2' and properties['ProductName'] == 'Cloudlane', 'MSI product identity and version')
    check('ALLUSERS' not in properties, 'per-user installation without a forced machine-wide context')
    conditions = dict(db.sql('SELECT `Condition`,`Description` FROM `LaunchCondition`'))
    check('Installed OR (VersionNT64 AND CLOUDLANE_OS_BUILD >= 26100)' in conditions, 'Windows x64/build requirement uses the real OS build')
    check(db.sql('SELECT `Property`,`Signature_` FROM `AppSearch`') == [['CLOUDLANE_OS_BUILD', 'RealWindowsBuild']] and
          db.sql('SELECT `Signature` FROM `Signature`') == [] and
          db.sql('SELECT `Signature_`,`Root`,`Key`,`Name`,`Type` FROM `RegLocator`') ==
          [['RealWindowsBuild', '2', 'SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion', 'CurrentBuildNumber', '18']] and
          'CLOUDLANE_OS_BUILD' in properties['SecureCustomProperties'].split(';'),
          'real build search reads the 64-bit registry and is carried to the execute sequence')
    for sequence in ('InstallUISequence', 'InstallExecuteSequence'):
        actions = {row[0]: int(row[1]) for row in db.sql('SELECT `Action`,`Sequence` FROM `' + sequence + '`')}
        assert 0 < actions['AppSearch'] < actions['LaunchConditions']
    check(True, 'registry OS detection runs before launch conditions in UI and silent installs')
    check('Installed OR NOT NEWERPRODUCTS' in conditions, 'downgrade detection is authored')
    files = db.sql('SELECT `File`,`Component_`,`FileName`,`FileSize`,`Attributes`,`Sequence` FROM `File`')
    check(len(files) == len(manifest), 'every manifest payload has one MSI file entry')
    expected = {row['key']: row for row in manifest}
    for identifier, component, filename, size, attributes, sequence in files:
        row = expected[identifier]
        assert component == row['component'] and filename.split('|')[-1] == Path(row['path']).name
        assert int(size) == row['bytes'] and int(sequence) == row['sequence'] and int(attributes) & 16384
    check(True, 'MSI file sizes, component ownership, names, compression and cabinet sequence match the payload')
    components = {row[0]: row[1:] for row in db.sql('SELECT `Component`,`Directory_`,`Attributes`,`KeyPath` FROM `Component`')}
    directories = {row[0]: row[1:] for row in db.sql('SELECT `Directory`,`Directory_Parent`,`DefaultDir` FROM `Directory`')}
    file_keys = set(expected)
    registry = {row[0]: row for row in db.sql('SELECT `Registry`,`Root`,`Key`,`Name`,`Value`,`Component_` FROM `Registry`')}
    for component, (directory, attributes, key_path) in components.items():
        assert directory in directories
        assert key_path in (registry if int(attributes) & 4 else file_keys)
    check(True, 'all component directories and file/registry key paths resolve')
    feature_links = db.sql('SELECT `Feature_`,`Component_` FROM `FeatureComponents`')
    check({row[1] for row in feature_links} == set(components) and all(row[0] == 'App' for row in feature_links), 'all components belong to the installed feature')
    shortcuts = db.sql('SELECT `Shortcut`,`Directory_`,`Component_`,`Target`,`Icon_` FROM `Shortcut`')
    check({row[0] for row in shortcuts} == {'StartMenu', 'Desktop'} and all(row[2] in components and row[3].startswith('[#F') for row in shortcuts), 'Start menu and desktop shortcuts target the compiled application')
    controls = db.sql('SELECT `Dialog_`,`Control` FROM `Control`')
    control_keys = {(row[0], row[1]) for row in controls}
    for dialog, first, default, cancel in db.sql('SELECT `Dialog`,`Control_First`,`Control_Default`,`Control_Cancel` FROM `Dialog`'):
        assert all((dialog, name) in control_keys for name in (first, default, cancel))
    for dialog, control in db.sql('SELECT `Dialog_`,`Control_` FROM `ControlEvent`'):
        assert (dialog, control) in control_keys
    check(True, 'setup welcome/progress/finished dialogs have valid controls and events')
    actions = {row[0]: row[1:] for row in db.sql('SELECT `Action`,`Condition`,`Sequence` FROM `InstallExecuteSequence`')}
    check(int(actions['InstallInitialize'][1]) < int(actions['InstallFiles'][1]) < int(actions['InstallFinalize'][1]), 'file installation occurs inside the native MSI transaction')
    check(actions['RemoveOwnedStartup'][0] == 'REMOVE="ALL" AND NOT UPGRADINGPRODUCTCODE' and int(actions['RemoveOwnedStartup'][1]) < int(actions['RemoveFiles'][1]), 'uninstall-only owned startup cleanup runs before application file removal')
    check(all(Path(row['path']).parts[0].lower() != 'data-direct' for row in manifest) and not db.sql('SELECT `FileName` FROM `RemoveFile` WHERE `FileName` IS NOT NULL'), 'user data is not packaged or targeted by wildcard removal')
    check(all(not row['path'].endswith(('.cs', '.xaml', '.csproj', '.pdb', '.bin', '.block')) for row in manifest), 'Cloudlane application source, symbols, tokens and cache files are excluded')
    admin = {row[0] for row in db.sql('SELECT `Action` FROM `AdminExecuteSequence`')}
    check(not admin.intersection({'RegisterProduct', 'ProcessComponents', 'WriteRegistryValues', 'CreateShortcuts'}), 'administrative extraction sequence does not register a product or shortcuts')
    extraction = work / 'verified-cabinet'
    extraction.mkdir(exist_ok=True)
    cabinet = work / 'verified-payload.cab'
    db.extract_stream('cloudlane.cab', cabinet)

subprocess.run(['C:\\Windows\\System32\\expand.exe', '-F:*', str(cabinet), str(extraction)], stdout=subprocess.DEVNULL, check=True)
for row in manifest:
    extracted = extraction / row['key']
    assert extracted.stat().st_size == row['bytes']
    assert hashlib.sha256(extracted.read_bytes()).hexdigest() == row['sha256']
check(True, 'every file extracted from the MSI cabinet matches the SHA-256 payload manifest')
library = next(row for row in manifest if row['path'] == 'ThirdParty/SMBLibrary-corresponding-source.zip')
with zipfile.ZipFile(extraction / library['key']) as archive:
    check(archive.testzip() is None and any(name.startswith('SMBLibrary/') for name in archive.namelist()) and any(name.startswith('Utilities/') for name in archive.namelist()), 'complete corresponding library source archive is intact')
    check(not any(name.startswith(('src/', 'shared/', 'tests/')) or Path(name).name in ('Settings.cs', 'GoogleAuth.cs', 'MainWindow.xaml.cs', 'BundledGoogleClient.cs') for name in archive.namelist()), 'third-party source archive contains no Cloudlane application source')
probe = subprocess.run([sys.executable, str(root / 'publishing/check-os-detection.py'), str(package)], check=True, capture_output=True, text=True)
os_detection = json.loads(probe.stdout)
check(os_detection['scenarios_passed'] == 8 and not os_detection['installation_actions_run'], 'native MSI AppSearch reads the actual build; compatibility, older Windows and maintenance scenarios pass')
logs = [(root / ('work/' + name)).read_text(encoding='utf-8-sig') for name in ('checks-1.7.2.txt', 'publish-1.7.2.txt')]
suite = re.search(r'(\d+) checks passed\.', logs[0])
check(suite and int(suite[1]) >= 353 and not any(re.search(r'Unhandled exception|error (?:CS|NETSDK)\d|warning [A-Z]+\d|Build failed|build failed', log) for log in logs), 'application regression suite and release build pass without warnings/errors')
report = {'version': '1.7.2', 'application_checks_passed': int(suite[1]), 'installer_checks_passed': len(checks), 'installer_checks': checks,
          'msi': str(package), 'bytes': package.stat().st_size, 'sha256': hashlib.sha256(package.read_bytes()).hexdigest(),
          'google_sign_in': 'Each user imports their own Desktop OAuth client JSON before sign-in. No publisher registration or user tokens are bundled. Google policies apply to the user-owned project.',
          'privacy': 'Cloudlane is MIT licensed with a separate source download. The installer includes corresponding LGPL library source and notices. No runtime account data is packaged.',
          'limitations': 'Native install/uninstall UI, live Google sign-in and a mapped drive need user-session verification. Windows DPAPI is explicitly skipped in this restricted build profile. Cabinet extraction and MSI structure were verified without installing the app in the build account.'}
report['native_administrative_extraction'] = 'Attempted in a project-local staging directory. Windows Installer could not write C:\\Windows\\Installer\\inprogressinstallinfo.ipi (access denied), then returned 1603/2503. No product registration or shortcuts were requested by that administrative action sequence. Full installation remains unverified in this restricted execution profile.'
report['os_detection'] = os_detection
(package.parent / 'Cloudlane-1.7.2-installer-validation.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps({key: report[key] for key in ('application_checks_passed', 'installer_checks_passed', 'bytes', 'sha256')}, indent=2))
