from pathlib import Path
import html
import shutil
import zipfile

root = Path(__file__).resolve().parents[1]
release = root / 'release/Cloudlane-Explorer-1.7.2'
assert (release / 'Cloudlane.exe').is_file()
for name in ['LICENSE', 'THIRD-PARTY-NOTICES.md']:
    shutil.copy2(root / name, release / name)
shutil.copytree(root / 'licenses', release / 'licenses', dirs_exist_ok=True)
third_party = release / 'ThirdParty'
third_party.mkdir(exist_ok=True)
with zipfile.ZipFile(third_party / 'SMBLibrary-corresponding-source.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for folder in ['SMBLibrary', 'Utilities']:
        for path in (root / 'vendor' / folder).rglob('*'):
            if path.is_file() and not any(part in ('bin', 'obj') for part in path.relative_to(root / 'vendor').parts):
                archive.write(path, path.relative_to(root / 'vendor'))
    archive.write(root / 'vendor/MODIFICATIONS.md', 'MODIFICATIONS.md')
    for path in (root / 'licenses').glob('*'):
        if path.is_file(): archive.write(path, 'licenses/' + path.name)
    archive.writestr('BUILD.md', '''# SMBLibrary / Utilities corresponding source

These are the LGPL third-party libraries used by Cloudlane, including local changes. Cloudlane application source is not part of this archive.

Upstream revision and changes: see MODIFICATIONS.md. Install the .NET 10 SDK and run:

dotnet build SMBLibrary/SMBLibrary.csproj -c Release

This also builds Utilities using its relative project reference. Use the resulting compatible SMBLibrary.dll and Utilities.dll in place of the separate DLLs beside Cloudlane.exe, after exiting Cloudlane. There is no application signature check prohibiting library replacement. Preserve the libraries' API compatibility. A repair or update may restore the packaged versions. See licenses/ for LGPL/GPL terms and other notices.
''')

notices = '''# Third-party notices

Cloudlane application code is open source under the MIT License reproduced in LICENSE. The complete matching application source is a separate download from the website's Source & setup page.

Cloudlane uses SMBLibrary by Tal Aloni and contributors, with Utilities, under LGPL-3.0-or-later. Their complete corresponding source, including the modifications used by this build, is included in ThirdParty/SMBLibrary-corresponding-source.zip. See licenses/SMBLibrary-LGPL-3.0.txt and licenses/GPL-3.0.txt. Compatible replacement/rebuilt library DLLs can be used beside Cloudlane.exe; see the source archive's BUILD.md. Reverse engineering needed to debug modifications to these LGPL libraries is permitted by their license.

The package includes Microsoft .NET 10 and Windows Desktop Runtime components, with notices/licenses under licenses/. No WinFsp, rclone, external filesystem driver or paid SDK is bundled.
'''
(release / 'THIRD-PARTY-NOTICES.md').write_text(notices, encoding='utf-8')
guide = '# Cloudlane 1.7.2\n\n' + (root / 'SETUP.md').read_text(encoding='utf-8')
(release / 'README.md').write_text(guide, encoding='utf-8')
page = '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Cloudlane Help</title><style>body{font:16px/1.65 Segoe UI,sans-serif;color:#142039;max-width:850px;margin:40px auto;padding:0 24px}h2{margin-top:32px}</style>'
for line in guide.splitlines():
    if line.startswith('## '): page += '<h2>' + html.escape(line[3:]) + '</h2>'
    elif line.startswith('# '): page += '<h1>' + html.escape(line[2:]) + '</h1>'
    elif line: page += '<p>' + html.escape(line) + '</p>'
(release / 'README.html').write_text(page + '</html>', encoding='utf-8')
print('Prepared compiled app payload, user-owned OAuth setup guide and LGPL corresponding source.')
