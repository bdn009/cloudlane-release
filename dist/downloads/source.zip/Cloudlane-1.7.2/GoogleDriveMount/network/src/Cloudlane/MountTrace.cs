using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
namespace Cloudlane;
internal sealed class MountTrace
{
    private readonly Queue<string> lines = new();
    private readonly Queue<string> protocol = new();
    private readonly object gate = new();
    public void Add(string message) => Append(lines, message, 80);
    public void AddProtocol(string message) => Append(protocol, message, 120);
    private void Append(Queue<string> target, string message, int maximum)
    {
        // Vendor protocol messages quote names/paths. Omit those values from support logs.
        string safe = Regex.Replace(message, "'[^']*'", "'[omitted]'");
        if (safe.Length > 1200) safe = safe[..1200];
        lock (gate) { target.Enqueue(DateTime.UtcNow.ToString("HH:mm:ss.fff") + " UTC " + safe); while (target.Count > maximum) target.Dequeue(); }
    }
    public void Clear() { lock (gate) { lines.Clear(); protocol.Clear(); } }
    public string Text { get { lock (gate) return "Cloudlane 1.7.2 mount diagnostics\nWindows " + Environment.OSVersion.Version + "\nMount lifecycle\n" + string.Join("\n", lines) + "\nRecent SMB activity\n" + string.Join("\n", protocol); } }
    internal string OutputPath { get; set; } = Path.Combine(Settings.DataDir, "mount-diagnostics.txt");
    public void Save()
    { try { File.WriteAllText(OutputPath, Text); } catch { } }
}
