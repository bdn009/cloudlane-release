# Third-party notices

Cloudlane application code is open source under the MIT License reproduced in LICENSE. The complete matching application source is a separate download from the website's Source & setup page.

Cloudlane uses SMBLibrary by Tal Aloni and contributors, with Utilities, under LGPL-3.0-or-later. Their complete corresponding source, including the modifications used by this build, is included in ThirdParty/SMBLibrary-corresponding-source.zip. See licenses/SMBLibrary-LGPL-3.0.txt and licenses/GPL-3.0.txt. Compatible replacement/rebuilt library DLLs can be used beside Cloudlane.exe; see the source archive's BUILD.md. Reverse engineering needed to debug modifications to these LGPL libraries is permitted by their license.

The package includes Microsoft .NET 10 and Windows Desktop Runtime components, with notices/licenses under licenses/. No WinFsp, rclone, external filesystem driver or paid SDK is bundled.
