# Cloudlane 1.7.2 source

MIT-licensed Cloudlane by bdn236, with vendored LGPL SMBLibrary/Utilities and all local modifications. This is the complete application source for the matching Windows installer. No publisher OAuth registration, account data, installer binary or downloaded SDK is included.

## Build on Windows

Install .NET SDK 10 (x64) and Python 3.11 or newer. Open PowerShell in this extracted folder and run `powershell -ExecutionPolicy Bypass -File .\Build.ps1`. NuGet access is needed to restore Microsoft runtime packages. No paid tool, external driver or private publisher file is required. Use `-SkipDpapi` only in restricted environments; those Windows user-encryption checks will then be explicitly skipped. The device-namespace registration probe is skipped by this script; native mapping still needs interactive verification.

The self-contained app is written under GoogleDriveMount/network/release/Cloudlane-Explorer-1.7.2; the MSI and validation report are under outputs/. The builder refuses to overwrite an MSI; use a fresh extraction for a repeat build. The installer uses a stable Cloudlane Production family, installed beside earlier test builds. If you publish a fork, give it your own installer namespace, app identity and publisher branding.

Run the app and use Google app setup to import your own Desktop OAuth JSON. Follow GoogleDriveMount/network/SETUP.md. Windows 11 24H2+ x64 is required for mapping. This source package does not enable earlier Windows versions.

The installer remains unsigned. Tests simulate Google HTTP and do not establish live account authorization or a successful native install/uninstall. Review the emitted reports and verify those operations interactively before distributing your build.

See LICENSE, GoogleDriveMount/network/THIRD-PARTY-NOTICES.md, licenses/, and vendor/MODIFICATIONS.md for licenses and upstream modifications. The installer includes the LGPL libraries as replaceable DLLs and includes their corresponding source. Contact: support@hisabi.store.
