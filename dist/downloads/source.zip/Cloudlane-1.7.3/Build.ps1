param([switch]$SkipDpapi)
$ErrorActionPreference = 'Stop'
$projectRoot = Join-Path $PSScriptRoot 'GoogleDriveMount\network'
Push-Location $projectRoot
try {
    New-Item -ItemType Directory -Force work | Out-Null
    $version = '1.7.3'
    $checkArgs = @('run', '--project', 'tests/Cloudlane.Checks.csproj', '-c', 'Release', '--', '--skip-device-namespace', '--require-user-client')
    if ($SkipDpapi) { $checkArgs += '--skip-dpapi' }
    & dotnet @checkArgs 2>&1 | Tee-Object "work/checks-$version.txt"
    if ($LASTEXITCODE -ne 0) { throw 'Application checks failed' }
    & dotnet publish src/Cloudlane/Cloudlane.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=false -o "release/Cloudlane-Explorer-$version" 2>&1 | Tee-Object "work/publish-$version.txt"
    if ($LASTEXITCODE -ne 0) { throw 'Publish failed' }
    foreach ($step in @('prepare-payload.py', 'build-msi.py', 'verify-msi.py')) {
        & python "publishing/$step"
        if ($LASTEXITCODE -ne 0) { throw "Failed: $step" }
    }
} finally { Pop-Location }
