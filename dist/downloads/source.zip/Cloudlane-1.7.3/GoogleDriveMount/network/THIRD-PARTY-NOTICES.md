# Third-party notices

Cloudlane application source is MIT licensed.

The Explorer bridge uses SMBLibrary by Tal Aloni and contributors, with Utilities, under LGPL-3.0-or-later. See licenses/SMBLibrary-LGPL-3.0.txt and licenses/GPL-3.0.txt. Complete corresponding source, revision and modifications are included in the matching versioned Cloudlane-Explorer source ZIP under vendor/. Separate DLLs permit replacement/relinking. No WinFsp, rclone, filesystem driver or commercial SDK is bundled.

The self-contained package includes Microsoft .NET 10 and Windows Desktop Runtime code, with notices/licenses under licenses/.
