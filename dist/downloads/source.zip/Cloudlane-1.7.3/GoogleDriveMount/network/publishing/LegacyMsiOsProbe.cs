using System;
using System.Runtime.InteropServices;
using System.Text;
class Probe {
 [DllImport("msi.dll", CharSet=CharSet.Unicode)] static extern uint MsiOpenPackageEx(string path,uint flags,out uint handle);
 [DllImport("msi.dll", CharSet=CharSet.Unicode)] static extern uint MsiGetProperty(uint handle,string name,StringBuilder buffer,ref uint length);
 [DllImport("msi.dll", CharSet=CharSet.Unicode)] static extern int MsiEvaluateCondition(uint handle,string expression);
 [DllImport("msi.dll", CharSet=CharSet.Unicode)] static extern uint MsiDoAction(uint handle,string name);
 [DllImport("msi.dll")] static extern uint MsiSetInternalUI(uint level,IntPtr window);
 [DllImport("msi.dll")] static extern uint MsiCloseHandle(uint handle);
 static int Main(string[] args) {
  MsiSetInternalUI(2,IntPtr.Zero);uint handle;uint error=MsiOpenPackageEx(args[0],1,out handle);
  Console.WriteLine("OpenPackage="+error);if(error!=0)return 1;
  try {
   if(args.Length>1)Console.WriteLine("AppSearch="+MsiDoAction(handle,"AppSearch"));
   foreach(string name in new[]{"VersionNT","VersionNT64","WindowsBuild","CLOUDLANE_OS_BUILD"}) {
    uint length=1024;var buffer=new StringBuilder(1024);MsiGetProperty(handle,name,buffer,ref length);Console.WriteLine(name+"="+buffer);
   }
   Console.WriteLine("OriginalCondition="+MsiEvaluateCondition(handle,"Installed OR (VersionNT64 AND WindowsBuild >= 26100)"));
   Console.WriteLine("RegistryCondition="+MsiEvaluateCondition(handle,"Installed OR (VersionNT64 AND CLOUDLANE_OS_BUILD >= 26100)"));
  }finally{MsiCloseHandle(handle);}return 0;
 }
}
