"""Exercise MSI's real registry search/condition evaluator without installing."""
from pathlib import Path
from ctypes import wintypes as w
import ctypes as c
import json
import sys
import winreg
import os
import subprocess
from msi_api import Database

package = Path(sys.argv[1]).resolve()
with Database(package) as database:
    conditions = database.sql('SELECT `Condition` FROM `LaunchCondition`')
condition = next(row[0] for row in conditions if 'CLOUDLANE_OS_BUILD' in row[0])
# A real executable without a supported-OS manifest reproduces the compatibility
# version that caused older packages to reject valid Windows 11 installations.
compiler = Path(os.environ['WINDIR']) / 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
probe_exe = package.parent / 'legacy-os-probe.exe'
subprocess.run([str(compiler), '/nologo', '/target:exe', '/platform:x64', '/nowin32manifest',
                '/out:' + str(probe_exe), str(Path(__file__).with_name('LegacyMsiOsProbe.cs'))],
               check=True, capture_output=True, text=True)
legacy_probe = subprocess.run([str(probe_exe), str(package), 'search'], check=True, capture_output=True, text=True)
legacy_properties = dict(line.split('=', 1) for line in legacy_probe.stdout.splitlines() if '=' in line)
msi = c.WinDLL('msi')
msi.MsiSetInternalUI.argtypes = [w.UINT, c.c_void_p]
msi.MsiOpenPackageExW.argtypes = [w.LPCWSTR, w.DWORD, c.POINTER(w.UINT)]
msi.MsiGetPropertyW.argtypes = [w.UINT, w.LPCWSTR, w.LPWSTR, c.POINTER(w.DWORD)]
msi.MsiSetPropertyW.argtypes = [w.UINT, w.LPCWSTR, w.LPCWSTR]
msi.MsiDoActionW.argtypes = [w.UINT, w.LPCWSTR]
msi.MsiEvaluateConditionW.argtypes = [w.UINT, w.LPCWSTR]
msi.MsiCloseHandle.argtypes = [w.UINT]
msi.MsiSetInternalUI(2, None)
handle = w.UINT()

def require(status):
    assert status == 0, f'Windows Installer diagnostic failed: {status}'

def get(name):
    length = w.DWORD(1024); buffer = c.create_unicode_buffer(length.value)
    require(msi.MsiGetPropertyW(handle, name, buffer, c.byref(length)))
    return buffer.value

def set_value(name, value):
    require(msi.MsiSetPropertyW(handle, name, value))

require(msi.MsiOpenPackageExW(str(package), 1, c.byref(handle)))
try:
    # AppSearch only reads the declared registry locator. No install, file-copy,
    # registration, service, shortcut or transaction actions are executed.
    require(msi.MsiDoActionW(handle, 'AppSearch'))
    detected = get('CLOUDLANE_OS_BUILD')
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                        r'SOFTWARE\Microsoft\Windows NT\CurrentVersion',
                        0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as key:
        actual = str(winreg.QueryValueEx(key, 'CurrentBuildNumber')[0])
    assert detected == actual, f'MSI registry search mismatch: {detected} != {actual}'
    assert legacy_properties['CLOUDLANE_OS_BUILD'] == actual, 'Legacy installer host did not find the actual OS build'
    assert legacy_properties['RegistryCondition'] == ('1' if int(actual) >= 26100 else '0'), 'Legacy host incorrectly rejected/accepted the OS'
    legacy_build = get('WindowsBuild')
    scenarios = [
        ('22H2', '22621', '1000', '', False),
        ('23H2', '22631', '1000', '', False),
        ('24H2', '26100', '603', '', True),
        ('newer Windows', '26200', '603', '', True),
        ('missing build', '', '1000', '', False),
        ('invalid build', 'unknown', '1000', '', False),
        ('32-bit Windows', '26100', '', '', False),
        ('installed maintenance on older Windows', '22621', '1000', '1', True),
    ]
    for name, build, version64, installed, expected in scenarios:
        set_value('CLOUDLANE_OS_BUILD', build)
        set_value('VersionNT64', version64)
        set_value('Installed', installed)
        # Explicitly reproduce legacy MSI compatibility-version reporting.
        set_value('WindowsBuild', '9600')
        outcome = msi.MsiEvaluateConditionW(handle, condition)
        assert outcome == (1 if expected else 0), f'Wrong OS outcome for {name}: {outcome}'
    print(json.dumps({'real_registry_build': actual, 'detected_msi_registry_build': detected,
                      'legacy_msi_build_before_simulation': legacy_build,
                      'legacy_host': legacy_properties,
                      'scenarios_passed': len(scenarios), 'installation_actions_run': False}))
finally:
    msi.MsiCloseHandle(handle)
