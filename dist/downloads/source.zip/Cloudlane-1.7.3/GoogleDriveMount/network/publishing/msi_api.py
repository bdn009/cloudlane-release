import ctypes as c
from ctypes import wintypes as w

msi = c.WinDLL('msi')
H = w.UINT
def api(name, args, result=w.UINT):
    function = getattr(msi, name)
    function.argtypes = args
    function.restype = result
    return function
open_db = api('MsiOpenDatabaseW', [w.LPCWSTR, c.c_void_p, c.POINTER(H)])
open_view = api('MsiDatabaseOpenViewW', [H, w.LPCWSTR, c.POINTER(H)])
execute = api('MsiViewExecute', [H, H])
fetch = api('MsiViewFetch', [H, c.POINTER(H)])
close = api('MsiCloseHandle', [H])
create_record = api('MsiCreateRecord', [w.UINT], H)
set_string = api('MsiRecordSetStringW', [H, w.UINT, w.LPCWSTR])
set_integer = api('MsiRecordSetInteger', [H, w.UINT, c.c_int])
set_stream = api('MsiRecordSetStreamW', [H, w.UINT, w.LPCWSTR])
get_string = api('MsiRecordGetStringW', [H, w.UINT, w.LPWSTR, c.POINTER(w.DWORD)])
field_count = api('MsiRecordGetFieldCount', [H])
commit = api('MsiDatabaseCommit', [H])
get_summary = api('MsiGetSummaryInformationW', [H, w.LPCWSTR, w.UINT, c.POINTER(H)])
set_summary = api('MsiSummaryInfoSetPropertyW', [H, w.UINT, w.UINT, c.c_int, c.c_void_p, w.LPCWSTR])
persist_summary = api('MsiSummaryInfoPersist', [H])
read_stream = api('MsiRecordReadStream', [H, w.UINT, c.c_void_p, c.POINTER(w.DWORD)])

def check(result, operation):
    if result:
        raise RuntimeError(f'{operation}: Windows Installer error {result}')

class Stream:
    def __init__(self, path): self.path = str(path)

class Database:
    def __init__(self, path, create=False):
        self.handle = H()
        check(open_db(str(path), c.c_void_p(3 if create else 0), c.byref(self.handle)), 'Open database')
    def __enter__(self): return self
    def __exit__(self, *args): close(self.handle)
    def sql(self, statement, values=()):
        view = H()
        check(open_view(self.handle, statement, c.byref(view)), statement)
        record = create_record(len(values)) if values else 0
        try:
            for index, value in enumerate(values, 1):
                if isinstance(value, Stream): check(set_stream(record, index, value.path), 'Set stream')
                elif isinstance(value, int): check(set_integer(record, index, value), 'Set integer')
                elif value is not None: check(set_string(record, index, str(value)), 'Set string')
            check(execute(view, record), statement)
            rows = []
            if statement.lstrip().upper().startswith('SELECT'):
                while True:
                    row = H(); status = fetch(view, c.byref(row))
                    if status == 259: break
                    check(status, 'Fetch')
                    try:
                        values_out = []
                        for index in range(1, field_count(row) + 1):
                            size = w.DWORD(32768); buffer = c.create_unicode_buffer(size.value)
                            check(get_string(row, index, buffer, c.byref(size)), 'Read field')
                            values_out.append(buffer.value)
                        rows.append(values_out)
                    finally: close(row)
            return rows
        finally:
            if record: close(record)
            close(view)
    def insert(self, table, values):
        columns = [['Name'], ['Data']] if table == '_Streams' else self.sql('SELECT `Name` FROM `_Columns` WHERE `Table`=? ORDER BY `Number`', (table,))
        assert len(columns) == len(values), (table, len(columns), len(values))
        names = ','.join('`' + row[0] + '`' for row in columns)
        self.sql('INSERT INTO `' + table + '` (' + names + ') VALUES (' + ','.join('?' for _ in values) + ')', values)
    def summary(self, values):
        summary = H()
        check(get_summary(self.handle, None, 20, c.byref(summary)), 'Open summary')
        try:
            for property_id, value in values.items():
                check(set_summary(summary, property_id, 3 if isinstance(value, int) else 30, value if isinstance(value, int) else 0, None, value if isinstance(value, str) else None), 'Set summary')
            check(persist_summary(summary), 'Save summary')
        finally: close(summary)
    def commit(self): check(commit(self.handle), 'Commit')
    def extract_stream(self, name, path):
        view = H(); record = H()
        check(open_view(self.handle, 'SELECT `Data` FROM `_Streams` WHERE `Name`=?', c.byref(view)), 'Stream query')
        parameter = create_record(1)
        try:
            check(set_string(parameter, 1, name), 'Stream name')
            check(execute(view, parameter), 'Execute stream query')
            check(fetch(view, c.byref(record)), 'Fetch stream')
            with open(path, 'wb') as output:
                while True:
                    size = w.DWORD(1024 * 1024); buffer = c.create_string_buffer(size.value)
                    check(read_stream(record, 1, buffer, c.byref(size)), 'Read stream')
                    if not size.value: break
                    output.write(buffer.raw[:size.value])
        finally:
            if record: close(record)
            close(parameter); close(view)
