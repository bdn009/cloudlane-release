using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Enumeration;
using System.Linq;
using System.Threading;
using SMBLibrary;
using FA = SMBLibrary.FileAttributes;
namespace Cloudlane.Mount;
public sealed record CloudNode(string Path, string Name, string Id, bool Directory, long Size, DateTime Modified, string Version = "", byte[]? Inline = null, string MimeType = "");
public sealed record CloudCapacity(long TotalBytes, long FreeBytes);
public interface ICloudTree
{
    long TotalBytes { get; }
    long FreeBytes { get; }
    CloudCapacity Capacity => new(TotalBytes, FreeBytes);
    string VolumeLabel => "Google Drive - Cloudlane";
    CloudNode Resolve(string path);
    IReadOnlyList<CloudNode> Children(CloudNode directory);
    byte[] Read(CloudNode file, long offset, int count);
    ICloudReadSession? OpenRead(CloudNode file) => null;
    bool IsCloudOnly(CloudNode file) => false;
}
public sealed class CloudFileStore(ICloudTree tree) : INTFileStore
{
    public Action<string>? Error;
    private sealed class Handle(CloudNode node)
    {
        public CloudNode Saved = node;
        public StreamingCloudUpload? Upload;
        public bool Owner, WriteAllowed, MetadataAllowed, DeleteAllowed, DeleteOnClose, RemoteTrashed, NoRecall;
        public ShareAccess Sharing;
        public int Closed;
        public readonly object ReadGate = new();
        public ICloudReadSession? Reader;
        public CloudNode Node => Upload?.Node ?? Saved;
    }
    private readonly object createGate = new();
    private readonly HashSet<Handle> openHandles = new();
    private volatile bool stopping;
    private long noRecallReads;
    public string ReadDiagnostics => "Explicit data reads on no-recall handles allowed=" + Interlocked.Read(ref noRecallReads);
    private FA Attr(CloudNode n) => n.Directory ? FA.Directory : FA.Archive | (tree is IWritableCloudTree ? 0 : FA.ReadOnly) |
        (tree.IsCloudOnly(n) ? FA.NotContentIndexed : 0);
    private static long Allocation(CloudNode n) => n.Directory ? 0 : checked((n.Size + 4095) / 4096 * 4096);
    private NTStatus Fail(Exception e)
    {
        if (e is not FileNotFoundException && e is not DirectoryNotFoundException) Error?.Invoke(e.Message);
        return e is FileNotFoundException ? NTStatus.STATUS_OBJECT_NAME_NOT_FOUND : e is DirectoryNotFoundException ? NTStatus.STATUS_OBJECT_PATH_NOT_FOUND : e is UnauthorizedAccessException ? NTStatus.STATUS_ACCESS_DENIED : e is NotSupportedException ? NTStatus.STATUS_NOT_SUPPORTED : e is OperationCanceledException ? NTStatus.STATUS_CANCELLED : e.Message.Contains("storage is full", StringComparison.OrdinalIgnoreCase) ? NTStatus.STATUS_DISK_FULL : NTStatus.STATUS_DATA_ERROR;
    }
    public NTStatus CreateFile(out object handle, out FileStatus fileStatus, string path, AccessMask access, FA attrs, ShareAccess share, CreateDisposition disposition, CreateOptions options, SecurityContext security)
    {
        if (tree is IWritableCloudTree writable) return CreateWritable(writable, out handle, out fileStatus, path, access, attrs, share, disposition, options);
        handle = null!; fileStatus = FileStatus.FILE_DOES_NOT_EXIST;
        if (disposition != CreateDisposition.FILE_OPEN && disposition != CreateDisposition.FILE_OPEN_IF) return NTStatus.STATUS_MEDIA_WRITE_PROTECTED;
        const uint write = 0x00000002 | 0x00000004 | 0x00000010 | 0x00000100 | 0x00010000 | 0x00040000 | 0x00080000 | 0x40000000 | 0x10000000;
        if (((uint)access & write) != 0 || (options & CreateOptions.FILE_DELETE_ON_CLOSE) != 0) return NTStatus.STATUS_MEDIA_WRITE_PROTECTED;
        try
        {
            var node = tree.Resolve(path);
            if ((options & CreateOptions.FILE_DIRECTORY_FILE) != 0 && !node.Directory) return NTStatus.STATUS_NOT_A_DIRECTORY;
            if ((options & CreateOptions.FILE_NON_DIRECTORY_FILE) != 0 && node.Directory) return NTStatus.STATUS_FILE_IS_A_DIRECTORY;
            var opened = new Handle(node) { NoRecall = (options & CreateOptions.FILE_OPEN_NO_RECALL) != 0 }; handle = opened;
            lock (createGate) openHandles.Add(opened);
            fileStatus = FileStatus.FILE_OPENED; return NTStatus.STATUS_SUCCESS;
        }
        catch (Exception e) { return Fail(e); }
    }
    private NTStatus CreateWritable(IWritableCloudTree writable, out object handle, out FileStatus fileStatus, string path, AccessMask access, FA attrs, ShareAccess share, CreateDisposition disposition, CreateOptions options)
    {
        handle = null!; fileStatus = FileStatus.FILE_DOES_NOT_EXIST;
        if (stopping) return NTStatus.STATUS_NETWORK_NAME_DELETED;
        try
        {
            lock (createGate)
            {
                CloudNode? node;
                try { node = tree.Resolve(path); } catch (FileNotFoundException) { node = null; }
                bool exists = node != null;
                bool replace = disposition is CreateDisposition.FILE_SUPERSEDE or CreateDisposition.FILE_OVERWRITE or CreateDisposition.FILE_OVERWRITE_IF;
                if (exists && disposition == CreateDisposition.FILE_CREATE) return NTStatus.STATUS_OBJECT_NAME_COLLISION;
                if (!exists && disposition is CreateDisposition.FILE_OPEN or CreateDisposition.FILE_OVERWRITE) return NTStatus.STATUS_OBJECT_NAME_NOT_FOUND;
                bool directory = (options & CreateOptions.FILE_DIRECTORY_FILE) != 0 || (attrs & FA.Directory) != 0;
                bool dataWrite = ((uint)access & (0x2u | 0x4u | 0x40000000u | 0x10000000u)) != 0;
                bool metadataWrite = ((uint)access & (0x100u | 0x40000000u | 0x10000000u)) != 0;
                bool deleteAllowed = ((uint)access & (0x10000u | 0x10000000u)) != 0;
                if (exists && directory && !node!.Directory) return NTStatus.STATUS_NOT_A_DIRECTORY;
                if (exists && node!.Directory && (options & CreateOptions.FILE_NON_DIRECTORY_FILE) != 0) return NTStatus.STATUS_FILE_IS_A_DIRECTORY;
                if (exists && node!.Directory && replace) return NTStatus.STATUS_FILE_IS_A_DIRECTORY;
                StreamingCloudUpload? upload = writable.PendingUpload(path); bool owner = false;
                if ((options & CreateOptions.FILE_DELETE_ON_CLOSE) != 0 && (!deleteAllowed || path.Trim('\\').Length == 0)) return NTStatus.STATUS_ACCESS_DENIED;
                if (node != null && deleteAllowed && openHandles.Any(h => h.Node.Id == node.Id && Volatile.Read(ref h.Closed) == 0 && (h.Sharing & ShareAccess.Delete) == 0)) return NTStatus.STATUS_SHARING_VIOLATION;
                if (node?.Directory != true && !directory)
                {
                    if (upload != null && (dataWrite || replace)) return NTStatus.STATUS_SHARING_VIOLATION;
                    if (!exists || replace)
                    {
                        upload = writable.BeginUpload(path, node); owner = true; node = upload.Node;
                    }
                    else if (dataWrite) return NTStatus.STATUS_NOT_SUPPORTED; // Replace supported; arbitrary in-place edits are not.
                }
                else if (!exists) node = writable.CreateDirectory(path);
                if (node == null) return NTStatus.STATUS_OBJECT_NAME_NOT_FOUND;
                var opened = new Handle(node) { Upload = upload, Owner = owner, WriteAllowed = dataWrite, MetadataAllowed = metadataWrite,
                    DeleteAllowed = deleteAllowed, DeleteOnClose = (options & CreateOptions.FILE_DELETE_ON_CLOSE) != 0, Sharing = share,
                    NoRecall = (options & CreateOptions.FILE_OPEN_NO_RECALL) != 0 };
                handle = opened; openHandles.Add(opened);
                fileStatus = !exists ? FileStatus.FILE_CREATED : replace ? FileStatus.FILE_OVERWRITTEN : FileStatus.FILE_OPENED;
                return NTStatus.STATUS_SUCCESS;
            }
        }
        catch (Exception e) { return Fail(e); }
    }
    public void AbortUploads()
    {
        stopping = true;
        Handle[] opened; lock (createGate) opened = openHandles.ToArray();
        foreach (var h in opened) { ICloudReadSession? reader; lock (h.ReadGate) reader = h.Reader; reader?.Dispose(); }
        if (tree is IWritableCloudTree writable) writable.AbortUploads();
    }
    public NTStatus CloseFile(object handle)
    {
        if (handle is not Handle h) return NTStatus.STATUS_INVALID_HANDLE;
        if (Interlocked.Exchange(ref h.Closed, 1) != 0) return NTStatus.STATUS_SUCCESS;
        try
        {
            if (h.Owner && h.Upload != null)
            {
                if (h.RemoteTrashed) { }
                else if (stopping) { if (!h.Upload.Completed) h.Upload.Abort(); }
                else if (h.DeleteOnClose && !h.Upload.Completed) h.Upload.Abort();
                else if (!h.Upload.Aborted) h.Upload.Complete();
            }
            if (!stopping && h.DeleteOnClose && !h.RemoteTrashed && h.Upload?.Aborted != true && tree is IWritableCloudTree writable)
            {
                NTStatus deletion = ChangeDeletion(writable, h, true);
                if (deletion != NTStatus.STATUS_SUCCESS) return deletion;
            }
            return NTStatus.STATUS_SUCCESS;
        }
        catch (Exception e) { try { if (h.Upload?.Completed == false) h.Upload.Abort(); } catch { } return Fail(e); }
        finally
        {
            ICloudReadSession? reader; lock (h.ReadGate) reader = h.Reader; reader?.Dispose();
            if (h.Owner && h.Upload != null && tree is IWritableCloudTree writable) writable.ReleaseUpload(h.Upload);
            lock (createGate) openHandles.Remove(h);
        }
    }
    public NTStatus ReadFile(out byte[] data, object handle, long offset, int maxCount)
    {
        data = Array.Empty<byte>();
        if (handle is not Handle h || Volatile.Read(ref h.Closed) != 0) return NTStatus.STATUS_INVALID_HANDLE;
        if (h.Upload != null && !h.Upload.Completed) return NTStatus.STATUS_SHARING_VIOLATION;
        if (h.Node.Directory) return NTStatus.STATUS_FILE_IS_A_DIRECTORY;
        if (offset < 0 || maxCount < 0) return NTStatus.STATUS_INVALID_PARAMETER;
        if (offset >= h.Node.Size) return NTStatus.STATUS_END_OF_FILE;
        if (stopping) return NTStatus.STATUS_NETWORK_NAME_DELETED;
        // No-recall is an open hint, not reliable proof of a background caller.
        // Opens/metadata remain lazy; an explicit data read must still work for players.
        if (h.NoRecall) Interlocked.Increment(ref noRecallReads);
        try
        {
            ICloudReadSession? reader;
            lock (h.ReadGate)
            {
                if (Volatile.Read(ref h.Closed) != 0) return NTStatus.STATUS_INVALID_HANDLE;
                reader = h.Reader ??= tree.OpenRead(h.Node);
            }
            int wanted = (int)Math.Min(Math.Min(maxCount, 1024 * 1024), h.Node.Size - offset);
            data = reader != null ? reader.Read(offset, wanted) : tree.Read(h.Node, offset, wanted);
            return NTStatus.STATUS_SUCCESS;
        }
        catch (Exception e) { return Fail(e); }
    }
    public NTStatus WriteFile(out int count, object handle, long offset, byte[] data)
    {
        count = 0; if (tree is not IWritableCloudTree) return NTStatus.STATUS_MEDIA_WRITE_PROTECTED;
        if (handle is not Handle h || Volatile.Read(ref h.Closed) != 0) return NTStatus.STATUS_INVALID_HANDLE;
        if (!h.Owner || !h.WriteAllowed || h.Upload == null) return NTStatus.STATUS_ACCESS_DENIED;
        if (stopping) return NTStatus.STATUS_NETWORK_NAME_DELETED;
        try { count = h.Upload.Write(offset, data); return NTStatus.STATUS_SUCCESS; } catch (Exception e) { return Fail(e); }
    }
    public NTStatus FlushFileBuffers(object handle)
    {
        if (handle is not Handle h || Volatile.Read(ref h.Closed) != 0) return NTStatus.STATUS_INVALID_HANDLE;
        try { if (h.Owner && h.Upload != null && !h.Upload.Aborted) h.Upload.Complete(); return NTStatus.STATUS_SUCCESS; } catch (Exception e) { return Fail(e); }
    }
    public NTStatus LockFile(object h, long o, long l, bool x) => NTStatus.STATUS_SUCCESS;
    public NTStatus UnlockFile(object h, long o, long l) => NTStatus.STATUS_SUCCESS;
    public NTStatus QueryDirectory(out List<QueryDirectoryFileInformation> result, object handle, string pattern, FileInformationClass cls)
    {
        result = new();
        if (handle is not Handle h || !h.Node.Directory) return NTStatus.STATUS_NOT_A_DIRECTORY;
        try
        {
            var entries = new List<CloudNode> { h.Node with { Name = "." }, h.Node with { Name = ".." } };
            entries.AddRange(tree.Children(h.Node));
            foreach (var n in entries.Where(n => FileSystemName.MatchesWin32Expression(pattern, n.Name, true)))
            {
                QueryDirectoryFileInformation? item = cls switch
                {
                    FileInformationClass.FileDirectoryInformation => new FileDirectoryInformation(),
                    FileInformationClass.FileBothDirectoryInformation => new FileBothDirectoryInformation(),
                    FileInformationClass.FileFullDirectoryInformation => new FileFullDirectoryInformation(),
                    FileInformationClass.FileIdBothDirectoryInformation => new FileIdBothDirectoryInformation(),
                    FileInformationClass.FileIdFullDirectoryInformation => new FileIdFullDirectoryInformation(),
                    FileInformationClass.FileNamesInformation => new FileNamesInformation(), _ => null
                };
                if (item == null) return NTStatus.STATUS_INVALID_INFO_CLASS;
                dynamic d = item; d.FileName = n.Name;
                if (cls != FileInformationClass.FileNamesInformation)
                {
                    d.CreationTime = n.Modified; d.LastWriteTime = n.Modified; d.LastAccessTime = n.Modified; d.ChangeTime = n.Modified;
                    d.EndOfFile = n.Size; d.AllocationSize = Allocation(n); d.FileAttributes = Attr(n);
                    if (item is FileIdBothDirectoryInformation a) a.FileId = Identity(n.Id);
                    if (item is FileIdFullDirectoryInformation b) b.FileId = Identity(n.Id);
                }
                result.Add(item);
            }
            return NTStatus.STATUS_SUCCESS;
        }
        catch (Exception e) { return Fail(e); }
    }
    private static ulong Identity(string id) => BitConverter.ToUInt64(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(id)), 0);
    public NTStatus GetFileInformation(out FileInformation result, object handle, FileInformationClass cls)
    {
        result = null!; if (handle is not Handle h) return NTStatus.STATUS_INVALID_HANDLE;
        var n = h.Node;
        var basic = new FileBasicInformation { CreationTime = n.Modified, LastAccessTime = n.Modified, LastWriteTime = n.Modified, ChangeTime = n.Modified, FileAttributes = Attr(n) };
        var standard = new FileStandardInformation { AllocationSize = Allocation(n), EndOfFile = n.Size, Directory = n.Directory, NumberOfLinks = 1, DeletePending = h.DeleteOnClose };
        result = cls switch
        {
            FileInformationClass.FileBasicInformation => basic,
            FileInformationClass.FileStandardInformation => standard,
            FileInformationClass.FileInternalInformation => new FileInternalInformation { IndexNumber = unchecked((long)Identity(n.Id)) },
            FileInformationClass.FileNetworkOpenInformation => new FileNetworkOpenInformation { CreationTime = n.Modified, LastAccessTime = n.Modified, LastWriteTime = n.Modified, ChangeTime = n.Modified, AllocationSize = Allocation(n), EndOfFile = n.Size, FileAttributes = Attr(n) },
            FileInformationClass.FileAllInformation => new FileAllInformation { BasicInformation = basic, StandardInformation = standard, InternalInformation = new FileInternalInformation { IndexNumber = unchecked((long)Identity(n.Id)) }, NameInformation = new FileNameInformation { FileName = n.Path } },
            FileInformationClass.FileNameInformation => new FileNameInformation { FileName = n.Path },
            FileInformationClass.FileEaInformation => new FileEaInformation(),
            FileInformationClass.FileAttributeTagInformation => new FileAttributeTagInformation { FileAttributes = Attr(n) },
            _ => null!
        };
        return result == null ? NTStatus.STATUS_INVALID_INFO_CLASS : NTStatus.STATUS_SUCCESS;
    }
    public NTStatus SetFileInformation(object handle, FileInformation info)
    {
        if (tree is not IWritableCloudTree writable) return NTStatus.STATUS_MEDIA_WRITE_PROTECTED;
        if (handle is not Handle h || Volatile.Read(ref h.Closed) != 0) return NTStatus.STATUS_INVALID_HANDLE;
        try
        {
            if (info is FileDispositionInformation deletion)
            {
                return ChangeDeletion(writable, h, deletion.DeletePending);
            }
            if (info is FileBasicInformation basic)
            {
                if (!h.MetadataAllowed) return NTStatus.STATUS_ACCESS_DENIED;
                if (basic.LastWriteTime.Time.HasValue)
                {
                    DateTime modified = basic.LastWriteTime.Time.Value;
                    if (h.Upload != null) h.Upload.SetModified(modified); else h.Saved = writable.SetModified(h.Node, modified);
                }
                return NTStatus.STATUS_SUCCESS;
            }
            if (!h.Owner || !h.WriteAllowed || h.Upload == null) return NTStatus.STATUS_ACCESS_DENIED;
            if (info is FileEndOfFileInformation eof) { h.Upload.SetLength(eof.EndOfFile); return NTStatus.STATUS_SUCCESS; }
            if (info is FileAllocationInformation allocation) return allocation.AllocationSize >= 0 ? NTStatus.STATUS_SUCCESS : NTStatus.STATUS_INVALID_PARAMETER;
            return NTStatus.STATUS_NOT_SUPPORTED;
        }
        catch (Exception e) { return Fail(e); }
    }
    private NTStatus ChangeDeletion(IWritableCloudTree writable, Handle h, bool delete)
    {
        lock (createGate)
        {
            if (!h.DeleteAllowed || h.Node.Path.Trim('\\').Length == 0) return NTStatus.STATUS_ACCESS_DENIED;
            if (!delete)
            {
                if (h.Upload?.Aborted == true) return NTStatus.STATUS_NOT_SUPPORTED;
                if (h.RemoteTrashed) writable.SetTrashed(h.Node, false);
                h.RemoteTrashed = false; h.DeleteOnClose = false; return NTStatus.STATUS_SUCCESS;
            }
            if (h.RemoteTrashed) return NTStatus.STATUS_SUCCESS;
            if (openHandles.Any(other => !ReferenceEquals(other, h) && other.Node.Id == h.Node.Id && Volatile.Read(ref other.Closed) == 0 && (other.Sharing & ShareAccess.Delete) == 0)) return NTStatus.STATUS_SHARING_VIOLATION;
            if (h.Node.Directory && tree.Children(h.Node).Count > 0) return NTStatus.STATUS_DIRECTORY_NOT_EMPTY;
            if (h.Upload != null && !h.Upload.Completed)
            {
                if (!h.Upload.CanDelete) return NTStatus.STATUS_SHARING_VIOLATION;
                h.Upload.Abort();
            }
            else writable.SetTrashed(h.Node, true);
            h.RemoteTrashed = true; h.DeleteOnClose = true; return NTStatus.STATUS_SUCCESS;
        }
    }
    public NTStatus GetFileSystemInformation(out FileSystemInformation result, FileSystemInformationClass cls)
    {
        var space = tree.Capacity;
        long total = Math.Max(0, space.TotalBytes), free = Math.Clamp(space.FreeBytes, 0, total);
        result = cls switch
        {
            FileSystemInformationClass.FileFsVolumeInformation => new FileFsVolumeInformation { VolumeLabel = tree.VolumeLabel, VolumeSerialNumber = 0x434C4E45, VolumeCreationTime = new DateTime(2026, 1, 1), SupportsObjects = false },
            FileSystemInformationClass.FileFsSizeInformation => new FileFsSizeInformation { TotalAllocationUnits = total / 4096, AvailableAllocationUnits = free / 4096, SectorsPerAllocationUnit = 8, BytesPerSector = 512 },
            FileSystemInformationClass.FileFsFullSizeInformation => new FileFsFullSizeInformation { TotalAllocationUnits = total / 4096, CallerAvailableAllocationUnits = free / 4096, ActualAvailableAllocationUnits = free / 4096, SectorsPerAllocationUnit = 8, BytesPerSector = 512 },
            FileSystemInformationClass.FileFsAttributeInformation => new FileFsAttributeInformation { FileSystemName = "Cloudlane", FileSystemAttributes = FileSystemAttributes.CasePreservedNames | FileSystemAttributes.UnicodeOnDisk | (tree is IWritableCloudTree ? 0 : FileSystemAttributes.ReadOnlyVolume), MaximumComponentNameLength = 255 },
            FileSystemInformationClass.FileFsDeviceInformation => new FileFsDeviceInformation { DeviceType = DeviceType.Disk, Characteristics = DeviceCharacteristics.IsMounted },
            FileSystemInformationClass.FileFsControlInformation => new FileFsControlInformation { FileSystemControlFlags = FileSystemControlFlags.ContentIndexingDisabled, DefaultQuotaLimit = ulong.MaxValue, DefaultQuotaThreshold = ulong.MaxValue },
            FileSystemInformationClass.FileFsSectorSizeInformation => new FileFsSectorSizeInformation { LogicalBytesPerSector = 512, PhysicalBytesPerSectorForAtomicity = 512, PhysicalBytesPerSectorForPerformance = 512, FileSystemEffectivePhysicalBytesPerSectorForAtomicity = 512 },
            _ => null!
        };
        return result == null ? NTStatus.STATUS_INVALID_INFO_CLASS : NTStatus.STATUS_SUCCESS;
    }
    public NTStatus SetFileSystemInformation(FileSystemInformation info) => tree is IWritableCloudTree ? NTStatus.STATUS_NOT_SUPPORTED : NTStatus.STATUS_MEDIA_WRITE_PROTECTED;
    public NTStatus GetSecurityInformation(out SecurityDescriptor result, object handle, SecurityInformation info) { result = null!; return NTStatus.STATUS_NOT_SUPPORTED; }
    public NTStatus SetSecurityInformation(object handle, SecurityInformation info, SecurityDescriptor desc) => tree is IWritableCloudTree ? NTStatus.STATUS_NOT_SUPPORTED : NTStatus.STATUS_MEDIA_WRITE_PROTECTED;
    public NTStatus NotifyChange(out object request, object handle, NotifyChangeFilter filter, bool tree, int size, OnNotifyChangeCompleted completed, object context) { request = null!; return NTStatus.STATUS_NOT_SUPPORTED; }
    public NTStatus Cancel(object request) => NTStatus.STATUS_SUCCESS;
    public NTStatus DeviceIOControl(object handle, uint code, byte[] input, out byte[] output, int max) { output = Array.Empty<byte>(); return NTStatus.STATUS_NOT_SUPPORTED; }
}

