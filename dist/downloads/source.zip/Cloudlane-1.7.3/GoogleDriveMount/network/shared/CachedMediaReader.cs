using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
namespace Cloudlane.Mount;

public sealed class CachedMediaReader : ICloudReadSession
{
    public const int ReadAheadBlocks = 32; // Up to 256 MiB ahead, within the shared 2 GiB disk budget.
    public const int ActivationBytes = 512 * 1024;
    public const int ProbeWindowBytes = 64 * 1024;
    private static readonly SemaphoreSlim fronts = new(8, 8);
    private readonly object readGate = new(), aheadGate = new();
    private readonly MediaBlockCache cache;
    private readonly string identity;
    private readonly long length;
    private readonly bool preloadVideo;
    private readonly Func<CancellationToken, Task> validate;
    private readonly Func<long, int, CancellationToken, Task<byte[]>> download;
    private readonly CancellationTokenSource lifetime;
    private CancellationTokenSource? aheadCancel;
    private Task aheadTask = Task.CompletedTask;
    private long nextAhead, targetAhead, lastBlock = -1;
    private long frontOffset = -1;
    private byte[]? front;
    private bool verified, ownsFront, disposed;
    private bool active;
    private long sequenceEnd = -1, sequenceBytes;
    private int sequenceReads;
    private long retryAheadAfter;
    public CachedMediaReader(MediaBlockCache cache, string identity, long length, Func<CancellationToken, Task> validate,
        Func<long, int, CancellationToken, Task<byte[]>> download, CancellationToken ct, bool preloadVideo = true)
    {
        this.cache = cache; this.identity = identity; this.length = length; this.validate = validate; this.download = download; this.preloadVideo = preloadVideo;
        lifetime = CancellationTokenSource.CreateLinkedTokenSource(ct);
    }
    public byte[] Read(long offset, int count)
    {
        if (offset < 0 || count < 0 || count > CloudReadBuffer.BlockSize) throw new IOException("Invalid streaming range.");
        lock (readGate)
        {
            if (disposed) throw new OperationCanceledException("The media file was closed.");
            lifetime.Token.ThrowIfCancellationRequested();
            if (offset >= length || count == 0) return Array.Empty<byte>();
            if (!verified) { validate(lifetime.Token).GetAwaiter().GetResult(); verified = true; }
            int wanted = (int)Math.Min(count, length - offset);
            if (!ownsFront) ownsFront = fronts.Wait(0);
            if (!active)
            {
                if (offset == sequenceEnd) { sequenceBytes += wanted; sequenceReads++; }
                else { sequenceBytes = wanted; sequenceReads = 1; }
                sequenceEnd = offset + wanted;
                active = sequenceReads >= 2 && sequenceBytes >= ActivationBytes;
                if (!active) return ReadProbe(offset, wanted);
                // Probe RAM is not a fully verified cache block. Demand reads now use normal cache keys.
                front = null;
            }
            long currentBlock = offset / MediaBlockCache.BlockSize;
            Prioritize(currentBlock);
            byte[] result = new byte[wanted]; int copied = 0;
            bool partialWindow = false;
            while (copied < wanted)
            {
                long position = offset + copied;
                long blockStart = position / MediaBlockCache.BlockSize * MediaBlockCache.BlockSize;
                int blockCount = (int)Math.Min(MediaBlockCache.BlockSize, length - blockStart);
                byte[] bytes;
                if (front != null && position >= frontOffset && position < frontOffset + front.Length)
                { bytes = front; blockStart = frontOffset; }
                else
                {
                    front = null;
                    // Start video promptly: foreground misses fetch at most 1 MiB while larger chunks preload.
                    if (length > 4L * 1024 * 1024 && !cache.Contains(identity, blockStart, blockCount))
                    {
                        blockStart = position / CloudReadBuffer.BlockSize * CloudReadBuffer.BlockSize;
                        blockCount = (int)Math.Min(CloudReadBuffer.BlockSize, length - blockStart); partialWindow = true;
                    }
                    bytes = cache.GetAsync(identity, blockStart, blockCount, ct => download(blockStart, blockCount, ct), true, lifetime.Token).GetAwaiter().GetResult();
                    if (ownsFront) { front = bytes; frontOffset = blockStart; }
                }
                int inside = (int)(position - blockStart), take = Math.Min(wanted - copied, bytes.Length - inside);
                if (take <= 0) throw new IOException("Invalid cached media block.");
                bytes.AsSpan(inside, take).CopyTo(result.AsSpan(copied)); copied += take;
            }
            if (preloadVideo) BeginAhead((offset + wanted - 1) / MediaBlockCache.BlockSize, partialWindow);
            return result;
        }
    }
    private byte[] ReadProbe(long offset, int wanted)
    {
        byte[] result = new byte[wanted]; int copied = 0;
        while (copied < wanted)
        {
            long position = offset + copied, start = frontOffset;
            byte[]? bytes = front;
            if (bytes == null || position < start || position >= start + bytes.Length)
            {
                start = position / MediaBlockCache.BlockSize * MediaBlockCache.BlockSize;
                int size = (int)Math.Min(MediaBlockCache.BlockSize, length - start);
                bytes = cache.TryRead(identity, start, size);
                if (bytes == null)
                {
                    start = position / CloudReadBuffer.BlockSize * CloudReadBuffer.BlockSize;
                    size = (int)Math.Min(CloudReadBuffer.BlockSize, length - start);
                    bytes = cache.TryRead(identity, start, size);
                }
                if (bytes == null)
                {
                    start = position;
                    size = (int)Math.Min(Math.Max(ProbeWindowBytes, wanted - copied), length - start);
                    bytes = download(start, size, lifetime.Token).GetAwaiter().GetResult();
                    if (bytes.Length != size) throw new IOException("Google returned an incomplete probe range.");
                }
                if (ownsFront) { front = bytes; frontOffset = start; }
            }
            int inside = (int)(position - start), take = Math.Min(wanted - copied, bytes.Length - inside);
            bytes.AsSpan(inside, take).CopyTo(result.AsSpan(copied)); copied += take;
        }
        return result;
    }
    private void Prioritize(long block)
    {
        CancellationTokenSource? old = null;
        lock (aheadGate)
        {
            if (lastBlock >= 0 && (block < lastBlock || block > lastBlock + 1))
            { old = aheadCancel; aheadCancel = null; nextAhead = block + 1; targetAhead = nextAhead; retryAheadAfter = 0; }
            lastBlock = block;
        }
        // A seek cancels the old queued/in-flight preload, while the new foreground read has its reserved worker.
        if (old != null) { try { old.Cancel(); } catch (ObjectDisposedException) { } }
    }
    private void BeginAhead(long block, bool includeCurrent)
    {
        lock (aheadGate)
        {
            if (Environment.TickCount64 < retryAheadAfter) return;
            long blocks = (length + MediaBlockCache.BlockSize - 1) / MediaBlockCache.BlockSize;
            long ahead = Math.Max(0, Math.Min(ReadAheadBlocks, cache.CapacityBytes / (MediaBlockCache.BlockSize + 64L) - 1));
            long target = Math.Min(blocks, block + 1 + ahead);
            if (aheadCancel != null && !aheadCancel.IsCancellationRequested)
            {
                targetAhead = Math.Max(targetAhead, target);
                if (!aheadTask.IsCompleted) return;
                if (nextAhead >= targetAhead) return;
            }
            else { nextAhead = includeCurrent ? block : block + 1; targetAhead = target; }
            var cancel = CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token);
            aheadCancel = cancel; aheadTask = Task.Run(() => PreloadAsync(cancel));
        }
    }
    private async Task PreloadAsync(CancellationTokenSource cancel)
    {
        try { await Task.WhenAll(PreloadLaneAsync(cancel), PreloadLaneAsync(cancel)).ConfigureAwait(false); }
        catch (OperationCanceledException) { }
        catch (Exception) { lock (aheadGate) retryAheadAfter = Environment.TickCount64 + 10000; }
        finally { cancel.Dispose(); }
    }
    private async Task PreloadLaneAsync(CancellationTokenSource cancel)
    {
        try
        {
            while (true)
            {
                long block;
                lock (aheadGate)
                {
                    if (!ReferenceEquals(aheadCancel, cancel) || nextAhead >= targetAhead) return;
                    block = nextAhead++;
                }
                cancel.Token.ThrowIfCancellationRequested();
                long offset = block * MediaBlockCache.BlockSize;
                int count = (int)Math.Min(MediaBlockCache.BlockSize, length - offset);
                await cache.WarmAsync(identity, offset, count, ct => download(offset, count, ct), cancel.Token).ConfigureAwait(false);
            }
        }
        catch { try { cancel.Cancel(); } catch (ObjectDisposedException) { } throw; }
    }
    public void Dispose()
    {
        try { lifetime.Cancel(); } catch (ObjectDisposedException) { }
        lock (readGate)
        {
            if (disposed) return;
            disposed = true; front = null;
            if (ownsFront) { ownsFront = false; fronts.Release(); }
            // Keep the CTS until its preload task has unwound; no background task touches the player window.
            Task pending; lock (aheadGate) pending = aheadTask;
            _ = pending.ContinueWith(_ => lifetime.Dispose(), CancellationToken.None, TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
        }
    }
}
