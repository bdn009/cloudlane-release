using System;
using System.IO;
using System.Threading;
namespace Cloudlane.Mount;

public interface ICloudReadSession : IDisposable
{
    byte[] Read(long offset, int count);
}

// One sliding transfer buffer per open file, released on close. No disk payloads.
public sealed class CloudReadBuffer : ICloudReadSession
{
    public const int BlockSize = 1024 * 1024;
    public const int MaxBufferedReaders = 16;
    private static readonly SemaphoreSlim slots = new(MaxBufferedReaders, MaxBufferedReaders);
    private readonly object gate = new();
    private readonly long length;
    private readonly Func<long, int, CancellationToken, byte[]> fetch;
    private readonly CancellationTokenSource lifetime;
    private byte[]? buffer;
    private long start;
    private bool ownsSlot, disposed;
    public CloudReadBuffer(long length, Func<long, int, CancellationToken, byte[]> fetch, CancellationToken cancellation)
    { this.length = length; this.fetch = fetch; lifetime = CancellationTokenSource.CreateLinkedTokenSource(cancellation); }
    public byte[] Read(long offset, int count)
    {
        if (offset < 0 || count < 0 || count > BlockSize) throw new IOException("Invalid streaming range.");
        lock (gate)
        {
            if (disposed) throw new OperationCanceledException("The cloud file was closed.");
            lifetime.Token.ThrowIfCancellationRequested();
            if (offset >= length || count == 0) return Array.Empty<byte>();
            int wanted = (int)Math.Min(count, length - offset);
            if (!ownsSlot) ownsSlot = slots.Wait(0);
            if (!ownsSlot) return Fetch(offset, wanted); // Busy thumbnail batches cannot grow RAM without bound.
            byte[] result = new byte[wanted]; int copied = 0;
            while (copied < wanted)
            {
                long position = offset + copied;
                if (buffer == null || position < start || position >= start + buffer.Length)
                {
                    // Drop the previous window before allocating its replacement.
                    buffer = null; start = position;
                    buffer = Fetch(position, (int)Math.Min(BlockSize, length - position));
                }
                int within = (int)(position - start), take = Math.Min(wanted - copied, buffer.Length - within);
                buffer.AsSpan(within, take).CopyTo(result.AsSpan(copied)); copied += take;
            }
            return result;
        }
    }
    private byte[] Fetch(long offset, int count)
    {
        var bytes = fetch(offset, count, lifetime.Token);
        if (bytes.Length != count) throw new IOException("Google returned an incomplete streaming range.");
        return bytes;
    }
    public void Dispose()
    {
        // Cancellation must happen before taking the lock held by an in-flight network read.
        try { lifetime.Cancel(); } catch (ObjectDisposedException) { }
        lock (gate)
        {
            if (disposed) return;
            disposed = true; buffer = null;
            if (ownsSlot) { ownsSlot = false; slots.Release(); }
            lifetime.Dispose();
        }
    }
}
