using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
namespace Cloudlane.Mount;

// A bounded, account/version-keyed disk cache. Foreground downloads have a reserved worker.
public sealed class MediaBlockCache : IAsyncDisposable
{
    public const long DefaultCapacity = 2L * 1024 * 1024 * 1024;
    public const int BlockSize = 8 * 1024 * 1024;
    public const int MaxEntries = 4096;
    private const int HeaderSize = 44;
    private const string Marker = "Cloudlane streaming cache v1";
    private static readonly byte[] Magic = Encoding.ASCII.GetBytes("CLSCACH1");
    private static readonly Regex BlockName = new("^[A-F0-9]{64}\\.block$", RegexOptions.CultureInvariant);
    private static readonly Regex TempName = new("^[A-F0-9]{64}\\.tmp\\.[a-f0-9]{32}$", RegexOptions.CultureInvariant);
    private sealed record Entry(long Bytes, long Access);
    private sealed class Job(string key, int count, Func<CancellationToken, Task<byte[]>> fetch, bool foreground, CancellationToken stop)
    {
        public readonly string Key = key;
        public readonly int Count = count;
        public readonly Func<CancellationToken, Task<byte[]>> Fetch = fetch;
        public readonly TaskCompletionSource<byte[]> Done = new(TaskCreationOptions.RunContinuationsAsynchronously);
        public bool Foreground = foreground, Started;
        public int Consumers;
        public readonly CancellationTokenSource Cancel = CancellationTokenSource.CreateLinkedTokenSource(stop);
    }
    private readonly string root;
    private readonly long capacity;
    private readonly object diskGate = new(), queueGate = new();
    private readonly Dictionary<string, Entry> entries = new(StringComparer.Ordinal);
    private readonly Dictionary<string, Job> jobs = new(StringComparer.Ordinal);
    private readonly Queue<Job> foreground = new(), background = new();
    private readonly SemaphoreSlim demandSignal = new(0), anySignal = new(0);
    private readonly CancellationTokenSource stop;
    private readonly FileStream owner;
    private readonly Task[] workers;
    private long used, clock, hits, downloads;
    private bool disposed;
    private string lastError = "";
    public string LastError => Volatile.Read(ref lastError);
    public long UsedBytes { get { lock (diskGate) return used; } }
    public long CapacityBytes => capacity;
    public string Diagnostics => $"Streaming cache: bytes={UsedBytes}/{capacity}; hits={Interlocked.Read(ref hits)}; downloaded blocks={Interlocked.Read(ref downloads)}; queued/active={PendingCount}; error={LastError}";
    public int PendingCount { get { lock (queueGate) return jobs.Count; } }
    public MediaBlockCache(string root, CancellationToken cancellation, long capacity = DefaultCapacity, Action<string>? secureDirectory = null)
    {
        if (!Path.IsPathFullyQualified(root) || capacity < HeaderSize + 1) throw new ArgumentException("Invalid streaming cache folder or capacity.");
        this.root = Path.GetFullPath(root); this.capacity = capacity;
        InitializeRoot(this.root, secureDirectory); owner = LockRoot(this.root);
        stop = CancellationTokenSource.CreateLinkedTokenSource(cancellation);
        try
        {
            foreach (string path in Directory.EnumerateFiles(this.root))
            {
                string name = Path.GetFileName(path);
                if (TempName.IsMatch(name)) { File.Delete(path); continue; }
                if (!BlockName.IsMatch(name)) continue;
                var file = new FileInfo(path);
                if (file.Length < HeaderSize || file.Length > BlockSize + HeaderSize) { File.Delete(path); continue; }
                entries[name[..64]] = new(file.Length, file.LastWriteTimeUtc.Ticks); used += file.Length;
            }
            clock = Math.Max(DateTime.UtcNow.Ticks, entries.Count == 0 ? 0 : entries.Values.Max(e => e.Access));
            EvictFor(0);
            workers = new[] { Task.Run(() => WorkerAsync(false)), Task.Run(() => WorkerAsync(true)), Task.Run(() => WorkerAsync(true)) };
        }
        catch { owner.Dispose(); stop.Dispose(); throw; }
    }
    private static void InitializeRoot(string root, Action<string>? secure)
    {
        Directory.CreateDirectory(root);
        string marker = Path.Combine(root, ".cloudlane-cache-v1");
        if (File.Exists(marker))
        { if (File.ReadAllText(marker) != Marker) throw new IOException("This folder is not a Cloudlane streaming cache."); }
        else
        {
            if (Directory.EnumerateFileSystemEntries(root).Any()) throw new IOException("Choose a different cache location; this folder contains unrelated files.");
            File.WriteAllText(marker, Marker);
        }
        secure?.Invoke(root);
    }
    private static FileStream LockRoot(string root) => new(Path.Combine(root, ".cloudlane-cache-lock"), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
    public static string Key(string identity, long offset, int count) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(identity + "|" + offset + "|" + count)));
    public bool Contains(string identity, long offset, int count)
    { string key = Key(identity, offset, count); lock (diskGate) return entries.TryGetValue(key, out var e) && e.Bytes == count + HeaderSize; }
    public async Task WarmAsync(string identity, long offset, int count, Func<CancellationToken, Task<byte[]>> fetch, CancellationToken ct)
    {
        if (Contains(identity, offset, count)) return;
        await GetAsync(identity, offset, count, fetch, false, ct).ConfigureAwait(false);
    }
    public Task<byte[]> GetAsync(string identity, long offset, int count, Func<CancellationToken, Task<byte[]>> fetch, bool isForeground, CancellationToken ct)
    {
        if (offset < 0 || count <= 0 || count > BlockSize) throw new ArgumentException("Invalid cache block.");
        ct.ThrowIfCancellationRequested();
        lock (queueGate) if (disposed) throw new OperationCanceledException("Streaming cache stopped.");
        string key = Key(identity, offset, count);
        byte[]? hit = ReadStored(key, count);
        if (hit != null) { Interlocked.Increment(ref hits); return Task.FromResult(hit); }
        Job job;
        lock (queueGate)
        {
            if (disposed || stop.IsCancellationRequested) throw new OperationCanceledException("Streaming cache stopped.");
            if (!jobs.TryGetValue(key, out job!) || job.Cancel.IsCancellationRequested)
            {
                job = new(key, count, fetch, isForeground, stop.Token); jobs[key] = job;
                // Observe failures even when every waiting playback handle has been closed.
                _ = job.Done.Task.ContinueWith(t => { _ = t.Exception; }, CancellationToken.None, TaskContinuationOptions.OnlyOnFaulted | TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
                if (isForeground) foreground.Enqueue(job); else background.Enqueue(job);
                Signal(isForeground);
            }
            else if (isForeground && !job.Started && !job.Foreground)
            { job.Foreground = true; foreground.Enqueue(job); Signal(true); }
            job.Consumers++;
        }
        // Closing one playback handle must not cancel another handle's shared block download.
        return ConsumeAsync(job, ct);
    }
    // Probe reads may reuse existing verified blocks but must not populate the disk cache.
    public byte[]? TryRead(string identity, long offset, int count)
    {
        lock (queueGate) if (disposed) throw new OperationCanceledException("Streaming cache stopped.");
        var bytes = ReadStored(Key(identity, offset, count), count);
        if (bytes != null) Interlocked.Increment(ref hits);
        return bytes;
    }
    private async Task<byte[]> ConsumeAsync(Job job, CancellationToken ct)
    {
        try { return await job.Done.Task.WaitAsync(ct).ConfigureAwait(false); }
        finally
        {
            bool cancel = false, queued = false;
            lock (queueGate)
            {
                job.Consumers--;
                if (job.Consumers == 0 && !job.Done.Task.IsCompleted)
                {
                    cancel = true;
                    if (!job.Started)
                    {
                        queued = true; job.Started = true; job.Done.TrySetCanceled();
                        if (jobs.TryGetValue(job.Key, out var current) && ReferenceEquals(current, job)) jobs.Remove(job.Key);
                    }
                }
            }
            if (cancel) try { job.Cancel.Cancel(); } catch (ObjectDisposedException) { }
            if (queued) job.Cancel.Dispose();
        }
    }
    private void Signal(bool demand) { if (demand) demandSignal.Release(); anySignal.Release(); }
    private Job? Next(bool allowBackground)
    {
        while (foreground.Count > 0) { var job = foreground.Dequeue(); if (!job.Started) { job.Started = true; return job; } }
        if (allowBackground) while (background.Count > 0) { var job = background.Dequeue(); if (!job.Started) { job.Started = true; return job; } }
        return null;
    }
    private async Task WorkerAsync(bool allowBackground)
    {
        try
        {
            while (true)
            {
                await (allowBackground ? anySignal : demandSignal).WaitAsync(stop.Token).ConfigureAwait(false);
                Job? job; lock (queueGate) job = Next(allowBackground);
                if (job == null) continue;
                try
                {
                    stop.Token.ThrowIfCancellationRequested();
                    var bytes = ReadStored(job.Key, job.Count);
                    if (bytes == null)
                    {
                        bytes = await job.Fetch(job.Cancel.Token).ConfigureAwait(false);
                        if (bytes.Length != job.Count) throw new IOException("Google returned an incomplete streaming block.");
                        job.Cancel.Token.ThrowIfCancellationRequested();
                        Interlocked.Increment(ref downloads); Store(job.Key, bytes);
                    }
                    else Interlocked.Increment(ref hits);
                    job.Done.TrySetResult(bytes);
                }
                catch (OperationCanceledException) { job.Done.TrySetCanceled(); }
                catch (Exception ex) { Volatile.Write(ref lastError, "Streaming download needs retry: " + ex.Message); job.Done.TrySetException(ex); }
                finally
                {
                    lock (queueGate)
                    {
                        if (jobs.TryGetValue(job.Key, out var current) && ReferenceEquals(current, job)) jobs.Remove(job.Key);
                        // Promotion can leave a duplicate queue reference. Do not retain completed payloads there.
                        TrimStarted(foreground); TrimStarted(background);
                    }
                    job.Cancel.Dispose();
                }
            }
        }
        catch (OperationCanceledException) when (stop.IsCancellationRequested) { }
    }
    private static void TrimStarted(Queue<Job> queue)
    {
        int count = queue.Count;
        while (count-- > 0) { var job = queue.Dequeue(); if (!job.Started) queue.Enqueue(job); }
    }
    private byte[]? ReadStored(string key, int count)
    {
        lock (diskGate)
        {
            if (!entries.TryGetValue(key, out var entry)) return null;
            string path = Path.Combine(root, key + ".block");
            try
            {
                var raw = File.ReadAllBytes(path);
                bool valid = raw.Length == count + HeaderSize && raw.AsSpan(0, 8).SequenceEqual(Magic) &&
                    BinaryPrimitives.ReadInt32LittleEndian(raw.AsSpan(8, 4)) == count &&
                    SHA256.HashData(raw.AsSpan(HeaderSize)).AsSpan().SequenceEqual(raw.AsSpan(12, 32));
                if (!valid) throw new IOException("Cached block checksum mismatch.");
                long access = ++clock;
                try { File.SetLastWriteTimeUtc(path, new DateTime(access, DateTimeKind.Utc)); } catch (IOException) { } catch (UnauthorizedAccessException) { }
                entries[key] = entry with { Access = access };
                return raw.AsSpan(HeaderSize).ToArray();
            }
            catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
            {
                Volatile.Write(ref lastError, "A cached block was unavailable; downloading it again. " + ex.Message);
                try { RemoveEntry(key); } catch (IOException) { } catch (UnauthorizedAccessException) { }
                return null;
            }
        }
    }
    private void Store(string key, byte[] bytes)
    {
        lock (diskGate)
        {
            int needed = bytes.Length + HeaderSize;
            if (needed > capacity) return;
            string temp = Path.Combine(root, key + ".tmp." + Guid.NewGuid().ToString("N"));
            try
            {
                EvictFor(needed);
                var volume = new DriveInfo(Path.GetPathRoot(root)!);
                if (volume.AvailableFreeSpace < needed + 256L * 1024 * 1024)
                { Volatile.Write(ref lastError, "Local disk space is low; this block is streamed without caching."); return; }
                using (var file = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    byte[] header = new byte[HeaderSize]; Magic.CopyTo(header, 0);
                    BinaryPrimitives.WriteInt32LittleEndian(header.AsSpan(8, 4), bytes.Length); SHA256.HashData(bytes).CopyTo(header, 12);
                    file.Write(header); file.Write(bytes);
                }
                string path = Path.Combine(root, key + ".block");
                File.Move(temp, path, true);
                if (entries.TryGetValue(key, out var old)) used -= old.Bytes;
                entries[key] = new(needed, ++clock); used += needed;
                File.SetLastWriteTimeUtc(path, new DateTime(clock, DateTimeKind.Utc));
                Volatile.Write(ref lastError, "");
            }
            catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
            {
                Volatile.Write(ref lastError, "Cache write failed; streaming continues without saving this block. " + ex.Message);
            }
            finally
            {
                if (File.Exists(temp))
                {
                    try { File.Delete(temp); }
                    catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
                    { used += new FileInfo(temp).Length; } // Count stranded partial data against the same capacity.
                }
            }
        }
    }
    private void EvictFor(long needed)
    {
        int maximum = needed > 0 ? MaxEntries - 1 : MaxEntries;
        while ((used + needed > capacity || entries.Count > maximum) && entries.Count > 0) RemoveEntry(entries.MinBy(e => e.Value.Access).Key);
        if (used + needed > capacity) throw new IOException("Streaming cache capacity is too small.");
    }
    private void RemoveEntry(string key)
    {
        if (!entries.TryGetValue(key, out var entry)) return;
        File.Delete(Path.Combine(root, key + ".block")); entries.Remove(key); used -= entry.Bytes;
    }
    public static long Inspect(string root)
    {
        if (!Directory.Exists(root) || !File.Exists(Path.Combine(root, ".cloudlane-cache-v1"))) return 0;
        if (File.ReadAllText(Path.Combine(root, ".cloudlane-cache-v1")) != Marker) throw new IOException("Invalid streaming cache folder.");
        return Directory.EnumerateFiles(root).Where(p => BlockName.IsMatch(Path.GetFileName(p)) || TempName.IsMatch(Path.GetFileName(p))).Sum(p => new FileInfo(p).Length);
    }
    public static void ClearStored(string root)
    {
        if (!Directory.Exists(root)) return;
        if (!File.Exists(Path.Combine(root, ".cloudlane-cache-v1")) || File.ReadAllText(Path.Combine(root, ".cloudlane-cache-v1")) != Marker)
            throw new IOException("This folder is not a Cloudlane streaming cache; no files were removed.");
        using var cacheLock = LockRoot(root);
        foreach (string path in Directory.EnumerateFiles(root))
            if (BlockName.IsMatch(Path.GetFileName(path)) || TempName.IsMatch(Path.GetFileName(path))) File.Delete(path);
    }
    public async ValueTask DisposeAsync()
    {
        lock (queueGate) { if (disposed) return; disposed = true; }
        stop.Cancel();
        await Task.WhenAll(workers).ConfigureAwait(false);
        lock (queueGate) { foreach (var job in jobs.Values) { job.Done.TrySetCanceled(); job.Cancel.Dispose(); } jobs.Clear(); foreground.Clear(); background.Clear(); }
        owner.Dispose(); stop.Dispose(); demandSignal.Dispose(); anySignal.Dispose();
    }
}
