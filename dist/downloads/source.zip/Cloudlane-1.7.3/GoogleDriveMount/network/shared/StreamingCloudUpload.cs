using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
namespace Cloudlane.Mount;
public interface ICloudUploadSink
{
    CloudNode? Send(byte[] buffer, int count, long offset, long? total, string? finalMd5);
    CloudNode SetModified(CloudNode node, DateTime modified);
    void Abort(bool committed);
}
public interface IWritableCloudTree : ICloudTree
{
    void SetTrashed(CloudNode node, bool trashed);
    StreamingCloudUpload BeginUpload(string path, CloudNode? replaced);
    StreamingCloudUpload? PendingUpload(string path);
    CloudNode CreateDirectory(string path);
    CloudNode SetModified(CloudNode node, DateTime modified);
    void ReleaseUpload(StreamingCloudUpload upload);
    void AbortUploads();
}
// A bounded forward write window accommodates pipelined SMB writes without
// storing a whole file. Bytes behind the sent prefix can never be rewritten.
public sealed class StreamingCloudUpload
{
    public const int ChunkSize = 1024 * 1024;
    public const int WindowSize = 4 * ChunkSize;
    private readonly object gate = new();
    private readonly ICloudUploadSink sink;
    private readonly Action<StreamingCloudUpload> changed, finished;
    private readonly IncrementalHash hash = IncrementalHash.CreateHash(HashAlgorithmName.MD5);
    private readonly List<(long From, long To)> ranges = new();
    private byte[]? buffer;
    private volatile CloudNode node;
    private long sent, highWater;
    private long? expected;
    private Exception? failure;
    private volatile bool done, aborted;
    private bool released;
    private bool modifiedRequested;
    public bool CanDelete { get; }
    public CloudNode Node => node;
    public bool Completed => done;
    public bool Aborted => aborted;
    public long SentBytes { get { lock (gate) return sent; } }
    public int BufferedCapacity { get { lock (gate) return buffer?.Length ?? 0; } }
    public StreamingCloudUpload(CloudNode node, ICloudUploadSink sink, Action<StreamingCloudUpload> changed, Action<StreamingCloudUpload> finished, bool canDelete = true)
    { this.node = node; this.sink = sink; this.changed = changed; this.finished = finished; CanDelete = canDelete; }
    private void Check()
    {
        if (aborted) throw new IOException("The Explorer upload was cancelled. Copy the original again.");
        if (failure != null) throw new IOException("The Explorer upload failed. Copy the original again. " + failure.Message, failure);
    }
    public void SetLength(long length)
    {
        lock (gate)
        {
            Check();
            if (length < 0 || length < highWater || done && length != node.Size) throw new NotSupportedException("Truncating or extending an uploaded file in place is not supported. Use Copy / Replace.");
            if (done) return;
            // An initial SetEndOfFile(0) is a normal create/truncate operation,
            // not proof that an empty upload should be committed immediately.
            expected = length == 0 ? null : length;
            node = node with { Size = length }; changed(this);
            RunPump();
        }
    }
    public int Write(long offset, byte[] data)
    {
        lock (gate)
        {
            Check(); if (done) throw new NotSupportedException("Writing after a completed upload is not supported. Use Copy / Replace.");
            if (offset < sent || offset < 0 || data.LongLength > long.MaxValue - offset) throw new NotSupportedException("Rewriting an uploaded prefix is not supported. Use a new Explorer copy.");
            long end = offset + data.Length;
            if (end - sent > WindowSize || expected.HasValue && end > expected.Value) throw new NotSupportedException("The write exceeds the bounded forward upload window or declared file size.");
            if (data.Length == 0) return 0;
            buffer ??= new byte[WindowSize];
            foreach (var range in ranges)
            {
                long from = Math.Max(offset, range.From), to = Math.Min(end, range.To);
                if (to > from && !buffer.AsSpan((int)(from - sent), (int)(to - from)).SequenceEqual(data.AsSpan((int)(from - offset), (int)(to - from))))
                    throw new NotSupportedException("A copy attempted to change bytes already in the upload window.");
            }
            if (ranges.Count >= 1024) throw new NotSupportedException("Too many fragmented writes in the upload window.");
            data.CopyTo(buffer, (int)(offset - sent));
            ranges.Add((offset, end)); ranges.Sort((a, b) => a.From.CompareTo(b.From));
            for (int i = 0; i + 1 < ranges.Count;)
            {
                if (ranges[i].To >= ranges[i + 1].From) { ranges[i] = (ranges[i].From, Math.Max(ranges[i].To, ranges[i + 1].To)); ranges.RemoveAt(i + 1); }
                else i++;
            }
            highWater = Math.Max(highWater, end); node = node with { Size = expected ?? highWater }; changed(this);
            RunPump(); return data.Length;
        }
    }
    private long Contiguous => ranges.Count > 0 && ranges[0].From == sent ? ranges[0].To - sent : 0;
    private void RunPump()
    {
        try
        {
            while (!done && Contiguous >= ChunkSize && (expected.HasValue ? sent + ChunkSize < expected.Value : highWater > sent + ChunkSize)) Send(ChunkSize, false);
            if (!done && expected.HasValue && highWater == expected.Value && Contiguous == expected.Value - sent) Send((int)Contiguous, true);
        }
        catch (Exception ex) { failure = ex; throw; }
    }
    private void Send(int count, bool final)
    {
        byte[] bytes = buffer ?? Array.Empty<byte>();
        hash.AppendData(bytes, 0, count);
        string? checksum = final ? Convert.ToHexString(hash.GetHashAndReset()).ToLowerInvariant() : null;
        CloudNode? committed = sink.Send(bytes, count, sent, final ? highWater : expected, checksum);
        if (final && committed == null || !final && committed != null) throw new IOException("Google returned an unexpected upload completion state.");
        sent += count;
        if (final)
        {
            if (modifiedRequested) committed = sink.SetModified(committed!, node.Modified);
            node = committed!; buffer = null; ranges.Clear(); done = true; Release(); finished(this);
        }
        else
        {
            Buffer.BlockCopy(bytes, count, bytes, 0, bytes.Length - count);
            ranges.RemoveAll(r => r.To <= sent);
            if (ranges.Count > 0 && ranges[0].From < sent) ranges[0] = (sent, ranges[0].To);
        }
    }
    public CloudNode Complete()
    {
        lock (gate)
        {
            Check(); if (done) return node;
            try
            {
                if (expected.HasValue && highWater != expected.Value || Contiguous != highWater - sent)
                    throw new IOException("The copy ended before all destination bytes were received. The upload was not completed.");
                RunPump(); if (!done) Send((int)Contiguous, true);
                return node;
            }
            catch (Exception ex) { failure = ex; throw; }
        }
    }
    public void SetModified(DateTime modified)
    {
        lock (gate)
        {
            Check(); modifiedRequested = true; node = done ? sink.SetModified(node, modified) : node with { Modified = modified };
            changed(this);
        }
    }
    public void Abort()
    {
        lock (gate)
        {
            if (aborted) return;
            try { sink.Abort(done); }
            finally { aborted = true; buffer = null; ranges.Clear(); Release(); finished(this); }
        }
    }
    private void Release() { if (!released) { hash.Dispose(); released = true; } }
}
