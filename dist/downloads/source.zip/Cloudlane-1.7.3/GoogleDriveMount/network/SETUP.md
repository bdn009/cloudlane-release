# Set up your own Google Drive connection

Cloudlane is open source and uses your own Google Cloud Desktop OAuth client. There is no publisher Google registration in this release. You only need to do this once per installation, then sign in with Google normally. Multiple accounts can use the same client; each account authorizes access separately.

## 1. Create a Google Cloud project

Open https://console.cloud.google.com/ and create or select your own project using the project selector at the top. A Google Cloud free-trial advertisement is separate from this setup; do not create a VM, storage bucket or service account for Cloudlane.

## 2. Enable Google Drive API

In that project, open APIs & Services > Library. Search for Google Drive API, select it and click Enable.

## 3. Configure Google Auth Platform

Open Google Auth Platform > Overview and click Get started if it is not configured yet. Enter an app name and your support/contact email. Choose External if you use a personal Gmail account. Finish the contact and policy steps.

Open Audience. While the app is in Testing, add the exact Google email addresses you will sign in with under Test users, including your own email. Owning the project does not automatically add you as a test user. Testing authorizations for Drive normally expire after seven days; sign in again when needed. Google verification, organization policies and API quotas still apply to your project.

Under Data Access, add the Google Drive scope https://www.googleapis.com/auth/drive. Cloudlane uses it to browse existing files, stream, upload, rename, create folders and move deleted items to Trash. Review this access before authorizing.

## 4. Download a Desktop OAuth JSON

Open Google Auth Platform > Clients > Create client. Set Application type to Desktop app, give it a name and create it. Download the JSON from the creation dialog or the client's detail page. Choose Desktop app, not Web application, API key or service account. The JSON contains both the client ID and client secret; you do not need to paste them separately.

## 5. Import and sign in

Open Cloudlane > Google app setup > Choose Desktop client JSON. Select the downloaded file, click Done, then Sign in with Google. Use an email added to your project's test users and approve the requested access in your browser. The imported JSON is saved encrypted for your Windows account on this PC; it is not sent to the publisher or website.

Choose an unused drive letter, optionally set its name, and click Connect drive. Approve Windows administrator access using the same Windows account. Use Open in Explorer to browse and stream. Add Google account connects additional accounts. Cloudlane must stay running for connected drives to work.

## Startup, uploads and cache

Enable Auto-connect this account when Cloudlane starts for each account you want reconnected, and Start with Windows to launch after Windows sign-in. Windows approval may still appear. Closing the window keeps it in the tray by default; Exit disconnects every drive.

Uploads read the original local file without a separate full payload copy. Keep originals until upload completion. The optional shared 2 GiB media cache evicts older blocks as it fills; it is temporary playback storage, not a backup. Delete moves completed cloud items to Google Drive Trash.

## Requirements and troubleshooting

Windows 11 24H2 or newer, build 26100+, on an x64 PC, internet access and same-user administrator approval. The driverless Explorer connection uses Windows custom SMB ports; earlier Windows releases are not supported. No WinFsp, rclone or separate .NET installation is needed for the packaged app.

Access blocked: check the selected project, OAuth client's Desktop type and Audience > Test users. Add the exact email shown on Google's error screen, then start a fresh sign-in from Cloudlane. An organization may apply additional restrictions. Google determines verification and access rules; using your own client does not bypass them.

To replace the imported registration, disconnect and forget all saved accounts first. Tokens belong to the original client, so sign in again after importing the replacement.

## Update, uninstall and local data

Exit Cloudlane from its tray menu before updating or uninstalling. Use Windows Settings > Apps > Installed apps > Cloudlane > Uninstall. The installer removes its app files, shortcuts and its own startup entry. Installation is per Windows user in %LOCALAPPDATA%\Programs\Cloudlane Production. The production installation is separate from the earlier development/test copy.

Uninstall retains the data-direct folder beside the executable and any separately selected media cache. This includes your encrypted client JSON, encrypted tokens, settings and pending upload references. Exit the app and remove those folders yourself to remove local data; pending work may be lost. To revoke Google authorization, remove your own app's connection in https://myaccount.google.com/connections. Removing local data does not delete your Google Drive files.

## Source and licenses

Download the matching complete Cloudlane source ZIP from the website's Source & setup page. Application code uses the MIT License; SMBLibrary and Utilities use LGPL-3.0-or-later. Their corresponding source and notices are also included in the installer under ThirdParty and licenses. This Windows build is unsigned.

Publisher: bdn236. Support: support@hisabi.store. Do not send passwords, account tokens or client JSON to support.

Official Google Desktop OAuth documentation: https://developers.google.com/identity/protocols/oauth2/native-app
