using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Cloudlane;

static class DesktopChecks
{
    public static async Task RunAsync(Action<bool, string> check)
    {
        var oldSettings = JsonSerializer.Deserialize<Settings>("{\"Letter\":\"H:\",\"AccountId\":\"saved-account\"}")!;
        check(oldSettings.CloseToTray && oldSettings.Letter == "H:" && oldSettings.AccountId == "saved-account",
            "old settings gain close-to-tray without losing the saved account or letter");
        var savedSettings = JsonSerializer.Deserialize<Settings>(JsonSerializer.Serialize(new Settings { CloseToTray = false }))!;
        check(!savedSettings.CloseToTray, "close-to-tray opt-out survives a settings round trip");
        check(oldSettings.DriveName == "" && oldSettings.DriveLabel(null) == "Google Drive",
            "existing settings without a custom drive name retain the automatic default");
        var namedSettings = JsonSerializer.Deserialize<Settings>(JsonSerializer.Serialize(new Settings { Letter = "H:", DriveName = "My media drive", StreamingCacheEnabled = false }))!;
        check(namedSettings.DriveName == "My media drive" && namedSettings.Letter == "H:" && !namedSettings.StreamingCacheEnabled,
            "custom drive names survive serialization without changing the letter or cache preference");
        const string exe = @"D:\Apps with spaces & symbols\Cloudlane.exe";
        var store = new MemoryStartupStore(); var registration = new StartupRegistration(store);
        check(!registration.IsEnabled && store.Writes == 0, "reading startup leaves a new installation opted out");
        registration.SetEnabled(true, exe);
        check(store.Command == "\"" + exe + "\" --startup" && registration.IsEnabled && registration.UsesExecutable(exe),
            "Windows startup quotes the executable path and requests a tray launch");
        check(registration.UsesExecutable(exe.ToUpperInvariant()), "startup path comparison tolerates Windows path casing");
        check(!registration.UsesExecutable(@"D:\Moved\Cloudlane.exe"), "moving the app is detected without silently rewriting startup");
        int writes = store.Writes; _ = registration.IsEnabled; _ = registration.UsesExecutable(exe);
        check(writes == store.Writes, "ordinary startup state reads never write the Run key");
        registration.SetEnabled(false, exe);
        check(!registration.IsEnabled && store.Removes == 1, "turning startup off removes the application's startup entry");
        registration.SetEnabled(true, exe);
        registration.RemoveIfOwned(@"D:\Other copy\Cloudlane.exe");
        check(registration.IsEnabled && store.Removes == 1, "uninstall cleanup preserves a startup entry belonging to another app copy");
        registration.RemoveIfOwned(exe);
        check(!registration.IsEnabled && store.Removes == 2, "uninstall cleanup removes only its own saved Windows startup command");
        foreach (string invalid in new[] { "Cloudlane.exe", @"D:\Cloudlane.exe\" + '"', @"D:\Cloudlane.exe" + '\n', @"D:\Cloudlane.dll", "D:\\" + new string('a', 250) + "\\Cloudlane.exe" })
        {
            bool rejected = false;
            try { registration.SetEnabled(true, invalid); } catch (Exception ex) when (ex is ArgumentException || ex is IOException) { rejected = true; }
            check(rejected && !registration.IsEnabled, "invalid or overlong startup path is rejected before registration");
        }
        store.FailWrites = true; bool denied = false;
        try { registration.SetEnabled(true, exe); } catch (UnauthorizedAccessException) { denied = true; }
        check(denied && !registration.IsEnabled, "startup permission failure is reported without a false enabled state");

        var events = new List<string>();
        var release = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var lifetime = new DesktopLifetime(() => events.Add("hide"), async () =>
        { events.Add("cancel-work"); await release.Task; events.Add("disconnect-drive"); }, () => events.Add("exit"));
        check(lifetime.HideOnClose(true, true) && events.SequenceEqual(new[] { "hide" }) && !lifetime.IsExiting,
            "closing to tray only hides: uploads and mount cleanup are untouched");
        check(!lifetime.HideOnClose(false, true) && !lifetime.HideOnClose(true, false) && events.Count == 1,
            "tray opt-out or unavailable tray cannot silently hide the app");
        Task quit = lifetime.ExitAsync(); Task repeatedQuit = lifetime.ExitAsync();
        check(ReferenceEquals(quit, repeatedQuit) && lifetime.IsExiting && !lifetime.CanClose && !quit.IsCompleted && events.Last() == "cancel-work",
            "Exit is deduplicated and waits for the active operation to settle");
        check(!lifetime.HideOnClose(true, true), "closing during Exit cannot hide the cleanup result");
        release.SetResult(); await quit;
        check(lifetime.CanClose && events.SequenceEqual(new[] { "hide", "cancel-work", "disconnect-drive", "exit" }),
            "Exit disconnects the drive after active work settles and before terminating");
        int attempts = 0, finishes = 0;
        var retry = new DesktopLifetime(() => { }, () => ++attempts == 1 ? Task.FromException(new IOException("busy drive")) : Task.CompletedTask, () => finishes++);
        bool failed = false; try { await retry.ExitAsync(); } catch (IOException) { failed = true; }
        check(failed && !retry.IsExiting && !retry.CanClose && finishes == 0,
            "failed disconnect leaves the application running and permits a retry");
        await retry.ExitAsync(); check(retry.CanClose && attempts == 2 && finishes == 1, "a subsequent Exit retries cleanup once");

        string name = "Cloudlane.Checks.Show." + Guid.NewGuid().ToString("N"); int shown = 0;
        var activation = new InstanceActivation(name, () => Interlocked.Increment(ref shown));
        try
        {
            check(await InstanceActivation.ShowExistingAsync(name) && shown == 1, "a second launch signals the existing instance over the current-user pipe");
            check(await InstanceActivation.ShowExistingAsync(name) && shown == 2, "the instance continues accepting restore requests after the first launch");
            using (var invalid = new NamedPipeClientStream(".", name, PipeDirection.InOut, PipeOptions.Asynchronous | PipeOptions.CurrentUserOnly))
            {
                using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(4));
                await invalid.ConnectAsync(deadline.Token); await invalid.WriteAsync(new byte[] { 99 }, deadline.Token);
                byte[] reply = new byte[1];
                int replyLength = await invalid.ReadAsync(reply, deadline.Token);
                check(replyLength == 0, "unknown activation messages receive no success acknowledgement");
            }
            check(shown == 2 && await InstanceActivation.ShowExistingAsync(name) && shown == 3,
                "unknown activation messages do not show a window or break later activation");
        }
        finally { activation.Dispose(); }
        await activation.Completion.WaitAsync(TimeSpan.FromSeconds(4));
        check(activation.Completion.IsCompletedSuccessfully, "exit stops the activation listener without a background exception");
    }
    private sealed class MemoryStartupStore : IStartupStore
    {
        public string? Command; public int Writes, Removes; public bool FailWrites;
        public string? Read() => Command;
        public void Write(string command) { if (FailWrites) throw new UnauthorizedAccessException("fixture"); Command = command; Writes++; }
        public void Remove() { Command = null; Removes++; }
    }
}
