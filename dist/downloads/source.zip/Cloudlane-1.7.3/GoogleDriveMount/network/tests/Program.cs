using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Cloudlane;
using Cloudlane.Mount;
using SMBLibrary;
using SMBLibrary.Server;
using SMBLibrary.Authentication.GSSAPI;
using SMBLibrary.Authentication.NTLM;

CheckProcess.DisableCrashDialog();
int passed=0;
void Check(bool value,string name){if(!value)throw new Exception(name);passed++;Console.WriteLine("PASS "+name);}
BundledClientChecks.Run(Check);
if(args.Contains("--multi-account-only"))
{
 await MultiAccountChecks.RunAsync(Check);
 await StartupConnectionChecks.RunAsync(Check);
 await DesktopWindowChecks.RunAsync(Check);
 Console.WriteLine($"{passed} targeted multi-account checks passed; Google HTTP is simulated.");
 return;
}
if(args.Contains("--cache-only"))
{
 var cachedSettings = new Settings { AccountId = new string('A',64) };
 string cachedToken = JsonSerializer.Serialize(new { access_token = "cache-test", refresh_token = "refresh", expiry = DateTimeOffset.UtcNow.AddHours(1).ToString("O") });
 if(!args.Contains("--folder-browse-only")) await MediaCacheChecks.RunAsync(Check,cachedSettings,cachedToken);
 await FolderBrowseChecks.RunAsync(Check,cachedSettings,cachedToken);
 Console.WriteLine($"{passed} targeted cache checks passed; Google HTTP is simulated.");
 return;
}
HttpResponseMessage Json(object value,HttpStatusCode code=HttpStatusCode.OK)=>new(code){Content=new StringContent(JsonSerializer.Serialize(value),Encoding.UTF8,"application/json")};
object Meta(string id,long size,string hash="")=>new{id,name="original.bin",mimeType="application/octet-stream",size=size.ToString(),version="1",modifiedTime="2026-10-16T00:00:00Z",md5Checksum=hash,parents=new[]{"parent"}};
HttpResponseMessage Partial(long count){var r=new HttpResponseMessage((HttpStatusCode)308);if(count>0)r.Headers.TryAddWithoutValidation("Range","bytes=0-"+(count-1));return r;}
HttpResponseMessage Session(){var r=Json(new{});r.Headers.Location=new Uri("https://www.googleapis.com/upload/test-session");return r;}
string token=JsonSerializer.Serialize(new{access_token="test-token",refresh_token="test-refresh",expiry=DateTimeOffset.UtcNow.AddHours(1).ToString("O")});
var options=new Settings{ClientId="test.apps.googleusercontent.com",ClientSecret="test",AccountId=new string('A',64)};
string root=Path.Combine(AppContext.BaseDirectory,"source-fixtures");Directory.CreateDirectory(root);
string source=Path.Combine(root,"original.bin");
int size=GoogleDriveApi.UploadBufferSize*2+123;
using(var f=new FileStream(source,FileMode.Create,FileAccess.Write)){byte[] block=Enumerable.Range(0,65536).Select(i=>(byte)(i%251)).ToArray();for(int remaining=size;remaining>0;remaining-=Math.Min(remaining,block.Length))f.Write(block,0,Math.Min(remaining,block.Length));}
string originalHash=await GoogleDriveApi.HashAsync(source,CancellationToken.None);long originalTicks=File.GetLastWriteTimeUtc(source).Ticks;
var before=Directory.GetFiles(AppContext.BaseDirectory,"*",SearchOption.AllDirectories).OrderBy(x=>x).ToArray();
var job=new UploadJob{Source=source,Name="original.bin",ParentRemoteId="parent"};long received=0;int maxBuffer=0,chunks=0,saves=0;using var serverHash=IncrementalHash.CreateHash(HashAlgorithmName.MD5);
using(var api=new GoogleDriveApi(options,new FakeHandler(async(req,n)=>{
 Check(req.Headers.Authorization?.Parameter=="test-token","upload requests use the Google OAuth token");
 if(req.RequestUri!.AbsolutePath.EndsWith("generateIds"))return Json(new{ids=new[]{"new-id"}});
 if(req.Method==HttpMethod.Post){Check(saves>0,"generated upload ID is persisted before creating session");return Session();}
 byte[] data=await req.Content!.ReadAsByteArrayAsync();var range=req.Content.Headers.ContentRange!;
 Check(range.From==received&&range.To==received+data.Length-1&&range.Length==size,"upload chunk has the exact source byte range");
 Check(data.Length<=GoogleDriveApi.UploadBufferSize,"upload request stays within the 4 MiB buffer bound");
 if(chunks==0){bool protectedSource=false;try{using var writer=new FileStream(source,FileMode.Open,FileAccess.Write,FileShare.ReadWrite);}catch(IOException){protectedSource=true;}Check(protectedSource,"original is protected against concurrent edits while uploading");}
 chunks++;maxBuffer=Math.Max(maxBuffer,data.Length);received+=data.Length;serverHash.AppendData(data);
 return received<size?Partial(received):Json(Meta("new-id",size,Convert.ToHexString(serverHash.GetCurrentHash()).ToLowerInvariant()));
}),token)){
 var uploaded=await api.UploadOriginalAsync(job,"parent",()=>saves++,null,CancellationToken.None);Check(uploaded.Id=="new-id"&&received==size&&chunks==3,"multi-chunk upload completes directly from the original file");
}
Check(Convert.ToHexString(serverHash.GetHashAndReset()).ToLowerInvariant()==originalHash,"server receives the original file's exact contents");
Check(await GoogleDriveApi.HashAsync(source,CancellationToken.None)==originalHash&&File.GetLastWriteTimeUtc(source).Ticks==originalTicks,"upload leaves source contents and last-write timestamp unchanged");
var after=Directory.GetFiles(AppContext.BaseDirectory,"*",SearchOption.AllDirectories).OrderBy(x=>x).ToArray();Check(before.SequenceEqual(after),"direct upload creates no additional local files or staging copies");
Check(saves>=4&&job.Session.Length>0,"only upload-session metadata is persisted by the upload callback");
// Resume a server-confirmed prefix without uploading that prefix again.
long prefix=GoogleDriveApi.UploadBufferSize, resumedBytes=0;int queries=0;
var resume=new UploadJob{Source=source,Name="original.bin",RemoteId="resume-id",Session="https://www.googleapis.com/upload/test-session",SourceSize=size,SourceTicks=originalTicks};
using(var api=new GoogleDriveApi(options,new FakeHandler(async(req,n)=>{
 var range=req.Content!.Headers.ContentRange!;
 if(range.From==null){queries++;return Partial(prefix);}
 Check(range.From==prefix+resumedBytes,"resumed upload begins after Google's confirmed bytes");byte[] bytes=await req.Content.ReadAsByteArrayAsync();resumedBytes+=bytes.Length;
 return prefix+resumedBytes<size?Partial(prefix+resumedBytes):Json(Meta("resume-id",size));
}),token)){
 await api.UploadOriginalAsync(resume,"parent",()=>{},null,CancellationToken.None);Check(queries==1&&resumedBytes==size-prefix,"resuming reads remaining bytes from the original without a disk cache");
}
// Lost connection after Google accepted a prefix: query state, then continue safely.
long accepted=0;bool interrupted=false;int recoveryQueries=0;
var recover=new UploadJob{Source=source,Name="original.bin",RemoteId="recover-id",Session="https://www.googleapis.com/upload/test-session",SourceSize=size,SourceTicks=originalTicks};
using(var api=new GoogleDriveApi(options,new FakeHandler(async(req,n)=>{
 var range=req.Content!.Headers.ContentRange!;
 if(range.From==null){recoveryQueries++;return Partial(accepted);}
 if(!interrupted){interrupted=true;accepted=2*1024*1024;throw new HttpRequestException("simulated interrupted network");}
 Check(range.From==accepted,"network recovery uses the server's acknowledged offset");accepted+=(await req.Content.ReadAsByteArrayAsync()).Length;
 return accepted<size?Partial(accepted):Json(Meta("recover-id",size));
}),token)){
 await api.UploadOriginalAsync(recover,"parent",()=>{},null,CancellationToken.None);Check(recoveryQueries==2&&accepted==size,"interrupted upload queries Google and continues without staging");
}
// Zero-byte files finalize with an empty body.
string empty=Path.Combine(root,"empty.txt");File.WriteAllText(empty,"");var emptyJob=new UploadJob{Source=empty,Name="empty.txt"};
using(var api=new GoogleDriveApi(options,new FakeHandler(async(req,n)=>{
 if(req.RequestUri!.AbsolutePath.EndsWith("generateIds"))return Json(new{ids=new[]{"empty-id"}});
 if(req.Method==HttpMethod.Post)return Session();
 Check((await req.Content!.ReadAsByteArrayAsync()).Length==0&&req.Content.Headers.ContentRange!.Length==0,"empty source uploads without fabricated file bytes");return Json(Meta("empty-id",0));
}),token)){await api.UploadOriginalAsync(emptyJob,"parent",()=>{},null,CancellationToken.None);}
// A different source version must never be mixed into an old partial upload.
var changed=new UploadJob{Source=source,Name="original.bin",RemoteId="old-id",Session="https://www.googleapis.com/upload/test-session",SourceSize=size+1,SourceTicks=originalTicks};int unexpectedCalls=0;
using(var api=new GoogleDriveApi(options,new FakeHandler((req,n)=>{unexpectedCalls++;return Task.FromResult(Json(new{}));}),token)){
 bool rejected=false;try{await api.UploadOriginalAsync(changed,"parent",()=>{},null,CancellationToken.None);}catch(IOException){rejected=true;}
 Check(rejected&&unexpectedCalls==0,"changed originals cannot resume into an old upload session");
}
// An invalid completion is never treated as success.
var invalid=new UploadJob{Source=empty,Name="empty.txt"};
using(var api=new GoogleDriveApi(options,new FakeHandler((req,n)=>Task.FromResult(req.RequestUri!.AbsolutePath.EndsWith("generateIds")?Json(new{ids=new[]{"expected-id"}}):req.Method==HttpMethod.Post?Session():Json(Meta("wrong-id",0)))),token)){
 bool rejected=false;try{await api.UploadOriginalAsync(invalid,"parent",()=>{},null,CancellationToken.None);}catch(IOException){rejected=true;}Check(rejected,"wrong Google completion identity is rejected");
}
// Folder planning records references and hierarchy, never file contents.
string directory=Path.Combine(root,"folder");Directory.CreateDirectory(Path.Combine(directory,"nested"));File.WriteAllText(Path.Combine(directory,"nested","note.txt"),"source only");
var treeBefore=Directory.GetFiles(root,"*",SearchOption.AllDirectories).OrderBy(x=>x).ToArray();var plan=UploadQueue.Plan(new[]{directory},"parent","My Drive");
Check(plan.Count==3&&plan[1].ParentJobKey==plan[0].Key&&plan[2].ParentJobKey==plan[1].Key,"folder uploads preserve parent dependencies");
Check(treeBefore.SequenceEqual(Directory.GetFiles(root,"*",SearchOption.AllDirectories).OrderBy(x=>x)),"planning folder uploads writes no file copies");
Check(plan.All(j=>File.Exists(j.Source)||Directory.Exists(j.Source)),"queued jobs reference the originals");
// Pausing preserves only the session reference, and releases the original handle.
using(var pauseSource=new CancellationTokenSource())
{
 var pausedJob=new UploadJob{Source=empty,Name="empty.txt",RemoteId="paused-id",Session="https://www.googleapis.com/upload/test-session",SourceSize=0,SourceTicks=File.GetLastWriteTimeUtc(empty).Ticks,ParentRemoteId="parent"};
 var pausedQueue=new UploadQueue();pausedQueue.Jobs.Add(pausedJob);int metadataWrites=0;
 using var api=new GoogleDriveApi(options,new FakeHandler((req,n)=>{
  if(n==1)return Task.FromResult(Partial(0));pauseSource.Cancel();throw new OperationCanceledException(pauseSource.Token);
 }),token);
 bool stopped=false;try{await UploadCoordinator.RunAsync(pausedQueue,api,()=>metadataWrites++,null,pauseSource.Token);}catch(OperationCanceledException){stopped=true;}
 Check(stopped&&!pausedJob.Complete&&pausedJob.State=="Paused"&&pausedJob.Session.Length>0,"pause retains the upload reference without declaring success");
 using(var writable=new FileStream(empty,FileMode.Open,FileAccess.Write,FileShare.ReadWrite))Check(writable.Length==0,"pause releases the original source handle");
 Check(metadataWrites>0,"pause persists queue metadata for a later retry");
}
// The coordinator creates cloud folders before sending each child directly.
var folderQueue=new UploadQueue();folderQueue.Jobs.AddRange(UploadQueue.Plan(new[]{directory},"parent","My Drive"));int generated=0;string[] ids={"folder-root","folder-nested","note-id"};
using(var api=new GoogleDriveApi(options,new FakeHandler(async(req,n)=>{
 if(req.RequestUri!.AbsolutePath.EndsWith("generateIds"))return Json(new{ids=new[]{ids[generated++]}});
 if(req.Method==HttpMethod.Post){using var meta=JsonDocument.Parse(await req.Content!.ReadAsStringAsync());var body=meta.RootElement;
  if(req.RequestUri.AbsolutePath.StartsWith("/upload/")){Check(body.GetProperty("parents")[0].GetString()=="folder-nested","file upload targets its newly created nested cloud folder");return Session();}
  string id=body.GetProperty("id").GetString()!;return Json(new{id,name=body.GetProperty("name").GetString(),mimeType="application/vnd.google-apps.folder",size="0",parents=new[]{id=="folder-root"?"parent":"folder-root"}});
 }
 Check(await req.Content!.ReadAsStringAsync()=="source only","folder queue reads the existing child file directly");return Json(Meta("note-id",11));
}),token)){
 await UploadCoordinator.RunAsync(folderQueue,api,()=>{},null,CancellationToken.None);Check(folderQueue.Jobs.All(j=>j.Complete)&&generated==3,"folder hierarchy and child upload finish in dependency order");
}
// Destination browsing fetches a folder's children and sorts folders first.
using(var api=new GoogleDriveApi(options,new FakeHandler((req,n)=>{
 Check(Uri.UnescapeDataString(req.RequestUri!.Query).Contains("'chosen-folder' in parents"),"Drive browser lists the selected destination folder");
 return Task.FromResult(Json(new{files=new[]{new{id="f",name="file.txt",mimeType="text/plain",size="1"},new{id="d",name="Folder",mimeType="application/vnd.google-apps.folder",size="0"}}}));
}),token)){var list=await api.ListFolderAsync("chosen-folder",CancellationToken.None);Check(list[0].IsDirectory&&list.Count==2,"Drive folders appear before files");}
Check(!Directory.Exists(Path.Combine(AppContext.BaseDirectory,"engine")),"no external filesystem engine is needed");

// Setup rejects credentials for the wrong client type and malformed downloads.
var desktop=Settings.ParseClient("{\"installed\":{\"client_id\":\"123.apps.googleusercontent.com\",\"client_secret\":\"desktop-secret\"}}");
Check(desktop.Id=="123.apps.googleusercontent.com","Desktop client configuration parses without signing in");
foreach(string bad in new[]{"not json","[]","{\"web\":{}}","{\"installed\":{}}","{\"installed\":{\"client_id\":7,\"client_secret\":\"x\"}}","{\"installed\":{\"client_id\":\"wrong.example.com\",\"client_secret\":\"x\"}}"})
{
 bool rejected=false;try{Settings.ParseClient(bad);}catch(InvalidOperationException){rejected=true;}
 Check(rejected,"invalid or wrong-type OAuth configuration gives a setup error");
}
// Folder snapshots and cancellation prevent uploading unexpected later changes.
var deduplicated=UploadQueue.Plan(new[]{directory,directory,Path.Combine(directory,"nested","note.txt")},"parent","My Drive");
Check(deduplicated.Count==3,"overlapping selections queue each original once");
Check(deduplicated.Single(j=>!j.IsFolder).SourceSize==11,"folder planning records the original file version at selection time");
using(var cancelPlan=new CancellationTokenSource())
{
 cancelPlan.Cancel();bool stopped=false;try{UploadQueue.Plan(new[]{directory},"parent","My Drive",cancelPlan.Token);}catch(OperationCanceledException){stopped=true;}
 Check(stopped,"large folder planning can be cancelled before uploads begin");
}
bool rootRejected=false;try{UploadQueue.Plan(new[]{Path.GetPathRoot(source)!},"parent","My Drive");}catch(IOException){rootRejected=true;}
Check(rootRejected,"whole-drive selection is rejected before recursively scanning the disk");
// Clearing finished parents keeps unfinished children pointed to the cloud folder.
var clearing=new UploadQueue();var doneParent=new UploadJob{IsFolder=true,Complete=true,RemoteId="existing-folder"};
var waitingChild=new UploadJob{ParentJobKey=doneParent.Key};clearing.Jobs.AddRange(new[]{doneParent,waitingChild});clearing.ClearCompleted();
Check(clearing.Jobs.Count==1&&waitingChild.ParentJobKey==""&&waitingChild.ParentRemoteId=="existing-folder","clearing completed folders preserves pending child destinations");
// Browsing handles all pages rather than silently hiding later destinations.
int pages=0;
using(var api=new GoogleDriveApi(options,new FakeHandler((req,n)=>{
 pages++;if(n==1)return Task.FromResult(Json(new{nextPageToken="second-page",files=new[]{new{id="one",name="a",mimeType="text/plain"}}}));
 Check(req.RequestUri!.Query.Contains("pageToken=second-page"),"folder pagination sends Google's next-page token");
 return Task.FromResult(Json(new{files=new[]{new{id="two",name="b",mimeType="text/plain"}}}));
}),token))Check((await api.ListFolderAsync("parent",CancellationToken.None)).Count==2&&pages==2,"all destination pages are included");
// Permanent quota errors stay actionable; transient rate errors are retried.
using(var api=new GoogleDriveApi(options,new FakeHandler((req,n)=>Task.FromResult(Json(new{error=new{errors=new[]{new{reason="storageQuotaExceeded"}}}},HttpStatusCode.Forbidden))),token))
{
 bool clearError=false;try{await api.GetAsync("file",CancellationToken.None);}catch(DriveException ex){clearError=ex.Message.Contains("storage is full");}
 Check(clearError,"full Google storage has an actionable error");
}
int limitedCalls=0;
using(var api=new GoogleDriveApi(options,new FakeHandler((req,n)=>{
 limitedCalls++;return Task.FromResult(n==1?Json(new{error=new{errors=new[]{new{reason="userRateLimitExceeded"}}}},HttpStatusCode.Forbidden):Json(Meta("file",0)));
}),token))Check((await api.GetAsync("file",CancellationToken.None)).Id=="file"&&limitedCalls==2,"transient Google rate limits retry without discarding queue state");
// A transport timeout follows the same server-query recovery as a lost connection.
var timed=new UploadJob{Source=empty,Name="empty.txt",RemoteId="timeout-id",Session="https://www.googleapis.com/upload/test-session",SourceSize=0,SourceTicks=File.GetLastWriteTimeUtc(empty).Ticks};
using(var api=new GoogleDriveApi(options,new FakeHandler((req,n)=>{
 if(n==1)return Task.FromResult(Partial(0));if(n==2)throw new TaskCanceledException("simulated HTTP timeout");return Task.FromResult(Json(Meta("timeout-id",0)));
}),token))Check((await api.UploadOriginalAsync(timed,"parent",()=>{},null,CancellationToken.None)).Id=="timeout-id","network timeout checks Google for completion before retrying bytes");
// A persisted session must never send account tokens to an arbitrary host.
var untrusted=new UploadJob{Source=empty,Name="empty.txt",RemoteId="id",Session="https://example.com/stolen",SourceSize=0,SourceTicks=File.GetLastWriteTimeUtc(empty).Ticks};int foreignCalls=0;
using(var api=new GoogleDriveApi(options,new FakeHandler((req,n)=>{foreignCalls++;return Task.FromResult(Json(new{}));}),token))
{
 bool rejected=false;try{await api.UploadOriginalAsync(untrusted,"parent",()=>{},null,CancellationToken.None);}catch(IOException){rejected=true;}
 Check(rejected&&foreignCalls==0,"untrusted session hosts are rejected before transmitting OAuth tokens");
}

// Stream files by exact byte range; a 6 GiB logical source never exists as a local payload.
var streamFilesBefore=Directory.GetFiles(AppContext.BaseDirectory,"*",SearchOption.AllDirectories).OrderBy(x=>x).ToArray();
long virtualSize=6L*1024*1024*1024;long readBytes=0;int rangeCalls=0;
var virtualMeta=DriveFile.Parse(JsonSerializer.SerializeToElement(Meta("video",virtualSize)));
using(var api=new GoogleDriveApi(options,new FakeHandler((req,n)=>{
 var requested=req.Headers.Range!.Ranges.Single();long from=requested.From!.Value,to=requested.To!.Value;
 Check(req.RequestUri!.Query.Contains("alt=media")&&req.Headers.Authorization?.Parameter=="test-token","streaming reads use authenticated Google media requests");
 byte[] bytes=Enumerable.Range(0,(int)(to-from+1)).Select(i=>(byte)((from+i)%251)).ToArray();readBytes+=bytes.Length;rangeCalls++;
 var response=new HttpResponseMessage(HttpStatusCode.PartialContent){Content=new ByteArrayContent(bytes)};
 response.Content.Headers.ContentRange=new System.Net.Http.Headers.ContentRangeHeaderValue(from,to,virtualSize);return Task.FromResult(response);
}),token))
{
 foreach(long offset in new[]{0L,virtualSize-1024,100000000L,4000000000L})
 {
  byte[] block=await api.ReadRangeAsync(virtualMeta,offset,1024,CancellationToken.None);
  Check(block.Length==1024&&block.Select((b,i)=>b==(byte)((offset+i)%251)).All(v=>v),"video seeking reads only the requested original byte range");
 }
 Check(rangeCalls==4&&readBytes==4096,"seeking in a 6 GiB source fetches 4 KiB without downloading its prefix");
}
using(var api=new GoogleDriveApi(options,new FakeHandler((req,n)=>Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK){Content=new ByteArrayContent(new byte[1024])})),token))
{
 bool rejected=false;try{await api.ReadRangeAsync(virtualMeta,100,1024,CancellationToken.None);}catch(IOException){rejected=true;}
 Check(rejected,"a server ignoring byte ranges is rejected instead of secretly downloading a whole file");
}
// Windows directory and file information encodings used by Explorer and media applications.
var testTree=new VirtualTree();var smbStore=new CloudFileStore(testTree);
Check(smbStore.CreateFile(out var dirHandle,out _,"\\",AccessMask.GENERIC_READ,0,ShareAccess.Read,CreateDisposition.FILE_OPEN,CreateOptions.FILE_DIRECTORY_FILE,null!)==NTStatus.STATUS_SUCCESS,"Explorer root can be opened through the virtual file store");
foreach(var cls in new[]{FileInformationClass.FileDirectoryInformation,FileInformationClass.FileBothDirectoryInformation,FileInformationClass.FileFullDirectoryInformation,FileInformationClass.FileIdBothDirectoryInformation,FileInformationClass.FileIdFullDirectoryInformation,FileInformationClass.FileNamesInformation})
{
 var status=smbStore.QueryDirectory(out var entries,dirHandle,"*",cls);var encoded=QueryDirectoryFileInformation.GetBytes(entries);
 Check(status==NTStatus.STATUS_SUCCESS&&entries.Count==3&&encoded.Length>0,"Explorer directory information serializes correctly: "+cls);
}
Check(smbStore.CreateFile(out var readHandle,out _,"\\video.mp4",AccessMask.GENERIC_READ,0,ShareAccess.Read,CreateDisposition.FILE_OPEN,0,null!)==NTStatus.STATUS_SUCCESS,"cloud media can be opened as a normal SMB file");
foreach(var cls in new[]{FileInformationClass.FileBasicInformation,FileInformationClass.FileStandardInformation,FileInformationClass.FileInternalInformation,FileInformationClass.FileNetworkOpenInformation,FileInformationClass.FileAllInformation,FileInformationClass.FileNameInformation,FileInformationClass.FileAttributeTagInformation})
{
 Check(smbStore.GetFileInformation(out var info,readHandle,cls)==NTStatus.STATUS_SUCCESS,"media file metadata is available: "+cls);info.WriteBytes(new byte[info.Length],0);
}
Check(smbStore.ReadFile(out var tail,readHandle,virtualSize-1024,4*1024*1024)==NTStatus.STATUS_SUCCESS&&tail.Length==1024,"SMB read supports offsets beyond 4 GiB and clamps to end of file");
Check(smbStore.ReadFile(out var bounded,readHandle,0,4*1024*1024)==NTStatus.STATUS_SUCCESS&&bounded.Length==1024*1024,"each SMB source read stays within a 1 MiB memory bound");
Check(smbStore.CreateFile(out _,out _,"\\video.mp4",AccessMask.GENERIC_WRITE,0,ShareAccess.Write,CreateDisposition.FILE_OPEN,0,null!)==NTStatus.STATUS_MEDIA_WRITE_PROTECTED,"mapped drive refuses edits rather than staging hidden content");
Check(smbStore.WriteFile(out _,readHandle,0,new byte[1])==NTStatus.STATUS_MEDIA_WRITE_PROTECTED,"mapped drive cannot modify Google files through a read handle");
Check(GoogleTree.Normalize("\\folder\\..\\video.mp4")=="\\video.mp4","Explorer relative paths normalize within the drive");
bool escaped=false;try{GoogleTree.Normalize("\\..\\outside");}catch(FileNotFoundException){escaped=true;}Check(escaped,"virtual paths cannot escape the Drive root");
// The elevated mapping helper accepts only constrained local drive requests.
var mapRequest=new MountRequest("G:",17445,"Cloudlane_"+new string('A',16),"Cloudlane",new string('B',64),"S-1-5-21-1-2-3-1000");
WindowsMapping.Validate(mapRequest);
foreach(var bad in new[]{mapRequest with{Letter="C:"},mapRequest with{Share="some-other-share"},mapRequest with{Port=445},mapRequest with{Password="bad"},mapRequest with{User="Guest"}})
{
 bool rejected=false;try{WindowsMapping.Validate(bad);}catch(IOException){rejected=true;}Check(rejected,"mapping helper rejects an invalid or unrelated target");
}
// Actual loopback SMB authentication, signing, enumeration and range reads (no Google account).
var failedMapping=await MapperScriptChecks.RunAsync(true);
Console.WriteLine($"Mapper fixture: OK={failedMapping.Ok}, lookups={failedMapping.Reads}, error={failedMapping.Error}; {string.Join("; ",failedMapping.Diagnostics)}");
Check(!failedMapping.Ok&&failedMapping.Error.Contains("Simulated native mapper failure")&&failedMapping.Reads==1,"Windows mapper stops after the original error, without a misleading second lookup");
Check(failedMapping.Diagnostics.Any(x=>x.Contains("TCP connection passed"))&&failedMapping.Diagnostics.Any(x=>x.Contains("SMB client policy")),"mapper failure includes elevated TCP check and read-only policy details");
Check(!string.Join("",failedMapping.Diagnostics).Contains(new string('B',64)),"mapper diagnostic output excludes the temporary credential");
var successfulMapping=await MapperScriptChecks.RunAsync(false);
Check(successfulMapping.Ok&&successfulMapping.Reads==2,"Windows mapper script verifies the retained mapping after success");
using(var listener=new System.Net.Sockets.TcpListener(LocalSmbEndpoint.Address,0))
{
 listener.Start();int tcpPort=((IPEndPoint)listener.LocalEndpoint).Port;listener.Stop();
 var shareList=new SMBShareCollection();shareList.Add(new FileSystemShare("Cloudlane",new CloudFileStore(testTree),CachingPolicy.NoCaching));
 var smbServer=new TestServer(shareList,new GSSProvider(new CloudlaneAuthentication("temporary-test-password")));
 smbServer.Listen(tcpPort);
 try
 {
  var badClient=new TestSmbClient();Check(badClient.Link(tcpPort),"loopback SMB listener accepts a protocol connection");
  Check(badClient.Login("","Cloudlane","wrong-password")!=NTStatus.STATUS_SUCCESS,"SMB rejects the wrong local session credential");badClient.Disconnect();
  var client=new TestSmbClient();Check(client.Link(tcpPort)&&client.Login("CLOUDLANE","CLOUDLANE","temporary-test-password")==NTStatus.STATUS_SUCCESS,"signed SMB authentication succeeds without an external driver");
  await LocalSmbEndpoint.CheckAsync(tcpPort,"Cloudlane","temporary-test-password",CancellationToken.None);
  Check(true,"production preflight verifies signed authentication and root access on the actual listener");
  bool badPreflight=false;try{await LocalSmbEndpoint.CheckAsync(tcpPort,"Cloudlane","wrong-password",CancellationToken.None);}catch(IOException){badPreflight=true;}
  Check(badPreflight,"production preflight rejects a failed local authentication before Windows mapping");
  var share=client.TreeConnect("Cloudlane",out var status);Check(status==NTStatus.STATUS_SUCCESS,"authenticated SMB share connects");
  Check(share.CreateFile(out var rootHandle,out _,"",AccessMask.GENERIC_READ,0,ShareAccess.Read,CreateDisposition.FILE_OPEN,CreateOptions.FILE_DIRECTORY_FILE,null!)==NTStatus.STATUS_SUCCESS,"signed SMB client opens the root directory");
  Check(share.QueryDirectory(out var listed,rootHandle,"*",FileInformationClass.FileIdBothDirectoryInformation)==NTStatus.STATUS_NO_MORE_FILES&&listed.Cast<FileIdBothDirectoryInformation>().Any(f=>f.FileName=="video.mp4"),"signed SMB directory enumeration returns the cloud video");share.CloseFile(rootHandle);
  Check(share.CreateFile(out var video,out _,"video.mp4",AccessMask.GENERIC_READ,0,ShareAccess.Read,CreateDisposition.FILE_OPEN,0,null!)==NTStatus.STATUS_SUCCESS,"SMB client opens virtual video metadata");
  Check(share.ReadFile(out var bytes,video,virtualSize-2048,1024)==NTStatus.STATUS_SUCCESS&&bytes.Length==1024&&bytes[0]==(byte)((virtualSize-2048)%251),"signed SMB reads an arbitrary range of a 6 GiB virtual video");
  share.CloseFile(video);share.Disconnect();client.Logoff();client.Disconnect();
 }
 finally{smbServer.Stop();}
}
Check(streamFilesBefore.SequenceEqual(Directory.GetFiles(AppContext.BaseDirectory,"*",SearchOption.AllDirectories).OrderBy(x=>x)),"range reads and actual SMB streaming create no local payload files");

// A valid empty root must count as mounted; Directory.Exists hides SMB/Win32 errors.
string probeFolder=Path.Combine(root,"mount-probe-empty");Directory.CreateDirectory(probeFolder);
await ExplorerMount.ProbeDirectoryAsync(probeFolder,"test root",CancellationToken.None);
Check(!Directory.EnumerateFileSystemEntries(probeFolder).Any(),"mount probe accepts an accessible empty directory");
string absent=Path.Combine(probeFolder,"not-present");bool realCode=false;
try{await ExplorerMount.ProbeDirectoryAsync(absent,"test root",CancellationToken.None);}catch(IOException ex){realCode=ex.Message.Contains("error 3:")&&ex.Message.Contains("test root");}
Check(realCode,"failed mount probe reports the actual Windows path error instead of a visibility guess");
Check(ExplorerDriveAlias.MakeTarget("Cloudlane_"+new string('A',16))==@"\Device\Mup\127.0.0.1\Cloudlane_"+new string('A',16),"desktop drive alias targets only the owned loopback share");
bool badAlias=false;try{ExplorerDriveAlias.MakeTarget("another-server");}catch(IOException){badAlias=true;}Check(badAlias,"drive alias rejects arbitrary remote targets");
var trace=new MountTrace();trace.Add("Create: Opened 'private-file-name.jpg' for user 'private-name'.");
Check(!trace.Text.Contains("private-file-name")&&!trace.Text.Contains("private-name"),"support diagnostics omit quoted file and account names");
trace.Add("Mount lifecycle marker");
for(int i=0;i<300;i++)trace.AddProtocol("Protocol fixture "+i);
Check(trace.Text.Contains("Mount lifecycle marker")&&!trace.Text.Contains("Protocol fixture 0\n")&&trace.Text.Contains("Protocol fixture 299"),"busy Explorer protocol traffic cannot evict the bounded mount lifecycle history");
string ownedShare="Cloudlane_"+new string('A',16);
var networkApi=new FakeNetworkDriveApi();
var networkDrive=new ExplorerNetworkDrive("G:",ownedShare,networkApi);
Check(networkDrive.Registered&&networkApi.Current==LocalSmbEndpoint.Remote(ownedShare),"Explorer drive registration retains the exact owned local share");
networkDrive.Dispose();networkDrive.Dispose();
Check(networkApi.Removes==1&&networkApi.Current==null,"network drive disconnect removes its owned letter only once");
var occupiedApi=new FakeNetworkDriveApi{Occupied=true}; bool occupiedRejected=false;
try{new ExplorerNetworkDrive("G:",ownedShare,occupiedApi);}catch(IOException){occupiedRejected=true;}
Check(occupiedRejected&&occupiedApi.Adds==0,"existing drive letters are rejected before calling the Windows network mapper");
var failedNetworkApi=new FakeNetworkDriveApi{AddError=85};bool nativeErrorPreserved=false;
try{new ExplorerNetworkDrive("G:",ownedShare,failedNetworkApi);}catch(System.ComponentModel.Win32Exception ex){nativeErrorPreserved=ex.NativeErrorCode==85;}
Check(nativeErrorPreserved&&failedNetworkApi.Removes==0,"failed network registration reports the actual Windows error without disconnecting an unrelated drive");
var replacedApi=new FakeNetworkDriveApi();var replacedDrive=new ExplorerNetworkDrive("G:",ownedShare,replacedApi);replacedApi.Current=@"\\another-server\other-share";replacedDrive.Dispose();
Check(replacedApi.Removes==0&&replacedApi.Current==@"\\another-server\other-share","cleanup preserves a drive replaced by another application");
var retryApi=new FakeNetworkDriveApi();var retryDrive=new ExplorerNetworkDrive("G:",ownedShare,retryApi);retryApi.RemoveError=2401;bool cleanupError=false;
try{retryDrive.Dispose();}catch(System.ComponentModel.Win32Exception){cleanupError=true;}
retryApi.RemoveError=0;retryDrive.Dispose();
Check(cleanupError&&retryApi.Removes==2&&retryApi.Current==null,"a failed Windows network disconnect can be retried");
if(!args.Contains("--skip-device-namespace"))
{
 string freeLetter=Enumerable.Range('D',23).Reverse().Select(c=>((char)c)+":").First(l=>!ExplorerMount.LetterInUse(l));
 using(var localAlias=new ExplorerDriveAlias(freeLetter,@"\??\"+probeFolder,false))
 {
  await ExplorerMount.ProbeDirectoryAsync(freeLetter+"\\","local alias",CancellationToken.None);
  Check(ExplorerDriveAlias.Target(freeLetter)==@"\??\"+probeFolder,"Windows creates the letter in the calling desktop namespace");
 }
 Check(ExplorerDriveAlias.Target(freeLetter)==null,"drive cleanup removes only its exact owned alias");
 Check(ExplorerNetworkDrive.RegisteredRemote(freeLetter)==null,"native Windows network-provider query accepts a free letter without creating a connection");
}
else Console.WriteLine("SKIP local DOS-device namespace check: explicitly disabled for this restricted session.");
await ExplorerUploadChecks.RunAsync(Check,options,token,source);
await ExplorerDeleteChecks.RunAsync(Check,options,token);
await DesktopChecks.RunAsync(Check);
await AppearanceChecks.RunAsync(Check,options,token);
await ReadPerformanceChecks.RunAsync(Check,options,token);
await MediaCacheChecks.RunAsync(Check,options,token);
await FolderBrowseChecks.RunAsync(Check,options,token);
await MultiAccountChecks.RunAsync(Check);
await StartupConnectionChecks.RunAsync(Check);
await DesktopWindowChecks.RunAsync(Check);
if(!args.Contains("--skip-dpapi"))
{
 byte[] plain=Encoding.UTF8.GetBytes("Cloudlane local encryption self-check");byte[] encrypted=SecretStore.Transform(plain,true);
 Check(!encrypted.SequenceEqual(plain)&&SecretStore.Transform(encrypted,false).SequenceEqual(plain),"Windows user encryption round-trips metadata without plaintext storage");
}
else Console.WriteLine("SKIP Windows DPAPI check: explicitly disabled for the restricted build profile. Verify from a normal Windows account.");
Console.WriteLine($"{passed} checks passed. Tests use fake Google HTTP responses; live Google authorization and uploads still require user-account verification.");
sealed class FakeHandler(Func<HttpRequestMessage,int,Task<HttpResponseMessage>> handler):HttpMessageHandler{int count;protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken cancellationToken)=>handler(request,++count);}

sealed class VirtualTree:ICloudTree
{
 public long TotalBytes=>6L*1024*1024*1024; public long FreeBytes=>0;
 public CloudNode Resolve(string path)=>path.Trim('\\') switch{""=>new("\\","","root",true,0,DateTime.UtcNow),"video.mp4"=>new("\\video.mp4","video.mp4","video",false,TotalBytes,DateTime.UtcNow),_=>throw new FileNotFoundException()};
 public IReadOnlyList<CloudNode> Children(CloudNode directory)=>new[]{Resolve("video.mp4")};
 public byte[] Read(CloudNode file,long offset,int count)=>Enumerable.Range(0,count).Select(i=>(byte)((offset+i)%251)).ToArray();
}
sealed class TestServer(SMBShareCollection shares,GSSProvider security):SMBServer(shares,security)
{public void Listen(int port)=>Start(LocalSmbEndpoint.Address,SMBTransportType.DirectTCPTransport,port,false,true,true,null);}
sealed class TestSmbClient:SMBLibrary.Client.SMB2Client
{public bool Link(int port)=>Connect(LocalSmbEndpoint.Address,SMBTransportType.DirectTCPTransport,port);}
static class CheckProcess
{
 [System.Runtime.InteropServices.DllImport("kernel32.dll")] private static extern uint SetErrorMode(uint mode);
 public static void DisableCrashDialog()=>SetErrorMode(3); // Fail critical errors; no Windows crash dialog for unattended checks.
}
