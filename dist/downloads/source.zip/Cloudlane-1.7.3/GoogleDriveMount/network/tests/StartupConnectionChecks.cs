using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Cloudlane;

internal static class StartupConnectionChecks
{
    private static readonly string A = new('A', 64), B = new('B', 64), C = new('C', 64);
    private static Settings Fixture() => new()
    {
        AccountId = A, AccountEmail = "first@example.test", Letter = "G:", DriveName = "First drive",
        StreamingCacheEnabled = false, ClientId = "test.apps.googleusercontent.com", ClientSecret = "fixture",
        Accounts = new()
        {
            new() { Id = A, Email = "first@example.test", Letter = "G:", DriveName = "First drive", AutoConnect = true },
            new() { Id = B, Email = "second@example.test", Letter = "H:", DriveName = "Second drive" },
            new() { Id = C, Email = "third@example.test", Letter = "I:", DriveName = "Third drive", AutoConnect = true }
        }
    };
    internal static async Task RunAsync(Action<bool, string> check)
    {
        var old = JsonSerializer.Deserialize<AccountProfile>("{\"Id\":\"saved\",\"Letter\":\"G:\"}")!;
        check(!old.AutoConnect, "auto-connect is opt-in and older saved account entries remain disabled by default");
        var settings = Fixture();
        var restored = JsonSerializer.Deserialize<Settings>(JsonSerializer.Serialize(settings))!; restored.InitializeAccounts();
        restored.SelectAccount(B); restored.DriveName = "Second renamed"; restored.RememberSelected();
        check(restored.Accounts.Single(a => a.Id == A).AutoConnect && !restored.Accounts.Single(a => a.Id == B).AutoConnect &&
            restored.Accounts.Single(a => a.Id == C).AutoConnect,
            "per-account auto-connect choices survive serialization, account switching and unrelated name edits");

        var attempts = new List<Settings>(); var progress = new List<StartupConnectionResult>();
        var runner = new StartupConnections();
        var result = await runner.RunAsync(settings, _ => true, _ => false, _ => false,
            (s, _) => { attempts.Add(s); settings.AccountEmail = "changed selection metadata"; return Task.CompletedTask; }, progress.Add, CancellationToken.None);
        check(attempts.Select(a => a.AccountId).SequenceEqual(new[] { A, C }) && result.Count == 2 && result.All(r => r.Connected),
            "startup connects only enabled accounts and reports each completed drive");
        check(attempts[0].Letter == "G:" && attempts[1].Letter == "I:" && attempts[1].DriveName == "Third drive" &&
            attempts[1].AccountEmail == "third@example.test" && !attempts[1].StreamingCacheEnabled && attempts[1].ClientId == settings.ClientId,
            "automatic connections use each account's saved letter/name and stable credentials/cache preferences without switching the UI account");
        var again = await runner.RunAsync(settings, _ => true, _ => false, _ => false, (_, _) => throw new Exception("Duplicate attempt"), _ => { }, CancellationToken.None);
        check(again.Count == 0 && attempts.Count == 2, "restoring or reloading a window cannot run automatic connection a second time");

        settings = Fixture(); int calls = 0;
        var skipped = await new StartupConnections().RunAsync(settings, s => s.AccountId != A, _ => false, l => l == "I:",
            (_, _) => { calls++; return Task.CompletedTask; }, _ => { }, CancellationToken.None);
        check(calls == 0 && skipped.Count == 2 && skipped[0].Message.Contains("Sign in") && skipped[1].Message.Contains("already in use"),
            "missing saved sign-ins and occupied letters are skipped with actionable results rather than replacing an existing drive");
        var connected = await new StartupConnections().RunAsync(settings, _ => false, _ => true, _ => true,
            (_, _) => throw new Exception("Already mounted"), _ => { }, CancellationToken.None);
        check(connected.All(r => r.Connected && r.Message == "Already connected"), "already connected account drives are preserved without remapping or requesting approval");

        calls = 0;
        var failure = await new StartupConnections().RunAsync(Fixture(), _ => true, _ => false, _ => false,
            (s, _) => { calls++; if (s.AccountId == A) throw new IOException("Simulated network failure"); return Task.CompletedTask; }, _ => { }, CancellationToken.None);
        check(calls == 2 && !failure[0].Connected && failure[1].Connected,
            "one account's connection failure does not prevent another enabled account from connecting");
        calls = 0;
        var approval = await new StartupConnections().RunAsync(Fixture(), _ => true, _ => false, _ => false,
            (_, _) => { calls++; throw new MappingApprovalCancelledException(); }, _ => { }, CancellationToken.None);
        check(calls == 1 && approval.Count == 1 && !approval[0].Connected && approval[0].Message.Contains("Remaining automatic connections stopped"),
            "declining Windows approval stops the automatic sequence instead of opening more administrator prompts");

        using var cancel = new CancellationTokenSource(); calls = 0; bool cancelled = false;
        try
        {
            await new StartupConnections().RunAsync(Fixture(), _ => true, _ => false, _ => false,
                (_, ct) => { calls++; cancel.Cancel(); ct.ThrowIfCancellationRequested(); return Task.CompletedTask; }, _ => { }, cancel.Token);
        }
        catch (OperationCanceledException) { cancelled = true; }
        check(cancelled && calls == 1, "cancelling startup interrupts its active attempt and leaves later drives untouched");

        var timeout = await new StartupConnections().RunAsync(Fixture(), _ => true, _ => false, _ => false,
            async (s, ct) => { if (s.AccountId == A) await Task.Delay(Timeout.Infinite, ct); }, _ => { }, CancellationToken.None, TimeSpan.FromMilliseconds(30));
        check(!timeout[0].Connected && timeout[0].Message.Contains("timed out") && timeout[1].Connected,
            "a startup connection timeout reports recovery guidance and still attempts other enabled accounts");
    }
}
