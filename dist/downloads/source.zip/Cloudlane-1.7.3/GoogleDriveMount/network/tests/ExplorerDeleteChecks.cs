using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using Cloudlane;
using Cloudlane.Mount;
using SMBLibrary;
using SMBLibrary.Server;
using SMBLibrary.Authentication.GSSAPI;
internal static class ExplorerDeleteChecks
{
    public static async Task RunAsync(Action<bool,string> check,Settings settings,string token)
    {
        var before=Directory.GetFiles(AppContext.BaseDirectory,"*",SearchOption.AllDirectories).OrderBy(x=>x).ToArray();
        var remote=new UploadDriveHandler();using var api=new GoogleDriveApi(settings,remote,token);
        var root=new DriveFile("root","My Drive","application/vnd.google-apps.folder",0,DateTimeOffset.UtcNow,"1","",Array.Empty<string>(),"",true);
        var tree=new GoogleTree(api,root,15000000000,10000000000,CancellationToken.None);var store=new CloudFileStore(tree);string error="";store.Error=value=>error=value;
        const AccessMask remove=(AccessMask)0x10080;
        const ShareAccess all=ShareAccess.Read|ShareAccess.Write|ShareAccess.Delete;
        void Add(string id,string name,string parent="root",bool folder=false)=>remote.Items.Add(id,new(id,name,parent,folder?"application/vnd.google-apps.folder":"application/octet-stream",folder?Array.Empty<byte>():new byte[]{1,2,3,4}));
        NTStatus Open(string path,out object handle,AccessMask access=remove,ShareAccess share=all,CreateOptions options=0)=>store.CreateFile(out handle,out _,path,access,0,share,CreateDisposition.FILE_OPEN,options,null!);
        NTStatus Delete(object handle,bool value=true)=>store.SetFileInformation(handle,new FileDispositionInformation{DeletePending=value});
        bool Missing(string path){try{tree.Resolve(path);return false;}catch(FileNotFoundException){return true;}}
        Add("movie","movie.mkv");
        check(Open("\\movie.mkv",out var movie)==NTStatus.STATUS_SUCCESS&&Delete(movie)==NTStatus.STATUS_SUCCESS,"Explorer delete moves a completed cloud file to Google Trash");
        check(remote.Items["movie"].Trashed&&remote.Items["movie"].Bytes.SequenceEqual(new byte[]{1,2,3,4})&&remote.PermanentDeletes==0&&remote.MediaReads==0,"deletion preserves file contents in Trash without a permanent-delete or media-download request");
        check(Missing("\\movie.mkv"),"a trashed item disappears from the mounted directory immediately");
        check(store.GetFileInformation(out var info,movie,FileInformationClass.FileStandardInformation)==NTStatus.STATUS_SUCCESS&&((FileStandardInformation)info).DeletePending,"Windows receives the destination's delete-pending state");
        int deletes=remote.TrashRequests;
        check(Delete(movie)==NTStatus.STATUS_SUCCESS&&remote.TrashRequests==deletes,"repeated delete marking does not submit duplicate Trash operations");
        check(Delete(movie,false)==NTStatus.STATUS_SUCCESS&&!remote.Items["movie"].Trashed&&tree.Resolve("\\movie.mkv").Id=="movie","clearing delete disposition restores the same Google file ID before close");
        check(Delete(movie)==NTStatus.STATUS_SUCCESS&&store.CloseFile(movie)==NTStatus.STATUS_SUCCESS&&remote.PermanentDeletes==0,"closing a marked file does not permanently delete it or repeat the Trash request");
        Add("locked","locked.mkv");tree.Refresh();
        check(Open("\\locked.mkv",out var playing,AccessMask.GENERIC_READ,ShareAccess.Read)==NTStatus.STATUS_SUCCESS&&Open("\\locked.mkv",out _)==NTStatus.STATUS_SHARING_VIOLATION,"a player handle without delete sharing produces file-in-use instead of administrator permission advice");
        store.CloseFile(playing);
        check(Open("\\locked.mkv",out var unlocked)==NTStatus.STATUS_SUCCESS&&Delete(unlocked)==NTStatus.STATUS_SUCCESS&&store.CloseFile(unlocked)==NTStatus.STATUS_SUCCESS,"closing the player allows the same file to be trashed");
        Add("no-right","read-only-handle.bin");tree.Refresh();
        Open("\\read-only-handle.bin",out var noRight,AccessMask.GENERIC_READ);deletes=remote.TrashRequests;
        check(Delete(noRight)==NTStatus.STATUS_ACCESS_DENIED&&remote.TrashRequests==deletes,"a handle without DELETE access cannot change Google Trash state");store.CloseFile(noRight);
        Add("denied","permission.bin");tree.Refresh();remote.TrashDenied=true;Open("\\permission.bin",out var denied);
        check(Delete(denied)==NTStatus.STATUS_ACCESS_DENIED&&!remote.Items["denied"].Trashed&&error.Contains("Google Drive denied"),"Google permission failures preserve the file and report the Google account permission problem");store.CloseFile(denied);remote.TrashDenied=false;
        Open("\\",out var rootHandle);deletes=remote.TrashRequests;
        check(Delete(rootHandle)==NTStatus.STATUS_ACCESS_DENIED&&remote.TrashRequests==deletes,"the My Drive root can never be trashed through the mount");store.CloseFile(rootHandle);
        Add("folder","folder",folder:true);Add("child","child.txt","folder");tree.Refresh();Open("\\folder",out var directory);
        check(Delete(directory)==NTStatus.STATUS_DIRECTORY_NOT_EMPTY&&!remote.Items["folder"].Trashed,"a nonempty directory is protected until Explorer removes its children");
        Open("\\folder\\child.txt",out var child);Delete(child);store.CloseFile(child);
        check(Delete(directory)==NTStatus.STATUS_SUCCESS&&store.CloseFile(directory)==NTStatus.STATUS_SUCCESS&&remote.Items["folder"].Trashed&&remote.Items["child"].Trashed,"Explorer's recursive deletion moves children and the emptied folder to Trash");
        Add("on-close","on-close.bin");tree.Refresh();
        check(Open("\\on-close.bin",out var onClose,options:CreateOptions.FILE_DELETE_ON_CLOSE)==NTStatus.STATUS_SUCCESS&&!remote.Items["on-close"].Trashed&&store.CloseFile(onClose)==NTStatus.STATUS_SUCCESS&&remote.Items["on-close"].Trashed,"DELETE_ON_CLOSE is supported for completed files");
        store.CreateFile(out var created,out _,"\\just-uploaded.bin",AccessMask.GENERIC_READ|AccessMask.GENERIC_WRITE,0,all,CreateDisposition.FILE_CREATE,0,null!);store.CloseFile(created);
        string recentId=tree.Resolve("\\just-uploaded.bin").Id;Open("\\just-uploaded.bin",out var recent);Delete(recent);store.CloseFile(recent);
        check(remote.Items[recentId].Trashed&&Missing("\\just-uploaded.bin"),"deleting a freshly uploaded file also clears the recent-upload metadata overlay");
        Add("stale","same-name.bin");tree.Refresh();Open("\\same-name.bin",out var stale);remote.Items.Remove("stale");Add("replacement","same-name.bin");
        check(Delete(stale)!=NTStatus.STATUS_SUCCESS&&!remote.Items["replacement"].Trashed,"deletion uses the opened Google ID and cannot delete a different file that reuses its name");store.CloseFile(stale);
        Add("active","active.bin");tree.Refresh();
        store.CreateFile(out var writer,out _,"\\active.bin",AccessMask.GENERIC_READ|AccessMask.GENERIC_WRITE,0,all,CreateDisposition.FILE_OVERWRITE_IF,0,null!);store.SetFileInformation(writer,new FileEndOfFileInformation{EndOfFile=100});
        Open("\\active.bin",out var activeDelete);
        check(Delete(activeDelete)==NTStatus.STATUS_SHARING_VIOLATION&&!remote.Items["active"].Trashed,"an incomplete replacement cannot delete the pre-existing remote file");store.CloseFile(activeDelete);store.CloseFile(writer);
        Add("smb-delete","over-smb.mkv");tree.Refresh();
        using(var reservation=new TcpListener(LocalSmbEndpoint.Address,0))
        {
            reservation.Start();int port=((IPEndPoint)reservation.LocalEndpoint).Port;reservation.Stop();
            var shares=new SMBShareCollection();shares.Add(new FileSystemShare("Cloudlane",store,CachingPolicy.NoCaching));var server=new TestServer(shares,new GSSProvider(new CloudlaneAuthentication("delete-test")));server.Listen(port);var client=new TestSmbClient();
            try
            {
                if(!client.Link(port)||client.Login("CLOUDLANE","Cloudlane","delete-test")!=NTStatus.STATUS_SUCCESS)throw new Exception("Signed delete fixture could not log in.");
                var files=client.TreeConnect("Cloudlane",out var status);if(status!=NTStatus.STATUS_SUCCESS)throw new Exception("Signed delete fixture could not connect its tree.");
                check(files.CreateFile(out var target,out _,"over-smb.mkv",remove,0,all,CreateDisposition.FILE_OPEN,0,null!)==NTStatus.STATUS_SUCCESS&&files.SetFileInformation(target,new FileDispositionInformation{DeletePending=true})==NTStatus.STATUS_SUCCESS&&files.CloseFile(target)==NTStatus.STATUS_SUCCESS&&remote.Items["smb-delete"].Trashed,"a real signed SMB delete request reaches Google Trash and closes successfully");
                files.Disconnect();client.Logoff();
            }
            finally { client.Disconnect();server.Stop(); }
        }
        check(remote.PermanentDeletes==0&&remote.MediaReads==0&&before.SequenceEqual(Directory.GetFiles(AppContext.BaseDirectory,"*",SearchOption.AllDirectories).OrderBy(x=>x)),"completed-file deletion uses no permanent-delete calls, media reads or local payload files");
        await Task.CompletedTask;
    }
}
