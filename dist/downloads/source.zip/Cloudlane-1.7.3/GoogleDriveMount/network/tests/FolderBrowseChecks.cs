using System;
using System.Collections.Concurrent;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Cloudlane;
using Cloudlane.Mount;
using SMBLibrary;

internal static class FolderBrowseChecks
{
    internal static async Task RunAsync(Action<bool, string> check, Settings settings, string token)
    {
        string folder = Path.Combine(AppContext.BaseDirectory, "folder-browse-cache");
        await using var cache = new MediaBlockCache(folder, CancellationToken.None);
        using var remote = new FolderHandler();
        using var api = new GoogleDriveApi(settings, remote, token);
        var root = new DriveFile("fish", "Fish", "application/vnd.google-apps.folder", 0, DateTimeOffset.UtcNow, "1", "", Array.Empty<string>(), "", true);
        var tree = new GoogleTree(api, root, 1L << 40, 1L << 39, CancellationToken.None, streamingCache: cache, cacheAccount: settings.AccountId);
        var store = new CloudFileStore(tree);
        using var endpoint = ExplorerServerPool.Acquire(store, _ => { });
        var client = new TestSmbClient();
        try
        {
            check(client.Link(endpoint.Port) && client.Login("CLOUDLANE", "Cloudlane", endpoint.Password) == NTStatus.STATUS_SUCCESS,
                "signed SMB authenticates for a folder containing many uncached images and videos");
            var share = client.TreeConnect(endpoint.ShareName, out _);
            share.CreateFile(out var directory, out _, "", AccessMask.GENERIC_READ, 0, ShareAccess.Read, CreateDisposition.FILE_OPEN, CreateOptions.FILE_DIRECTORY_FILE, null!);
            var listed = share.QueryDirectory(out var entries, directory, "*", FileInformationClass.FileDirectoryInformation);
            Console.WriteLine($"Folder enumeration fixture: status={listed}, entries={entries.Count}, media={remote.MediaCalls}, cache={cache.UsedBytes}");
            check((listed == NTStatus.STATUS_SUCCESS || listed == NTStatus.STATUS_NO_MORE_FILES) && entries.Count == FolderHandler.Files + 2 && remote.MediaCalls == 0 && cache.UsedBytes == 0,
                "opening and enumerating Fish lists every file without downloading any media or populating the cache");
            check(entries.Cast<FileDirectoryInformation>().Where(e => e.FileName != "." && e.FileName != "..").All(e =>
                (e.FileAttributes & SMBLibrary.FileAttributes.Offline) == 0 && e.FileAttributes.HasFlag(SMBLibrary.FileAttributes.NotContentIndexed)),
                "cloud listings keep content indexing off without advertising playable files as offline");
            share.CloseFile(directory);
            bool metadata = true;
            foreach (int n in Enumerable.Range(0, FolderHandler.Files))
            {
                string name = FolderHandler.Name(n);
                var opened = share.CreateFile(out var handle, out _, name, AccessMask.GENERIC_READ, 0, ShareAccess.Read,
                    CreateDisposition.FILE_OPEN, CreateOptions.FILE_OPEN_NO_RECALL, null!);
                var infoStatus = share.GetFileInformation(out var info, handle, FileInformationClass.FileNetworkOpenInformation);
                metadata &= opened == NTStatus.STATUS_SUCCESS && infoStatus == NTStatus.STATUS_SUCCESS && !((FileNetworkOpenInformation)info).FileAttributes.HasFlag(SMBLibrary.FileAttributes.Offline);
                share.CloseFile(handle);
            }
            check(metadata && remote.MediaCalls == 0 && cache.UsedBytes == 0,
                "opening no-recall handles and inspecting metadata fetches zero media bytes and creates no cache blocks");
            bool bytesCorrect = true;
            foreach (var options in new[] { (CreateOptions)0, CreateOptions.FILE_OPEN_NO_RECALL,
                CreateOptions.FILE_RANDOM_ACCESS | CreateOptions.FILE_SYNCHRONOUS_IO_NONALERT | CreateOptions.FILE_NON_DIRECTORY_FILE })
            foreach (int n in Enumerable.Range(0, FolderHandler.Files))
            {
                share.CreateFile(out var handle, out _, FolderHandler.Name(n), AccessMask.GENERIC_READ, 0, ShareAccess.Read,
                    CreateDisposition.FILE_OPEN, options, null!);
                bytesCorrect &= share.ReadFile(out var bytes, handle, 0, 4096) == NTStatus.STATUS_SUCCESS && bytes.All(b => b == n + 1);
                share.CloseFile(handle);
            }
            check(bytesCorrect && remote.MediaCalls == FolderHandler.Files * 3 && remote.MaxBytes == CachedMediaReader.ProbeWindowBytes && cache.UsedBytes == 0 && cache.PendingCount == 0,
                "ordinary, no-recall and VLC-style random-access reads succeed while brief probes create no disk cache or preloads");
            share.CreateFile(out var probe, out _, FolderHandler.Name(0), AccessMask.GENERIC_READ, 0, ShareAccess.Read, CreateDisposition.FILE_OPEN, 0, null!);
            share.ReadFile(out _, probe, 0, 4096); share.ReadFile(out _, probe, 0, 4096);
            share.ReadFile(out _, probe, FolderHandler.Length(0) - 32, 32); share.CloseFile(probe);
            check(cache.UsedBytes == 0 && cache.PendingCount == 0,
                "repeated header and scattered tail probes never count as sustained sequential playback");

            var before = remote.PerFile.ToDictionary(p => p.Key, p => p.Value);
            share.CreateFile(out var image, out _, FolderHandler.Name(1), AccessMask.GENERIC_READ, 0, ShareAccess.Read,
                CreateDisposition.FILE_OPEN, 0, null!);
            share.ReadFile(out var first, image, 0, CloudReadBuffer.BlockSize);
            check(cache.UsedBytes == 0 && first.Length == CloudReadBuffer.BlockSize,
                "a single large first read still does not authorize persistent caching or background downloads");
            share.ReadFile(out var second, image, CloudReadBuffer.BlockSize, CloudReadBuffer.BlockSize); share.CloseFile(image);
            check(first.All(b => b == 2) && second.All(b => b == 2) && cache.UsedBytes == FolderHandler.Length(1) + 44 &&
                cache.PendingCount == 0 && remote.PerFile.Where(p => p.Key != "item1").All(p => before[p.Key] == p.Value),
                "reading one selected image caches only that image and leaves every sibling's download count unchanged");
            int downloaded = remote.MediaCalls;
            share.CreateFile(out var reopened, out _, FolderHandler.Name(1), AccessMask.GENERIC_READ, 0, ShareAccess.Read, CreateDisposition.FILE_OPEN, 0, null!);
            share.ReadFile(out var again, reopened, 100, 4096); share.CloseFile(reopened);
            check(again.All(b => b == 2) && remote.MediaCalls == downloaded,
                "reopening the selected image reuses existing verified cache bytes without downloading it again");

            before = remote.PerFile.ToDictionary(p => p.Key, p => p.Value);
            var playerOpened = share.CreateFile(out var video, out _, FolderHandler.Name(0), AccessMask.GENERIC_READ, 0,
                ShareAccess.Read | ShareAccess.Write | ShareAccess.Delete, CreateDisposition.FILE_OPEN,
                CreateOptions.FILE_RANDOM_ACCESS | CreateOptions.FILE_SYNCHRONOUS_IO_NONALERT | CreateOptions.FILE_NON_DIRECTORY_FILE, null!);
            var standardStatus = share.GetFileInformation(out var playerInfo, video, FileInformationClass.FileStandardInformation);
            check(playerOpened == NTStatus.STATUS_SUCCESS && standardStatus == NTStatus.STATUS_SUCCESS &&
                ((FileStandardInformation)playerInfo).EndOfFile == FolderHandler.Length(0),
                "a VLC-style open and file-size query succeeds for a recording filename containing spaces and dots");
            var tailStatus = share.ReadFile(out var tail, video, FolderHandler.Length(0) - 32, 32);
            check(tailStatus == NTStatus.STATUS_SUCCESS && tail.Length == 32 && tail.All(b => b == 1) &&
                share.ReadFile(out _, video, FolderHandler.Length(0), 32) == NTStatus.STATUS_END_OF_FILE,
                "player header/tail seeks and exact EOF handling succeed without marking playable content offline");
            share.ReadFile(out _, video, 0, 4096);
            share.ReadFile(out _, video, 4096, CachedMediaReader.ActivationBytes);
            using (var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(10)))
                while (remote.LargeVideoReads == 0) await Task.Delay(10, deadline.Token);
            share.CloseFile(video);
            using (var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(10)))
                while (cache.PendingCount != 0) await Task.Delay(10, deadline.Token);
            check(remote.LargeVideoReads > 0 && remote.PerFile.Where(p => p.Key != "item0").All(p => before[p.Key] == p.Value),
                "sustained video playback enables ahead loading only for that video, never its folder's other files");
            share.Disconnect(); client.Logoff();
        }
        finally { client.Disconnect(); store.AbortUploads(); }
    }
    private sealed class FolderHandler : HttpMessageHandler
    {
        internal const int Files = 20;
        internal int MediaCalls, MaxBytes, LargeVideoReads;
        internal readonly ConcurrentDictionary<string, int> PerFile = new();
        internal static string Name(int n) => n == 0 ? "Desktop 2026.09.17 - 21.58.51.01.mp4" : "item" + n + (n % 2 == 0 ? ".mp4" : ".jpg");
        internal static long Length(int n) => n % 2 == 0 ? 40L * 1024 * 1024 : 2L * 1024 * 1024;
        private object Meta(int n) => new { id = "item" + n, name = Name(n), mimeType = n % 2 == 0 ? "video/mp4" : "image/jpeg", size = Length(n).ToString(), version = "1", modifiedTime = "2026-10-17T00:00:00Z", capabilities = new { canEdit = true, canDownload = true } };
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
        {
            if (request.RequestUri!.AbsolutePath.EndsWith("/files"))
                return Task.FromResult(Json(new { files = Enumerable.Range(0, Files).Select(Meta).ToArray() }));
            string id = request.RequestUri.Segments.Last(); int n = int.Parse(id[4..]);
            if (request.Headers.Range != null)
            {
                ct.ThrowIfCancellationRequested(); var range = request.Headers.Range.Ranges.Single();
                int size = (int)(range.To!.Value - range.From!.Value + 1);
                Interlocked.Increment(ref MediaCalls); PerFile.AddOrUpdate(id, 1, (_, old) => old + 1);
                if (size > MaxBytes) MaxBytes = size;
                if (id == "item0" && size > CloudReadBuffer.BlockSize) Interlocked.Increment(ref LargeVideoReads);
                var response = new HttpResponseMessage(HttpStatusCode.PartialContent) { Content = new ByteArrayContent(Enumerable.Repeat((byte)(n + 1), size).ToArray()) };
                response.Content.Headers.ContentRange = new ContentRangeHeaderValue(range.From.Value, range.To.Value, Length(n)); return Task.FromResult(response);
            }
            return Task.FromResult(Json(Meta(n)));
        }
        private static HttpResponseMessage Json(object body) => new(HttpStatusCode.OK) { Content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json") };
    }
}
