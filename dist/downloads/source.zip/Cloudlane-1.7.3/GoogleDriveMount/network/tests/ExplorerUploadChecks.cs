using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Cloudlane;
using Cloudlane.Mount;
using SMBLibrary;
using SMBLibrary.Server;
using SMBLibrary.Authentication.GSSAPI;
using FA = SMBLibrary.FileAttributes;
internal static class ExplorerUploadChecks
{
    public static async Task RunAsync(Action<bool,string> check, Settings settings, string token, string source)
    {
        var diskBefore=Directory.GetFiles(AppContext.BaseDirectory,"*",SearchOption.AllDirectories).OrderBy(x=>x).ToArray();
        string originalHash=await GoogleDriveApi.HashAsync(source,CancellationToken.None);
        var remote=new UploadDriveHandler(); using var api=new GoogleDriveApi(settings,remote,token);
        using var life=new CancellationTokenSource();
        var root=new DriveFile("root","My Drive","application/vnd.google-apps.folder",0,DateTimeOffset.UtcNow,"1","",Array.Empty<string>(),"",true);
        var tree=new GoogleTree(api,root,20L*1024*1024*1024,15L*1024*1024*1024,life.Token);
        var store=new CloudFileStore(tree);string error="";store.Error=message=>error=message;
        const AccessMask rw=AccessMask.GENERIC_READ|AccessMask.GENERIC_WRITE|(AccessMask)0x10000;
        NTStatus Open(string path,out object handle,CreateDisposition disposition=CreateDisposition.FILE_CREATE,CreateOptions options=0)=>store.CreateFile(out handle,out _,path,rw,0,ShareAccess.Read|ShareAccess.Write|ShareAccess.Delete,disposition,options,null!);
        check(store.GetFileSystemInformation(out var fs,FileSystemInformationClass.FileFsAttributeInformation)==NTStatus.STATUS_SUCCESS&&(((FileFsAttributeInformation)fs).FileSystemAttributes&FileSystemAttributes.ReadOnlyVolume)==0,"Explorer upload volume is advertised as writable");
        check(Open("\\copied",out var folder,CreateDisposition.FILE_OPEN_IF,CreateOptions.FILE_DIRECTORY_FILE)==NTStatus.STATUS_SUCCESS&&store.CloseFile(folder)==NTStatus.STATUS_SUCCESS,"Explorer creates a real cloud destination folder");
        long length=new FileInfo(source).Length;
        check(Open("\\copied\\copy.bin",out var handle)==NTStatus.STATUS_SUCCESS,"Explorer creates a new upload destination");
        check(store.SetFileInformation(handle,new FileAllocationInformation{AllocationSize=length+4096})==NTStatus.STATUS_SUCCESS&&store.SetFileInformation(handle,new FileEndOfFileInformation{EndOfFile=length})==NTStatus.STATUS_SUCCESS,"copy allocation and source file length are accepted without allocating a disk file");
        var upload=tree.PendingUpload("\\copied\\copy.bin")!;
        check(upload.Node.Size==length&&upload.BufferedCapacity==0&&tree.Children(tree.Resolve("\\copied")).Any(x=>x.Name=="copy.bin"),"pending copy appears in directory metadata before any payload buffer is allocated");
        using(var input=File.OpenRead(source))
        {
            byte[] first=new byte[StreamingCloudUpload.ChunkSize],second=new byte[first.Length];input.ReadExactly(first);input.ReadExactly(second);
            check(store.WriteFile(out int n,handle,first.Length,second)==NTStatus.STATUS_SUCCESS&&n==second.Length&&remote.Chunks==0,"bounded write window accepts a pipelined chunk arriving ahead of its prefix");
            check(store.CreateFile(out var metadata,out _,"\\copied\\copy.bin",(AccessMask)0x80,0,ShareAccess.Read|ShareAccess.Write,CreateDisposition.FILE_OPEN,0,null!)==NTStatus.STATUS_SUCCESS&&store.CloseFile(metadata)==NTStatus.STATUS_SUCCESS&&!upload.Completed,"Explorer metadata probes can close without prematurely finalizing an active copy");
            check(store.WriteFile(out n,handle,0,first)==NTStatus.STATUS_SUCCESS&&n==first.Length&&remote.Chunks==2,"filling the missing prefix uploads contiguous chunks directly to Google");
            byte[] bytes=new byte[512*1024];long offset=input.Position;
            while(offset<length)
            {
                int got=input.Read(bytes,0,(int)Math.Min(bytes.Length,length-offset));byte[] part=bytes.AsSpan(0,got).ToArray();
                if(store.WriteFile(out n,handle,offset,part)!=NTStatus.STATUS_SUCCESS||n!=got)throw new Exception("Copy write failed: "+error);
                offset+=got;
                if(!upload.Completed&&upload.BufferedCapacity>StreamingCloudUpload.WindowSize)throw new Exception("Upload exceeded its RAM bound.");
            }
        }
        check(upload.Completed&&upload.BufferedCapacity==0&&remote.MaxChunk<=StreamingCloudUpload.ChunkSize,"last copy write confirms the complete upload and releases bounded RAM");
        check(Open("\\copied\\copy.bin",out _,CreateDisposition.FILE_OVERWRITE_IF)==NTStatus.STATUS_SHARING_VIOLATION,"a completed copy retains exclusive writer ownership until its destination handle closes");
        DateTime modified=new(2020,3,4,5,6,7,DateTimeKind.Utc);
        check(store.SetFileInformation(handle,new FileBasicInformation{LastWriteTime=modified})==NTStatus.STATUS_SUCCESS&&store.FlushFileBuffers(handle)==NTStatus.STATUS_SUCCESS&&store.CloseFile(handle)==NTStatus.STATUS_SUCCESS,"Explorer can set copied modification time, flush and close the completed file");
        var copied=tree.Resolve("\\copied\\copy.bin");
        remote.HiddenNames.Add("copy.bin");tree.Refresh();
        check(tree.Resolve(copied.Path).Id==copied.Id,"recently completed file metadata remains visible while Google's folder listing catches up");remote.HiddenNames.Clear();tree.Refresh();
        check(remote.Items[copied.Id].Hash==originalHash&&copied.Size==length&&copied.Modified==modified,"Google receives the original bytes, exact size and copied modification time");
        check(store.CreateFile(out var read,out _,copied.Path,AccessMask.GENERIC_READ,0,ShareAccess.Read,CreateDisposition.FILE_OPEN,0,null!)==NTStatus.STATUS_SUCCESS&&store.ReadFile(out var tail,read,length-1024,1024)==NTStatus.STATUS_SUCCESS&&tail.Length==1024,"a copied file can immediately stream back through the same Explorer store");store.CloseFile(read);
        check(Open(copied.Path,out _,CreateDisposition.FILE_CREATE)==NTStatus.STATUS_OBJECT_NAME_COLLISION,"a normal new-file copy cannot silently overwrite an existing cloud file");
        check(Open(copied.Path,out var replacement,CreateDisposition.FILE_OVERWRITE_IF)==NTStatus.STATUS_SUCCESS,"Copy / Replace opens a separate resumable update of the existing file ID");
        store.SetFileInformation(replacement,new FileEndOfFileInformation{EndOfFile=123});
        check(remote.Items[copied.Id].Hash==originalHash,"starting a replacement leaves the old remote content intact");
        byte[] replace=Enumerable.Range(0,123).Select(i=>(byte)i).ToArray();
        check(store.WriteFile(out _,replacement,0,replace)==NTStatus.STATUS_SUCCESS&&store.CloseFile(replacement)==NTStatus.STATUS_SUCCESS&&tree.Resolve(copied.Path).Id==copied.Id&&remote.Items[copied.Id].Bytes.SequenceEqual(replace),"a completed replacement updates content without creating a duplicate Google file");
        check(Open("\\copied\\empty.txt",out var empty)==NTStatus.STATUS_SUCCESS&&store.CloseFile(empty)==NTStatus.STATUS_SUCCESS&&tree.Resolve("\\copied\\empty.txt").Size==0,"empty files are uploaded and confirmed on close");
        check(Open("\\copied\\cancelled.bin",out var cancelled)==NTStatus.STATUS_SUCCESS,"a cancellable copy is created");
        store.SetFileInformation(cancelled,new FileEndOfFileInformation{EndOfFile=2*StreamingCloudUpload.ChunkSize});
        store.WriteFile(out _,cancelled,0,new byte[64*1024]);
        check(store.SetFileInformation(cancelled,new FileDispositionInformation{DeletePending=true})==NTStatus.STATUS_SUCCESS&&store.CloseFile(cancelled)==NTStatus.STATUS_SUCCESS&&!tree.Children(tree.Resolve("\\copied")).Any(x=>x.Name=="cancelled.bin"),"cancelling a partial copy removes its pending destination without completing a truncated file");
        Open("\\copied\\incomplete.bin",out var incomplete);store.SetFileInformation(incomplete,new FileEndOfFileInformation{EndOfFile=100});store.WriteFile(out _,incomplete,0,new byte[50]);
        check(store.CloseFile(incomplete)!=NTStatus.STATUS_SUCCESS&&!tree.Children(tree.Resolve("\\copied")).Any(x=>x.Name=="incomplete.bin"),"closing a copy short of its declared length reports failure instead of success");
        Open("\\copied\\unknown-size.bin",out var unknown);byte[] unknownData=new byte[StreamingCloudUpload.ChunkSize+23];Array.Fill(unknownData,(byte)73);
        check(store.WriteFile(out _,unknown,0,unknownData)==NTStatus.STATUS_SUCCESS&&store.FlushFileBuffers(unknown)==NTStatus.STATUS_SUCCESS&&store.CloseFile(unknown)==NTStatus.STATUS_SUCCESS&&remote.Items[tree.Resolve("\\copied\\unknown-size.bin").Id].Bytes.SequenceEqual(unknownData),"a forward copy without a predeclared size finalizes its exact bytes at flush");
        Open("\\copied\\hole.bin",out var hole);store.SetFileInformation(hole,new FileEndOfFileInformation{EndOfFile=100});store.WriteFile(out _,hole,50,new byte[50]);
        check(store.CloseFile(hole)!=NTStatus.STATUS_SUCCESS,"unwritten gaps cannot be silently filled with zeroes or uploaded as a successful copy");
        Open("\\copied\\far-seek.bin",out var far);store.SetFileInformation(far,new FileEndOfFileInformation{EndOfFile=6L*1024*1024*1024});
        check(store.WriteFile(out _,far,5L*1024*1024*1024,new byte[1])==NTStatus.STATUS_NOT_SUPPORTED&&tree.PendingUpload("\\copied\\far-seek.bin")!.BufferedCapacity==0,"a random write beyond the RAM window is rejected without allocating a huge or disk buffer");store.SetFileInformation(far,new FileDispositionInformation{DeletePending=true});store.CloseFile(far);
        remote.DropChunkResponse=true;remote.PartialPrefix=256*1024;
        Open("\\copied\\recover.bin",out var recover);byte[] recoveryData=new byte[StreamingCloudUpload.ChunkSize+123];Array.Fill(recoveryData,(byte)45);store.SetFileInformation(recover,new FileEndOfFileInformation{EndOfFile=recoveryData.Length});
        check(store.WriteFile(out _,recover,0,recoveryData)==NTStatus.STATUS_SUCCESS&&store.CloseFile(recover)==NTStatus.STATUS_SUCCESS&&remote.Queries>0&&remote.Items[tree.Resolve("\\copied\\recover.bin").Id].Bytes.SequenceEqual(recoveryData),"an interrupted upload queries Google's acknowledged prefix and resends only bytes retained in RAM");
        remote.DropFinalResponse=true;remote.ExpireCompletedSession=true;
        Open("\\copied\\lost-final.bin",out var lost);store.SetFileInformation(lost,new FileEndOfFileInformation{EndOfFile=123});
        check(store.WriteFile(out _,lost,0,replace)==NTStatus.STATUS_SUCCESS&&store.CloseFile(lost)==NTStatus.STATUS_SUCCESS,"lost final responses recover by verifying the generated Google ID, size and checksum");
        remote.BadChecksum=true;Open("\\copied\\bad-hash.bin",out var badHash);store.SetFileInformation(badHash,new FileEndOfFileInformation{EndOfFile=123});
        check(store.WriteFile(out _,badHash,0,replace)!=NTStatus.STATUS_SUCCESS&&store.CloseFile(badHash)!=NTStatus.STATUS_SUCCESS&&remote.Items.Values.All(x=>x.Name!="bad-hash.bin"),"an incorrect Google checksum fails the copy and cleans up only its newly created file");remote.BadChecksum=false;
        remote.QuotaFailure=true;Open("\\copied\\quota.bin",out var quota);store.SetFileInformation(quota,new FileEndOfFileInformation{EndOfFile=123});
        check(store.WriteFile(out _,quota,0,replace)==NTStatus.STATUS_DISK_FULL&&error.Contains("storage is full"),"Google storage exhaustion reaches Explorer as disk full with an actionable app message");store.CloseFile(quota);remote.QuotaFailure=false;
        // Real signed SMB traffic exercises the destination create/size/write/flush/close operations.
        using(var reservation=new System.Net.Sockets.TcpListener(LocalSmbEndpoint.Address,0))
        {
            reservation.Start();int port=((IPEndPoint)reservation.LocalEndpoint).Port;reservation.Stop();
            var shares=new SMBShareCollection();shares.Add(new FileSystemShare("Cloudlane",store,CachingPolicy.NoCaching));
            var server=new TestServer(shares,new GSSProvider(new CloudlaneAuthentication("copy-test-password")));server.Listen(port);
            var client=new TestSmbClient();
            try
            {
                check(client.Link(port)&&client.Login("CLOUDLANE","Cloudlane","copy-test-password")==NTStatus.STATUS_SUCCESS,"signed SMB copy session authenticates to the writable store");
                var files=client.TreeConnect("Cloudlane",out var status);
                if(status!=NTStatus.STATUS_SUCCESS)throw new Exception("Signed copy tree connection failed.");
                check(files.CreateFile(out var target,out _,"copied\\over-smb.bin",rw,0,ShareAccess.Read|ShareAccess.Write|ShareAccess.Delete,CreateDisposition.FILE_CREATE,0,null!)==NTStatus.STATUS_SUCCESS,"signed SMB creates the Explorer copy target");
                files.CreateFile(out var destination,out _,"copied\\second-smb.bin",rw,0,ShareAccess.Read|ShareAccess.Write|ShareAccess.Delete,CreateDisposition.FILE_CREATE,0,null!);
                check(files.SetFileInformation(destination,new FileEndOfFileInformation{EndOfFile=length})==NTStatus.STATUS_SUCCESS,"signed SMB sets the destination length");
                using(var original=File.OpenRead(source))
                {
                    long offset=0;byte[] block=new byte[128*1024];
                    while(offset<length)
                    {
                        int got=original.Read(block,0,(int)Math.Min(block.Length,length-offset));
                        status=files.WriteFile(out int wrote,destination,offset,block.AsSpan(0,got).ToArray());
                        if(status!=NTStatus.STATUS_SUCCESS||wrote!=got)throw new Exception("Signed copy write failed: "+status+" "+error);
                        offset+=got;
                    }
                }
                check(files.FlushFileBuffers(destination)==NTStatus.STATUS_SUCCESS&&files.CloseFile(destination)==NTStatus.STATUS_SUCCESS&&remote.Items[tree.Resolve("\\copied\\second-smb.bin").Id].Hash==originalHash,"real signed SMB copy streams the source to Google and verifies exact contents on flush and close");
                // The first empty target is finalized by closing it through the SMB client.
                files.CloseFile(target);files.Disconnect();client.Logoff();
            }
            finally { client.Disconnect();server.Stop(); }
        }
        // Stop concurrently with several native socket disconnect callbacks.
        for(int attempt=0;attempt<5;attempt++)
        {
            using var listener=new System.Net.Sockets.TcpListener(LocalSmbEndpoint.Address,0);listener.Start();int port=((IPEndPoint)listener.LocalEndpoint).Port;listener.Stop();
            var shares=new SMBShareCollection();shares.Add(new FileSystemShare("Cloudlane",new CloudFileStore(new VirtualTree()),CachingPolicy.NoCaching));
            var server=new TestServer(shares,new GSSProvider(new CloudlaneAuthentication("shutdown-test")));server.Listen(port);
            var clients=Enumerable.Range(0,12).Select(_=>new TestSmbClient()).ToArray();
            foreach(var client in clients)if(!client.Link(port))throw new Exception("Concurrent shutdown fixture could not connect.");
            var disconnects=clients.Select(client=>Task.Run(()=>client.Disconnect())).ToList();disconnects.Add(Task.Run(()=>server.Stop()));await Task.WhenAll(disconnects);
        }
        check(true,"SMB shutdown handles concurrent client disconnects without an inconsistent connection snapshot");
        Open("\\copied\\shutdown.bin",out var shutdown);store.SetFileInformation(shutdown,new FileEndOfFileInformation{EndOfFile=123});store.WriteFile(out _,shutdown,0,new byte[12]);
        life.Cancel();store.AbortUploads();
        check(store.CloseFile(shutdown)==NTStatus.STATUS_SUCCESS&&remote.Items.Values.All(x=>x.Name!="shutdown.bin"),"disconnect aborts pending copies without completing a short remote file");
        check(await GoogleDriveApi.HashAsync(source,CancellationToken.None)==originalHash&&diskBefore.SequenceEqual(Directory.GetFiles(AppContext.BaseDirectory,"*",SearchOption.AllDirectories).OrderBy(x=>x)),"Explorer uploads leave the original unchanged and create no additional payload files on disk");
    }
}
internal sealed class UploadDriveHandler : HttpMessageHandler
{
    internal sealed class Item(string id,string name,string parent,string mime,byte[] bytes)
    {
        public string Id=id,Name=name,Parent=parent,Mime=mime;public byte[] Bytes=bytes;public int Version=1;public DateTime Modified=DateTime.UtcNow;public bool Trashed;
        public string Hash=>Convert.ToHexString(MD5.HashData(Bytes)).ToLowerInvariant();
        public object Json(bool bad=false)=>new{id=Id,name=Name,mimeType=Mime,size=Bytes.LongLength.ToString(),version=Version.ToString(),modifiedTime=Modified.ToString("O"),md5Checksum=bad?new string('0',32):Hash,parents=new[]{Parent},trashed=Trashed};
    }
    private sealed class Session(string id,string name,string parent,bool replace)
    { public string Id=id,Name=name,Parent=parent;public bool Replace=replace,Done;public MemoryStream Data=new(); }
    public readonly Dictionary<string,Item> Items=new();private readonly Dictionary<string,Session> sessions=new();private int ids;
    public readonly HashSet<string> HiddenNames=new(StringComparer.OrdinalIgnoreCase);
    public bool DropChunkResponse,DropFinalResponse,ExpireCompletedSession,BadChecksum,QuotaFailure;
    public int PartialPrefix,Queries,Chunks,MaxChunk;
    public bool TrashDenied;public int TrashRequests,RestoreRequests,PermanentDeletes,MediaReads;
    private static HttpResponseMessage Json(object value,HttpStatusCode status=HttpStatusCode.OK)=>new(status){Content=new StringContent(JsonSerializer.Serialize(value),Encoding.UTF8,"application/json")};
    private static HttpResponseMessage Incomplete(long length){var result=Json(new{},(HttpStatusCode)308);if(length>0)result.Headers.TryAddWithoutValidation("Range","bytes=0-"+(length-1));return result;}
    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken ct)
    {
        if(request.Headers.Authorization?.Parameter!="test-token")throw new Exception("Explorer upload is missing Google authorization.");
        string path=request.RequestUri!.AbsolutePath;
        if(path.EndsWith("generateIds"))return Json(new{ids=new[]{"copy-id-"+(++ids)}});
        if(path.StartsWith("/upload/mock-session/"))
        {
            var session=sessions[path];byte[] data=await request.Content!.ReadAsByteArrayAsync(ct);var range=request.Content.Headers.ContentRange!;
            if(data.Length==0&&!(range.Length==0&&!session.Done))
            {
                Queries++;if(session.Done&&ExpireCompletedSession){ExpireCompletedSession=false;return Json(new{},HttpStatusCode.NotFound);}return session.Done?Json(Items[session.Id].Json(BadChecksum)):Incomplete(session.Data.Length);
            }
            if(QuotaFailure)return Json(new{error=new{errors=new[]{new{reason="storageQuotaExceeded"}}}},HttpStatusCode.Forbidden);
            long offset=range.From??0;if(offset!=session.Data.Length)throw new Exception("Wrong resumable offset in Explorer copy test.");
            Chunks++;MaxChunk=Math.Max(MaxChunk,data.Length);
            if(DropChunkResponse&&data.Length>PartialPrefix){DropChunkResponse=false;session.Data.Write(data,0,PartialPrefix);throw new HttpRequestException("Simulated interrupted chunk response");}
            session.Data.Write(data);
            if(range.Length.HasValue&&session.Data.Length==range.Length.Value)
            {
                var item=new Item(session.Id,session.Name,session.Parent,"application/octet-stream",session.Data.ToArray());
                if(Items.TryGetValue(item.Id,out var previous))item.Version=previous.Version+1;
                Items[item.Id]=item;session.Done=true;
                if(DropFinalResponse){DropFinalResponse=false;throw new HttpRequestException("Simulated lost final response");}
                return Json(item.Json(BadChecksum),HttpStatusCode.Created);
            }
            return Incomplete(session.Data.Length);
        }
        if(path.StartsWith("/upload/drive/v3/files"))
        {
            using var metadata=JsonDocument.Parse(await request.Content!.ReadAsStringAsync(ct));var value=metadata.RootElement;
            bool replace=request.Method==HttpMethod.Patch;string id=replace?path.Split('/').Last():value.GetProperty("id").GetString()!;
            string parent=replace?Items[id].Parent:value.GetProperty("parents")[0].GetString()!;
            string name=replace?Items[id].Name:value.GetProperty("name").GetString()!,key="/upload/mock-session/"+(sessions.Count+1);sessions.Add(key,new(id,name,parent,replace));
            var result=Json(new{});result.Headers.Location=new Uri("https://www.googleapis.com"+key);return result;
        }
        if(path=="/drive/v3/files")
        {
            if(request.Method==HttpMethod.Post)
            {
                using var metadata=JsonDocument.Parse(await request.Content!.ReadAsStringAsync(ct));var m=metadata.RootElement;
                var item=new Item(m.GetProperty("id").GetString()!,m.GetProperty("name").GetString()!,m.GetProperty("parents")[0].GetString()!,m.GetProperty("mimeType").GetString()!,Array.Empty<byte>());Items.Add(item.Id,item);return Json(item.Json());
            }
            string q=Uri.UnescapeDataString(request.RequestUri.Query);var match=Regex.Match(q,"'([^']+)' in parents");string parent=match.Groups[1].Value;
            return Json(new{files=Items.Values.Where(x=>x.Parent==parent&&!x.Trashed&&!HiddenNames.Contains(x.Name)).Select(x=>x.Json()).ToArray()});
        }
        string fileId=path.Split('/').Last();if(!Items.TryGetValue(fileId,out var file))return Json(new{},HttpStatusCode.NotFound);
        if(request.Method==HttpMethod.Delete){PermanentDeletes++;Items.Remove(fileId);return Json(new{});}
        if(request.Method==HttpMethod.Patch)
        {
            using var metadata=JsonDocument.Parse(await request.Content!.ReadAsStringAsync(ct));
            if(metadata.RootElement.TryGetProperty("trashed",out var trash))
            {
                if(TrashDenied)return Json(new{error=new{errors=new[]{new{reason="insufficientFilePermissions"}}}},HttpStatusCode.Forbidden);
                file.Trashed=trash.GetBoolean();if(file.Trashed)TrashRequests++;else RestoreRequests++;return Json(file.Json());
            }
            file.Modified=DateTime.Parse(metadata.RootElement.GetProperty("modifiedTime").GetString()!).ToUniversalTime();file.Version++;return Json(file.Json());
        }
        if(request.RequestUri.Query.Contains("alt=media"))
        {
            MediaReads++;
            var range=request.Headers.Range!.Ranges.First();long from=range.From!.Value,to=range.To!.Value;
            var result=new HttpResponseMessage(HttpStatusCode.PartialContent){Content=new ByteArrayContent(file.Bytes.AsSpan((int)from,(int)(to-from+1)).ToArray())};result.Content.Headers.ContentRange=new ContentRangeHeaderValue(from,to,file.Bytes.Length);return result;
        }
        return Json(file.Json());
    }
}
