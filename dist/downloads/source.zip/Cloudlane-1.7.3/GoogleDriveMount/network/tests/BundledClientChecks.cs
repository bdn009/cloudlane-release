using System;
using System.IO;
using System.Linq;
using System.Text;
using Cloudlane;

internal static class BundledClientChecks
{
    internal static void Run(Action<bool, string> check)
    {
        var empty = new Settings(); BundledGoogleClient.Apply(empty, () => null);
        check(!empty.HasClient, "a developer build without a bundled client retains manual Google app setup");
        var ready = new Settings();
        Stream Client(string json) => new MemoryStream(Encoding.UTF8.GetBytes(json));
        const string fixture = "{\"installed\":{\"client_id\":\"distribution.apps.googleusercontent.com\",\"client_secret\":\"fixture-registration\"}}";
        BundledGoogleClient.Apply(ready, () => Client(fixture));
        check(ready.HasClient && ready.ClientId == "distribution.apps.googleusercontent.com", "a bundled Desktop registration enables Google sign-in without a JSON import");
        check(ready.AccountId.Length == 0 && ready.AccountEmail.Length == 0 && !ready.IsSignedIn, "a bundled registration does not sign in the publisher or create a saved user identity");
        ready.ClientId = "custom.apps.googleusercontent.com";
        BundledGoogleClient.Apply(ready, () => throw new Exception("Must retain explicit registration"));
        check(ready.ClientId == "custom.apps.googleusercontent.com", "an explicitly configured Google client takes precedence over the bundled registration");
        bool rejected = false;
        try { BundledGoogleClient.Apply(new Settings(), () => Client("{\"type\":\"service_account\"}")); }
        catch (InvalidOperationException) { rejected = true; }
        check(rejected, "bundled client validation rejects service-account credentials");
        rejected = false;
        try { BundledGoogleClient.Apply(new Settings(), () => Client("{\"installed\":{\"client_id\":\"bad\",\"client_secret\":\"x\"}}")); }
        catch (InvalidOperationException) { rejected = true; }
        check(rejected, "bundled client validation rejects malformed desktop identities");
        string json = System.Text.Json.JsonSerializer.Serialize(ready);
        check(!json.Contains(ready.ClientId) && !json.Contains("fixture-registration"), "ordinary settings serialization excludes bundled client configuration values");
        if (Environment.GetCommandLineArgs().Contains("--require-user-client"))
        {
            check(!BundledGoogleClient.IsAvailable, "the user-owned release contains no bundled Google registration resource");
            var fresh = new Settings(); BundledGoogleClient.Apply(fresh);
            check(!fresh.HasClient && !fresh.IsSignedIn, "the actual release starts without a publisher client or saved account");
        }
        var imported = Settings.ParseClient(fixture);
        check(imported.Id == "distribution.apps.googleusercontent.com" && imported.Secret == "fixture-registration", "user-supplied Desktop JSON parses without a publisher project requirement");
        var withAccount = new Settings(); withAccount.AddAccount(new string('A', 64), "user@example.test", _ => false);
        rejected = false;
        try { withAccount.SaveClient(fixture); } catch (InvalidOperationException) { rejected = true; }
        check(rejected && !withAccount.HasClient, "replacing registration with saved accounts is rejected before changing encrypted configuration");
    }
}
