using Cloudlane;
internal sealed class FakeNetworkDriveApi : ExplorerNetworkDrive.IApi
{
    public bool Occupied;
    public int AddError, RemoveError, Adds, Removes;
    public string? Current;
    public bool LetterOccupied(string letter) => Occupied;
    public int Add(string letter, string remote)
    { Adds++; if (AddError == 0) Current = remote; return AddError; }
    public string? Remote(string letter) => Current;
    public int Remove(string letter)
    { Removes++; if (RemoveError == 0) Current = null; return RemoveError; }
}
