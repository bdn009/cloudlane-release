using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using Cloudlane;

static class DesktopWindowChecks
{
    // Runs our own window on an isolated STA dispatcher. No Google token, mount or startup writes.
    public static Task RunAsync(Action<bool, string> check)
    {
        var finished = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var thread = new Thread(() =>
        {
            Application? app = null; Exception? failure = null;
            try
            {
                app = new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown };
                app.Resources["Muted"] = new SolidColorBrush(Colors.SlateGray);
                app.Resources["Ink"] = new SolidColorBrush(Colors.Black);
                var window = new MainWindow(startInTray: true); app.MainWindow = window;
                app.DispatcherUnhandledException += (_, e) => { failure = e.Exception; e.Handled = true; app.Shutdown(1); };
                window.Show();
                app.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, new Action(async () =>
                {
                    try
                    {
                        check(!window.IsVisible && window.IsLoaded, "a Windows-startup launch initializes the real window and hides it to the tray");
                        var trayField = typeof(MainWindow).GetField("tray", BindingFlags.Instance | BindingFlags.NonPublic)!;
                        object? tray = trayField.GetValue(window);
                        check(tray != null, "the real tray component is created on the WPF dispatcher");
                        window.ShowFromTray();
                        check(window.IsVisible && window.ShowInTaskbar && window.WindowState != WindowState.Minimized,
                            "Show from tray restores the existing window to the taskbar");
                        window.Close();
                        await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ApplicationIdle);
                        check(!window.IsVisible && ReferenceEquals(tray, trayField.GetValue(window)),
                            "closing the real WPF window preserves the same running tray component");
                        window.ShowFromTray(); window.Close();
                        await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ApplicationIdle);
                        check(!window.IsVisible && ReferenceEquals(tray, trayField.GetValue(window)),
                            "repeated show/close cycles do not reinitialize settings or duplicate the tray");
                        window.ShowFromTray();
                        var checkBox = (CheckBox)window.FindName("CloseToTrayCheck");
                        check(checkBox.IsChecked == true, "the new close-to-tray preference appears enabled in the real window");
                        check(((CheckBox)window.FindName("StreamingCacheCheck")).IsChecked == true &&
                            ((TextBlock)window.FindName("CacheBadge")).Text.Contains("2 GB"),
                            "the real WPF window exposes the enabled 2 GB cache setting and labels its disk usage");
                        var autoConnect = (CheckBox)window.FindName("AutoConnectCheck");
                        check(!autoConnect.IsEnabled && autoConnect.IsChecked == false,
                            "auto-connect starts unchecked and unavailable until a Google account is saved");
                        var settings = (Settings)typeof(MainWindow).GetField("settings", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(window)!;
                        check(!BundledGoogleClient.IsAvailable || (settings.HasClient && settings.Accounts.Count == 0 &&
                            ((Button)window.FindName("ImportButton")).Visibility == Visibility.Collapsed &&
                            ((Button)window.FindName("SignInButton")).Content.ToString() == "Sign in with Google"),
                            "a fresh configured release offers direct Google sign-in and hides developer JSON setup");
                        var nameBox = (TextBox)window.FindName("DriveNameBox");
                        check(BundledGoogleClient.IsAvailable || (!settings.HasClient &&
                            ((Button)window.FindName("ImportButton")).Visibility == Visibility.Visible),
                            "a fresh user-owned release exposes Google app setup before account authorization");
                        var saveName = (Button)window.FindName("SaveDriveNameButton");
                        nameBox.Text = "  My media drive  "; saveName.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                        check(nameBox.IsEnabled && saveName.IsEnabled && Settings.Load().DriveName == "My media drive" &&
                            ((TextBlock)window.FindName("DriveDisplayLabel")).Text == "My media drive" && nameBox.Text == "My media drive",
                            "the real drive-name control saves a custom name to disk and immediately previews it in Cloudlane");
                        File.Move(Settings.SettingsPath, Settings.SettingsPath + ".check-backup");
                        Directory.CreateDirectory(Settings.SettingsPath);
                        try
                        {
                            nameBox.Text = "Unsaved name"; saveName.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                            check(settings.DriveName == "My media drive" && ((TextBlock)window.FindName("DriveDisplayLabel")).Text == "My media drive" &&
                                ((TextBlock)window.FindName("DriveNameStatus")).Text.StartsWith("Could not save"),
                                "a failed name save preserves the previous effective name and reports the failure");
                        }
                        finally { Directory.Delete(Settings.SettingsPath); File.Move(Settings.SettingsPath + ".check-backup", Settings.SettingsPath); }
                        nameBox.Text = ""; saveName.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                        check(Settings.Load().DriveName == "" && ((TextBlock)window.FindName("DriveDisplayLabel")).Text == "Google Drive" &&
                            ((TextBlock)window.FindName("DriveNameStatus")).Text.StartsWith("Automatic"),
                            "clearing and saving the name restores the automatic account label persistently");
                        string firstId = new('A', 64), secondId = new('B', 64);
                        settings.AddAccount(firstId, "first@example.test", _ => false); settings.DriveName = "First drive";
                        settings.AddAccount(secondId, "second@example.test", _ => false); settings.DriveName = "Second drive";
                        settings.Save();
                        var reset = typeof(MainWindow).GetMethod("ResetSelectedAccount", BindingFlags.Instance | BindingFlags.NonPublic)!;
                        var update = typeof(MainWindow).GetMethod("UpdateUi", BindingFlags.Instance | BindingFlags.NonPublic)!;
                        reset.Invoke(window, null); update.Invoke(window, null);
                        var accountPicker = (ComboBox)window.FindName("AccountPicker");
                        check(accountPicker.Items.Count == 2 && ((Button)window.FindName("SignInButton")).IsEnabled && nameBox.Text == "Second drive",
                            "the real window lists multiple saved accounts and keeps Add Google account available");
                        var mounts = (Dictionary<string, ExplorerMount>)typeof(MainWindow).GetField("mounts", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(window)!;
                        var firstMount = new ExplorerMount(); mounts[firstId] = firstMount;
                        typeof(ExplorerMount).GetProperty("Letter")!.SetValue(firstMount, "G:");
                        accountPicker.SelectedIndex = 0;
                        await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ApplicationIdle);
                        check(settings.AccountId == firstId && nameBox.Text == "First drive" && !nameBox.IsEnabled &&
                            !((Button)window.FindName("ForgetButton")).IsEnabled,
                            "selecting a connected account shows its own name and protects it from renaming or removal");
                        accountPicker.SelectedIndex = 1;
                        await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ApplicationIdle);
                        check(settings.AccountId == secondId && firstMount.IsMounted && nameBox.Text == "Second drive" && nameBox.IsEnabled &&
                            !((Button)window.FindName("ClearCacheButton")).IsEnabled && ((Button)window.FindName("DisconnectAllButton")).IsEnabled,
                            "switching to another account preserves the existing drive and locks shared-cache changes while any drive is connected");
                        nameBox.Text = "Second renamed"; saveName.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                        var multipleSaved = Settings.Load(); multipleSaved.SelectAccount(firstId);
                        check(multipleSaved.DriveName == "First drive" && multipleSaved.Accounts.Count == 2,
                            "saving the selected account's drive name leaves the other account's saved name intact");
                        ((ComboBox)window.FindName("LetterPicker")).SelectedItem = "J:";
                        autoConnect.IsChecked = true; autoConnect.RaiseEvent(new RoutedEventArgs(CheckBox.ClickEvent));
                        var automaticSaved = Settings.Load();
                        check(automaticSaved.Accounts.Single(a => a.Id == secondId).AutoConnect && automaticSaved.Accounts.Single(a => a.Id == secondId).Letter == "J:" &&
                            !automaticSaved.Accounts.Single(a => a.Id == firstId).AutoConnect && firstMount.IsMounted,
                            "the real auto-connect checkbox saves the selected account and chosen letter without connecting or disconnecting another drive");
                        accountPicker.SelectedIndex = 0;
                        await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ApplicationIdle);
                        check(autoConnect.IsEnabled && autoConnect.IsChecked == false,
                            "selecting another connected account restores its separate auto-connect choice and permits changing the future startup preference");
                        autoConnect.IsChecked = true; autoConnect.RaiseEvent(new RoutedEventArgs(CheckBox.ClickEvent));
                        File.Move(Settings.SettingsPath, Settings.SettingsPath + ".auto-backup"); Directory.CreateDirectory(Settings.SettingsPath);
                        try
                        {
                            autoConnect.IsChecked = false; autoConnect.RaiseEvent(new RoutedEventArgs(CheckBox.ClickEvent));
                            check(autoConnect.IsChecked == true && settings.Accounts.All(a => a.AutoConnect) &&
                                ((TextBlock)window.FindName("AutoConnectStatus")).Text.StartsWith("Could not save"),
                                "a failed auto-connect save restores both account flags and the real checkbox state");
                        }
                        finally { Directory.Delete(Settings.SettingsPath); File.Move(Settings.SettingsPath + ".auto-backup", Settings.SettingsPath); }
                        autoConnect.IsChecked = false; autoConnect.RaiseEvent(new RoutedEventArgs(CheckBox.ClickEvent));
                        check(!Settings.Load().Accounts.Single(a => a.Id == firstId).AutoConnect && Settings.Load().Accounts.Single(a => a.Id == secondId).AutoConnect,
                            "unchecking auto-connect persists an opt-out while another account stays opted in");
                        typeof(ExplorerMount).GetProperty("Letter")!.SetValue(mounts[secondId], "H:");
                        settings.Accounts.Clear(); settings.AccountId = settings.AccountEmail = settings.DriveName = ""; settings.Letter = "G:"; settings.Save();
                        reset.Invoke(window, null); update.Invoke(window, null);
                        settings.CloseToTray = false; window.Close();
                    }
                    catch (Exception ex) { failure = ex; app.Shutdown(1); }
                }));
                app.Run();
                if (failure != null) throw failure;
                check(typeof(MainWindow).GetField("tray", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(window) == null,
                    "closing with tray mode off disposes the tray and shuts down the real WPF dispatcher");
                check(((Dictionary<string, ExplorerMount>)typeof(MainWindow).GetField("mounts", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(window)!).Values.All(m => !m.IsMounted),
                    "Exit disconnects every account mount even when its account is not selected in the window");
                finished.SetResult();
            }
            catch (Exception ex) { finished.TrySetException(ex); }
        }) { IsBackground = true, Name = "Cloudlane desktop checks" };
        thread.SetApartmentState(ApartmentState.STA); thread.Start();
        return finished.Task.WaitAsync(TimeSpan.FromSeconds(20));
    }
}
