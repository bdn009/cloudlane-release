using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Cloudlane;
using Cloudlane.Mount;
using Microsoft.Win32;
using SMBLibrary;
using SMBLibrary.Server;
using SMBLibrary.Authentication.GSSAPI;

internal static class AppearanceChecks
{
    public static async Task RunAsync(Action<bool, string> check, Settings settings, string token)
    {
        const string shareName = "Cloudlane_AAAAAAAAAAAAAAAA";
        string folder = Path.Combine(AppContext.BaseDirectory, "appearance-fixtures"); Directory.CreateDirectory(folder);
        string journal = Path.Combine(folder, "recovery.json"), icon = Path.Combine(AppContext.BaseDirectory, "Assets", "GoogleDrive.ico");
        check(File.Exists(icon), "the Google Drive icon is deployed with the app and referencing test project");
        check(ExplorerAppearance.Label("Test User", "test@example.com") == "Google Drive - Test User" &&
            ExplorerAppearance.Label("", "test@example.com") == "Google Drive - test@example.com" &&
            ExplorerAppearance.Label("", "") == "Google Drive", "friendly drive names use the account display name with email and generic fallbacks");
        check(!ExplorerAppearance.Label("Name\r\n\t", "").Contains('\n') && ExplorerAppearance.Label(new string('x', 500), "").Length <= 96,
            "Explorer labels strip control characters and stay within a bounded length");
        check(ExplorerAppearance.Label("Test User", "test@example.com", "  My media drive  ") == "My media drive" &&
            ExplorerAppearance.Label("Test User", "", " \r\n\t") == "Google Drive - Test User",
            "custom names override the account label verbatim and a blank name restores the automatic label");
        check(ExplorerAppearance.NormalizeCustomLabel(new string('x', 95) + "\U0001F4C1 folder") == new string('x', 95) &&
            ExplorerAppearance.NormalizeCustomLabel("  Media\r\n\t drive  ") == "Media drive",
            "saved custom labels remove control characters and truncate without splitting an emoji");
        string[] paths = ExplorerAppearance.Paths("H:", shareName);
        check(paths[0].EndsWith(@"MountPoints2\##127.0.0.1#" + shareName) && paths[1].EndsWith(@"DriveIcons\H\DefaultIcon"),
            "shell appearance is scoped to the exact owned loopback share and selected letter");
        bool badPath = false; try { ExplorerAppearance.Paths("C:", "other-share"); } catch (IOException) { badPath = true; }
        check(badPath, "appearance refuses a system letter or arbitrary network share");
        var shell = new FakeShellSettings(); shell.Values[(paths[1], "")] = new("%SystemRoot%\\old.ico", RegistryValueKind.ExpandString);
        int notifications = 0;
        var appearance = new ExplorerAppearance("H:", shareName, "Google Drive - Test User", icon, journal, shell, _ => notifications++);
        check(shell.Values[(paths[0], "_LabelFromReg")].Text == "Google Drive - Test User" && shell.Values[(paths[2], "")].Text == "Google Drive - Test User",
            "friendly label replaces the random share name in both shell label locations");
        check(shell.Values[(paths[1], "")].Text == "\"" + icon + "\",0" && notifications == 1 && File.Exists(journal),
            "icon paths are quoted and prior shell settings are saved before decoration");
        appearance.Dispose(); appearance.Dispose();
        check(shell.Values.Count == 1 && shell.Values[(paths[1], "")].Kind == RegistryValueKind.ExpandString && !File.Exists(journal),
            "disconnect restores the previous icon and registry value kind without disturbing unrelated settings");
        var previous = new ExplorerAppearance("H:", shareName, "Old session", icon, journal, shell, _ => { });
        shell.Values[(paths[2], "")] = new("User's new name");
        ExplorerAppearance.Restore(journal, shell, _ => { });
        check(shell.Values[(paths[2], "")].Text == "User's new name", "crash recovery preserves a name changed by the user after mounting");
        var current = new ExplorerAppearance("H:", shareName, "Current session", icon, journal, shell, _ => { });
        previous.Dispose();
        check(shell.Values[(paths[2], "")].Text == "Current session" && File.Exists(journal), "a stale appearance object cannot undo a newer session's decoration");
        current.Dispose();
        int before = shell.Values.Count; shell.FailOnWrite = shell.Writes + 2; bool rolledBack = false;
        try { new ExplorerAppearance("H:", shareName, "Partial", icon, journal, shell, _ => { }); } catch (UnauthorizedAccessException) { rolledBack = true; }
        check(rolledBack && shell.Values.Count == before && !File.Exists(journal), "a partial appearance write rolls back changed values and retains prior preferences");
        var retry = new ExplorerAppearance("H:", shareName, "Retry", icon, journal, shell, _ => { }); shell.Denied = true; bool retryNeeded = false;
        try { retry.Dispose(); } catch (UnauthorizedAccessException) { retryNeeded = true; }
        shell.Denied = false; retry.Dispose();
        check(retryNeeded && !File.Exists(journal) && shell.Values.Count == before, "failed decoration cleanup retains recovery data and succeeds when retried");

        long tb = 1024L * 1024 * 1024 * 1024;
        using var api = new GoogleDriveApi(settings, new OverviewHandler(), token);
        var info = await api.OverviewAsync(CancellationToken.None);
        check(info.Label == "Google Drive - Test Account" && info.Capacity == new CloudCapacity(5 * tb, 4 * tb),
            "account overview fetches the authenticated name and exact Google storage quota");
        check(Math.Abs(info.UsedPercent - 20) < .001 && info.StorageText.Contains("TB") && info.StorageText.Contains("free of"),
            "storage display handles terabyte accounts and calculates the used-space bar");
        using var unlimited = JsonDocument.Parse("{\"usage\":\"1234\"}");
        check(GoogleDriveApi.ParseCapacity(unlimited.RootElement) == new CloudCapacity(0, 0), "accounts without a finite Google quota never fabricate a disk capacity from used space");
        using var over = JsonDocument.Parse("{\"limit\":\"100\",\"usage\":\"200\"}");
        check(GoogleDriveApi.ParseCapacity(over.RootElement).FreeBytes == 0, "over-quota accounts report zero free space without a negative bar");
        using var invalid = JsonDocument.Parse("{\"limit\":\"-1\",\"usage\":\"0\"}"); bool invalidQuota = false;
        try { GoogleDriveApi.ParseCapacity(invalid.RootElement); } catch (IOException) { invalidQuota = true; }
        check(invalidQuota, "invalid quota values are rejected instead of displayed as valid storage");
        var root = new DriveFile("root", "My Drive", "application/vnd.google-apps.folder", 0, DateTimeOffset.UtcNow, "1", "", Array.Empty<string>(), "", true);
        var tree = new GoogleTree(api, root, 5 * tb, 4 * tb, CancellationToken.None, info.Label);
        var store = new CloudFileStore(tree);
        store.GetFileSystemInformation(out var volume, FileSystemInformationClass.FileFsVolumeInformation);
        check(((FileFsVolumeInformation)volume).VolumeLabel == info.Label, "the SMB volume label also identifies the Google account");
        store.GetFileSystemInformation(out var size, FileSystemInformationClass.FileFsFullSizeInformation);
        check(((FileFsFullSizeInformation)size).TotalAllocationUnits * 4096 == 5 * tb && ((FileFsFullSizeInformation)size).CallerAvailableAllocationUnits * 4096 == 4 * tb,
            "Explorer disk-space replies expose the actual multi-terabyte total and available bytes");

        var namedSettings = new Settings { DriveName = "My media drive" };
        var namedTree = new GoogleTree(api, root, 5 * tb, 4 * tb, CancellationToken.None, namedSettings.DriveLabel(info));
        var namedStore = new CloudFileStore(namedTree);

        using var reservation = new TcpListener(LocalSmbEndpoint.Address, 0); reservation.Start(); int port = ((IPEndPoint)reservation.LocalEndpoint).Port; reservation.Stop();
        var shares = new SMBShareCollection(); shares.Add(new FileSystemShare("Cloudlane", namedStore, CachingPolicy.NoCaching));
        var server = new TestServer(shares, new GSSProvider(new CloudlaneAuthentication("quota-check-password"))); server.Listen(port);
        var client = new TestSmbClient();
        try
        {
            check(client.Link(port) && client.Login("", "Cloudlane", "quota-check-password") == NTStatus.STATUS_SUCCESS, "signed SMB authenticates for native protocol storage queries");
            var share = client.TreeConnect("Cloudlane", out var status);
            check(status == NTStatus.STATUS_SUCCESS && share.GetFileSystemInformation(out var namedVolume, FileSystemInformationClass.FileFsVolumeInformation) == NTStatus.STATUS_SUCCESS &&
                ((FileFsVolumeInformation)namedVolume).VolumeLabel == "My media drive",
                "the saved custom drive name is returned as the volume label over real signed SMB traffic");
            check(status == NTStatus.STATUS_SUCCESS && share.GetFileSystemInformation(out var full, FileSystemInformationClass.FileFsFullSizeInformation) == NTStatus.STATUS_SUCCESS &&
                ((FileFsFullSizeInformation)full).CallerAvailableAllocationUnits * 4096 == 4 * tb, "a real signed SMB response carries the Google free-space value");
            namedTree.UpdateCapacity(new(5 * tb, 3 * tb));
            check(share.GetFileSystemInformation(out var changed, FileSystemInformationClass.FileFsFullSizeInformation) == NTStatus.STATUS_SUCCESS &&
                ((FileFsFullSizeInformation)changed).CallerAvailableAllocationUnits * 4096 == 3 * tb, "updated quota is visible over the existing SMB connection without remounting");
            share.Disconnect(); client.Logoff();
        }
        finally { client.Disconnect(); server.Stop(); }
    }
    private sealed class FakeShellSettings : IShellSettings
    {
        public Dictionary<(string, string), ShellText> Values = new(); public int Writes, FailOnWrite; public bool Denied;
        public ShellText? Read(string path, string name) => Values.GetValueOrDefault((path, name));
        public void Write(string path, string name, ShellText value)
        { if (Denied || ++Writes == FailOnWrite) throw new UnauthorizedAccessException("fixture"); Values[(path, name)] = value; }
        public void Remove(string path, string name) { if (Denied) throw new UnauthorizedAccessException("fixture"); Values.Remove((path, name)); }
    }
    private sealed class OverviewHandler : HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken token)
        {
            long tb = 1024L * 1024 * 1024 * 1024;
            var body = new { user = new { displayName = "Test Account", emailAddress = "test@example.com" }, storageQuota = new { limit = (5 * tb).ToString(), usage = tb.ToString() } };
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json") });
        }
    }
}
