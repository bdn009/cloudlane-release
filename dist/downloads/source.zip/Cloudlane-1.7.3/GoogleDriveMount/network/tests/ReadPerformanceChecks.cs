using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Cloudlane;
using Cloudlane.Mount;
using SMBLibrary;
using SMBLibrary.Server;
using SMBLibrary.Authentication.GSSAPI;

internal static class ReadPerformanceChecks
{
    public static async Task RunAsync(Action<bool, string> check, Settings settings, string token)
    {
        var originalFiles = Directory.GetFiles(AppContext.BaseDirectory, "*", SearchOption.AllDirectories).OrderBy(p => p).ToArray();
        int fetched = 0, maxFetch = 0;
        byte[] Fetch(long offset, int count, CancellationToken ct)
        { ct.ThrowIfCancellationRequested(); fetched++; maxFetch = Math.Max(maxFetch, count); return Enumerable.Range(0, count).Select(i => (byte)((offset + i) % 251)).ToArray(); }
        using (var reader = new CloudReadBuffer(6L * 1024 * 1024 * 1024, Fetch, CancellationToken.None))
        {
            for (int i = 0; i < 16; i++)
            {
                byte[] data = reader.Read(i * 4096, 4096);
                if (data.Length != 4096 || data[0] != (byte)(i * 4096 % 251)) throw new Exception("Incorrect buffered bytes");
            }
            check(fetched == 1 && maxFetch == CloudReadBuffer.BlockSize, "many small image reads share one bounded 1 MiB Google transfer");
            byte[] across = reader.Read(CloudReadBuffer.BlockSize - 100, 200);
            check(across.Length == 200 && across.Select((b, i) => b == (byte)((CloudReadBuffer.BlockSize - 100 + i) % 251)).All(x => x) && fetched == 2,
                "a read crossing a transfer window returns exact bytes without an early end-of-file");
            long tail = 6L * 1024 * 1024 * 1024 - 20;
            byte[] seek = reader.Read(tail, 1024);
            check(seek.Length == 20 && seek[0] == (byte)(tail % 251), "video seeks beyond 4 GiB remain bounded and clamp to the real end of file");
        }
        var owned = new List<CloudReadBuffer>(); int pressureCalls = 0;
        byte[] Pressure(long offset, int count, CancellationToken ct) { pressureCalls++; return new byte[count]; }
        try
        {
            for (int i = 0; i < CloudReadBuffer.MaxBufferedReaders; i++)
            { var reader = new CloudReadBuffer(2 * CloudReadBuffer.BlockSize, Pressure, CancellationToken.None); owned.Add(reader); reader.Read(0, 4); }
            using var overflow = new CloudReadBuffer(CloudReadBuffer.BlockSize, Pressure, CancellationToken.None);
            int start = pressureCalls; overflow.Read(0, 4); overflow.Read(0, 4);
            check(pressureCalls - start == 2, "more than sixteen open readers fall back to bounded direct reads rather than retain more buffers");
            owned[0].Dispose(); owned[0].Dispose(); start = pressureCalls;
            overflow.Read(0, 4); overflow.Read(0, 4);
            check(pressureCalls - start == 1, "closing a file releases its buffer budget exactly once for another reader");
        }
        finally { foreach (var reader in owned) reader.Dispose(); }
        using (var closed = new CloudReadBuffer(10, Fetch, CancellationToken.None))
        {
            closed.Dispose(); bool rejected = false; try { closed.Read(0, 1); } catch (OperationCanceledException) { rejected = true; }
            check(rejected, "a closed read handle cannot serve retained image bytes");
        }
        var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var cancelReader = new CloudReadBuffer(100, (_, count, ct) =>
        { entered.SetResult(); ct.WaitHandle.WaitOne(); ct.ThrowIfCancellationRequested(); return new byte[count]; }, CancellationToken.None);
        Task pending = Task.Run(() => { try { cancelReader.Read(0, 4); } catch (OperationCanceledException) { return; } throw new Exception("Read was not cancelled"); });
        await entered.Task.WaitAsync(TimeSpan.FromSeconds(3));
        await Task.Run(cancelReader.Dispose).WaitAsync(TimeSpan.FromSeconds(3)); await pending;
        check(pending.IsCompletedSuccessfully, "closing a file cancels an in-flight network read before waiting for its lock");

        using var remote = new ImageHandler { Delay = 8 };
        using var api = new GoogleDriveApi(settings, remote, token);
        var root = new DriveFile("root", "My Drive", "application/vnd.google-apps.folder", 0, DateTimeOffset.UtcNow, "1", "", Array.Empty<string>(), "", true);
        var tree = new GoogleTree(api, root, 15000000000, 10000000000, CancellationToken.None);
        var file = tree.Resolve("\\image.jpg");
        int originalCalls = remote.TotalCalls; var slow = Stopwatch.StartNew();
        for (int offset = 0; offset < ImageHandler.Length; offset += 65536) tree.Read(file, offset, 65536);
        slow.Stop(); originalCalls = remote.TotalCalls - originalCalls;
        int optimizedStart = remote.TotalCalls; var fast = Stopwatch.StartNew();
        using (var reader = tree.OpenRead(file)!)
            for (int offset = 0; offset < ImageHandler.Length; offset += 65536)
            {
                var data = reader.Read(offset, 65536);
                if (data.Length != 65536 || data[0] != (byte)(offset % 251)) throw new Exception("Image data differs");
            }
        fast.Stop(); int optimizedCalls = remote.TotalCalls - optimizedStart;
        check(originalCalls == 64 && optimizedCalls == 6, "a 2 MiB image read in 64 KiB pieces drops from 64 Google requests to 6, including version checks");
        Console.WriteLine($"BENCH simulated 8ms Google round trip: 2MiB image old={slow.ElapsedMilliseconds}ms/{originalCalls} requests, buffered={fast.ElapsedMilliseconds}ms/{optimizedCalls} requests; not a live Google speed measurement.");
        using (var reader = tree.OpenRead(file)!)
        {
            remote.Version = "2"; bool changed = false;
            try { reader.Read(0, 64); } catch (IOException) { changed = true; }
            check(changed, "a changed cloud version is rejected before a new transfer buffer is exposed");
        }
        remote.Version = "1"; remote.ChangeDuringDownload = true;
        using (var reader = tree.OpenRead(file)!)
        {
            bool changed = false; try { reader.Read(0, 64); } catch (IOException) { changed = true; }
            check(changed, "a cloud version changed during download is rejected by post-transfer validation");
        }
        remote.Version = "1"; remote.ChangeDuringDownload = false; remote.Delay = 0;
        var store = new CloudFileStore(tree);
        using var reservation = new TcpListener(LocalSmbEndpoint.Address, 0); reservation.Start(); int port = ((IPEndPoint)reservation.LocalEndpoint).Port; reservation.Stop();
        var shares = new SMBShareCollection(); shares.Add(new FileSystemShare("Cloudlane", store, CachingPolicy.NoCaching));
        var server = new TestServer(shares, new GSSProvider(new CloudlaneAuthentication("read-check-password"))); server.Listen(port);
        var client = new TestSmbClient();
        try
        {
            check(client.Link(port) && client.Login("", "Cloudlane", "read-check-password") == NTStatus.STATUS_SUCCESS, "signed SMB authenticates for image read coalescing");
            var share = client.TreeConnect("Cloudlane", out _);
            check(share.CreateFile(out var opened, out _, "image.jpg", AccessMask.GENERIC_READ, 0, ShareAccess.Read, CreateDisposition.FILE_OPEN, 0, null!) == NTStatus.STATUS_SUCCESS,
                "a normal SMB file handle lazily creates its image read session");
            int before = remote.TotalCalls;
            for (int offset = 0; offset < ImageHandler.Length; offset += 65536)
            {
                if (share.ReadFile(out var bytes, opened, offset, 65536) != NTStatus.STATUS_SUCCESS || bytes.Length != 65536 || bytes[0] != (byte)(offset % 251)) throw new Exception("SMB image mismatch");
            }
            check(remote.TotalCalls - before == 6, "real signed SMB image reads use the optimized six-request path");
            share.CloseFile(opened); share.Disconnect(); client.Logoff();
        }
        finally { client.Disconnect(); server.Stop(); }
        check(originalFiles.SequenceEqual(Directory.GetFiles(AppContext.BaseDirectory, "*", SearchOption.AllDirectories).OrderBy(p => p)), "optimized image streaming creates no additional payload or staging files on disk");
    }
    private sealed class ImageHandler : HttpMessageHandler
    {
        public const int Length = 2 * 1024 * 1024;
        public int TotalCalls, Delay; public string Version = "1"; public bool ChangeDuringDownload;
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
        {
            Interlocked.Increment(ref TotalCalls); if (Delay > 0) await Task.Delay(Delay, ct);
            object Meta() => new { id = "image", name = "image.jpg", mimeType = "image/jpeg", size = Length.ToString(), version = Version, modifiedTime = "2026-10-16T00:00:00Z" };
            if (request.Headers.Range != null)
            {
                var range = request.Headers.Range.Ranges.Single(); int count = checked((int)(range.To!.Value - range.From!.Value + 1));
                byte[] data = Enumerable.Range(0, count).Select(i => (byte)((range.From.Value + i) % 251)).ToArray();
                var response = new HttpResponseMessage(HttpStatusCode.PartialContent) { Content = new ByteArrayContent(data) };
                response.Content.Headers.ContentRange = new ContentRangeHeaderValue(range.From.Value, range.To.Value, Length);
                if (ChangeDuringDownload) Version = "2"; return response;
            }
            object payload = request.RequestUri!.AbsolutePath.EndsWith("/files") ? new { files = new[] { Meta() } } : Meta();
            return new(HttpStatusCode.OK) { Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json") };
        }
    }
}
