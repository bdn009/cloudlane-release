using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Cloudlane;
using Cloudlane.Mount;
using SMBLibrary;

internal static class MultiAccountChecks
{
    private static readonly string A = new('A', 64), B = new('B', 64);
    internal static async Task RunAsync(Action<bool, string> check)
    {
        var settings = new Settings { AccountId = A, AccountEmail = "first@example.test", Letter = "G:", DriveName = "First drive" };
        settings.InitializeAccounts();
        settings.AddAccount(B, "second@example.test", _ => false);
        check(settings.Accounts.Count == 2 && settings.Letter == "H:" && settings.DriveName == "",
            "a second Google account gets its own available letter without inheriting the first account's custom name");
        settings.DriveName = "Second drive"; var second = settings.Snapshot();
        settings.SelectAccount(A); var first = settings.Snapshot();
        check(settings.DriveName == "First drive" && settings.Letter == "G:" && first.TokenPath != second.TokenPath && first.QueuePath != second.QueuePath,
            "selecting accounts restores independent names and letters with separate token and upload-queue paths");
        settings.AddAccount(B, "second@example.test", _ => false);
        check(settings.Accounts.Count == 2 && settings.DriveName == "Second drive" && settings.Letter == "H:",
            "signing in to an already saved account updates it without duplicating or resetting its drive preferences");
        check(Settings.NextLetter(new[] { "G:", "H:" }, l => l == "I:") == "J:",
            "automatic letter assignment skips saved-account letters and letters occupied by Windows");
        bool exhausted = false; try { Settings.NextLetter(Array.Empty<string>(), _ => true); } catch (IOException) { exhausted = true; }
        check(exhausted, "adding an account reports drive-letter exhaustion instead of replacing an existing drive");
        var restored = JsonSerializer.Deserialize<Settings>(JsonSerializer.Serialize(settings))!; restored.InitializeAccounts();
        restored.SelectAccount(A);
        check(restored.Accounts.Count == 2 && restored.DriveName == "First drive" && restored.AccountEmail == "first@example.test",
            "multiple accounts and the selected account's preferences survive a settings round trip");
        var invalid = new Settings { Accounts = new() { new() { Id = "..\\escape" }, new() { Id = A }, new() { Id = A.ToLowerInvariant() } } };
        invalid.InitializeAccounts();
        check(invalid.Accounts.Count == 1 && invalid.AccountId == A, "invalid account paths and duplicate identities cannot enter the saved-account catalog");
        settings.RemoveSelected();
        check(settings.AccountId == A && settings.Accounts.Count == 1 && settings.DriveName == "First drive",
            "removing the selected account retains another account and its drive preferences");

        Settings.Prepare();
        string? original = File.Exists(Settings.SettingsPath) ? File.ReadAllText(Settings.SettingsPath) : null;
        try
        {
            var legacy = new Settings { AccountId = A, AccountEmail = "legacy@example.test", Letter = "K:", DriveName = "Existing drive" };
            byte[] encryptedFixture = Encoding.UTF8.GetBytes("already-encrypted-legacy-fixture");
            File.WriteAllBytes(Settings.ConfigPath, encryptedFixture); legacy.InitializeAccounts(); legacy.MigrateLegacyToken();
            var migrated = Settings.Load();
            check(migrated.Accounts.Count == 1 && migrated.IsSignedIn && migrated.Letter == "K:" && migrated.DriveName == "Existing drive" &&
                File.ReadAllBytes(migrated.TokenPath).SequenceEqual(encryptedFixture) && !File.Exists(Settings.ConfigPath),
                "upgrade moves the existing encrypted sign-in into its account folder and preserves the name and letter without reauthorization");
            File.WriteAllBytes(Settings.ConfigPath, new byte[] { 1, 2 }); migrated.AccountsVersion = 0; migrated.MigrateLegacyToken();
            check(File.ReadAllBytes(migrated.TokenPath).SequenceEqual(encryptedFixture), "migration never overwrites an existing account token with a legacy file");
            File.Delete(migrated.TokenPath);
            File.Move(Settings.SettingsPath, Settings.SettingsPath + ".multi-backup"); Directory.CreateDirectory(Settings.SettingsPath);
            try
            {
                bool failed = false;
                try { migrated.SaveAccountChange(s => s.AddAccount(B, "second@example.test", _ => false)); } catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException) { failed = true; }
                check(failed && migrated.AccountId == A && migrated.Accounts.Count == 1,
                    "a failed account-catalog save rolls back the selected identity and account list");
            }
            finally { Directory.Delete(Settings.SettingsPath); File.Move(Settings.SettingsPath + ".multi-backup", Settings.SettingsPath); }
        }
        finally
        {
            File.Delete(Settings.ConfigPath);
            if (original == null) File.Delete(Settings.SettingsPath); else File.WriteAllText(Settings.SettingsPath, original);
        }

        string tokenA = Token("account-a"), tokenB = Token("account-b");
        var mutable = first.Snapshot();
        var httpA = new AccountHandler("account-a", 17); var httpB = new AccountHandler("account-b", 83);
        using var apiA = new GoogleDriveApi(mutable, httpA, tokenA);
        mutable.AccountId = B; mutable.ClientId = "changed.apps.googleusercontent.com";
        var frozen = (Settings)typeof(GoogleDriveApi).GetField("settings", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(apiA)!;
        check(frozen.TokenPath == first.TokenPath && frozen.ClientId != mutable.ClientId,
            "an active Google client freezes its account token path and OAuth client while the UI selects another account");
        using var apiB = new GoogleDriveApi(second, httpB, tokenB);
        var root = new DriveFile("root", "My Drive", "application/vnd.google-apps.folder", 0, DateTimeOffset.UtcNow, "1", "", Array.Empty<string>(), "", true);
        using var stopA = new CancellationTokenSource(); using var stopB = new CancellationTokenSource();
        var treeA = new GoogleTree(apiA, root, 409600, 204800, stopA.Token, first.DriveName);
        var treeB = new GoogleTree(apiB, root, 819200, 614400, stopB.Token, second.DriveName);
        var storeA = new CloudFileStore(treeA); var storeB = new CloudFileStore(treeB);
        using var leaseA = ExplorerServerPool.Acquire(storeA, _ => { });
        using var leaseB = ExplorerServerPool.Acquire(storeB, _ => { });
        check(leaseA.Port == leaseB.Port && leaseA.Password == leaseB.Password && leaseA.ShareName != leaseB.ShareName,
            "two accounts share a Windows SMB endpoint and credential with distinct account shares");
        await LocalSmbEndpoint.CheckAsync(leaseA.Port, leaseA.ShareName, leaseA.Password, CancellationToken.None);
        await LocalSmbEndpoint.CheckAsync(leaseB.Port, leaseB.ShareName, leaseB.Password, CancellationToken.None);
        var client = new TestSmbClient();
        try
        {
            check(client.Link(leaseA.Port) && client.Login("CLOUDLANE", "Cloudlane", leaseA.Password) == NTStatus.STATUS_SUCCESS,
                "one real signed SMB session authenticates to the multi-account listener");
            var shareA = client.TreeConnect(leaseA.ShareName, out var statusA);
            var shareB = client.TreeConnect(leaseB.ShareName, out var statusB);
            check(statusA == NTStatus.STATUS_SUCCESS && statusB == NTStatus.STATUS_SUCCESS,
                "one signed session opens both account shares simultaneously");
            foreach (var item in new[] { (Share: shareA, Name: "First drive", Value: (byte)17, Free: 204800L), (Share: shareB, Name: "Second drive", Value: (byte)83, Free: 614400L) })
            {
                item.Share.GetFileSystemInformation(out var volume, FileSystemInformationClass.FileFsVolumeInformation);
                item.Share.GetFileSystemInformation(out var space, FileSystemInformationClass.FileFsFullSizeInformation);
                check(((FileFsVolumeInformation)volume).VolumeLabel == item.Name && ((FileFsFullSizeInformation)space).CallerAvailableAllocationUnits * 4096 == item.Free,
                    "each simultaneously connected account returns its own volume name and Google quota: " + item.Name);
                var opened = item.Share.CreateFile(out var handle, out _, "same.bin", AccessMask.GENERIC_READ, 0, ShareAccess.Read,
                    CreateDisposition.FILE_OPEN, CreateOptions.FILE_NON_DIRECTORY_FILE, null!);
                check(opened == NTStatus.STATUS_SUCCESS && item.Share.ReadFile(out var bytes, handle, 0, 128) == NTStatus.STATUS_SUCCESS && bytes.Length == 128 && bytes.All(b => b == item.Value),
                    "identical file paths and Google file IDs resolve to the correct account's bytes: " + item.Name);
                item.Share.CloseFile(handle);
            }
            shareA.Disconnect(); stopA.Cancel(); storeA.AbortUploads(); leaseA.Dispose(); leaseA.Dispose();
            client.TreeConnect(leaseA.ShareName, out var removedStatus);
            check(removedStatus != NTStatus.STATUS_SUCCESS && shareB.GetFileSystemInformation(out _, FileSystemInformationClass.FileFsVolumeInformation) == NTStatus.STATUS_SUCCESS,
                "disconnecting one account removes only its share and preserves the other signed connection");
            using (var third = ExplorerServerPool.Acquire(new CloudFileStore(treeA), _ => { }))
                check(third.Port == leaseB.Port && third.Password == leaseB.Password, "adding another share after a disconnect reuses the surviving listener and Windows credential");
            shareB.Disconnect(); client.Logoff();
        }
        finally { client.Disconnect(); }
        check(httpA.Requests > 0 && httpB.Requests > 0 && !httpA.WrongToken && !httpB.WrongToken,
            "all simulated Google requests retain the matching account's access token while both shares are connected");

        string folder = Path.Combine(AppContext.BaseDirectory, "multi-account-cache");
        using var callerA = new CancellationTokenSource();
        var cacheA = await StreamingCachePool.AcquireAsync(folder, callerA.Token);
        var cacheB = await StreamingCachePool.AcquireAsync(folder, CancellationToken.None);
        try
        {
            check(ReferenceEquals(cacheA.Cache, cacheB.Cache) && cacheA.Cache.CapacityBytes == 2147483648L,
                "simultaneous drives share one 2 GiB cache budget instead of creating a separate 2 GiB cache per account");
            await cacheA.Cache.GetAsync(A + "|same-file", 0, 128, _ => Task.FromResult(Enumerable.Repeat((byte)17, 128).ToArray()), true, CancellationToken.None);
            callerA.Cancel(); await cacheA.DisposeAsync(); await cacheA.DisposeAsync();
            var other = await cacheB.Cache.GetAsync(B + "|same-file", 0, 128, _ => Task.FromResult(Enumerable.Repeat((byte)83, 128).ToArray()), true, CancellationToken.None);
            var firstBytes = await cacheB.Cache.GetAsync(A + "|same-file", 0, 128, _ => throw new Exception("Expected cached bytes"), true, CancellationToken.None);
            check(other.All(b => b == 83) && firstBytes.All(b => b == 17),
                "disconnecting one cache lease leaves other accounts working and keeps matching file IDs isolated by account");
        }
        finally { await cacheA.DisposeAsync(); await cacheB.DisposeAsync(); }
        MediaBlockCache.ClearStored(folder);
        check(MediaBlockCache.Inspect(folder) == 0, "the shared cache releases its disk lock after the last drive disconnects");
    }
    private static string Token(string access) => JsonSerializer.Serialize(new { access_token = access, refresh_token = "refresh", expiry = DateTimeOffset.UtcNow.AddHours(1).ToString("O") });
    private sealed class AccountHandler(string access, byte value) : HttpMessageHandler
    {
        internal int Requests; internal bool WrongToken;
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
        {
            Interlocked.Increment(ref Requests); if (request.Headers.Authorization?.Parameter != access) WrongToken = true;
            if (request.RequestUri!.Query.Contains("alt=media"))
            {
                long from = request.Headers.Range!.Ranges.First().From!.Value, to = request.Headers.Range.Ranges.First().To!.Value;
                var response = new HttpResponseMessage(HttpStatusCode.PartialContent) { Content = new ByteArrayContent(Enumerable.Repeat(value, (int)(to - from + 1)).ToArray()) };
                response.Content.Headers.ContentRange = new ContentRangeHeaderValue(from, to, 128); return Task.FromResult(response);
            }
            object file = new { id = "same-id", name = "same.bin", mimeType = "application/octet-stream", size = "128", version = "1", modifiedTime = "2026-10-17T00:00:00Z", capabilities = new { canEdit = true, canDownload = true } };
            object body = request.RequestUri.AbsolutePath.EndsWith("/files") ? new { files = new[] { file } } : file;
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json") });
        }
    }
}
