using System;
using System.Collections.Concurrent;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Cloudlane;
using Cloudlane.Mount;
using SMBLibrary;
using SMBLibrary.Server;
using SMBLibrary.Authentication.GSSAPI;

internal static class MediaCacheChecks
{
    private static readonly TimeSpan Deadline = TimeSpan.FromSeconds(8);
    private static async Task Until(Func<bool> condition)
    { using var limit = new CancellationTokenSource(Deadline); while (!condition()) await Task.Delay(10, limit.Token); }
    private static Task<byte[]> Data(int length, byte value = 7)
    { var bytes = new byte[length]; Array.Fill(bytes, value); return Task.FromResult(bytes); }
    public static async Task RunAsync(Action<bool, string> check, Settings settings, string token)
    {
        string fixtures = Path.Combine(AppContext.BaseDirectory, "media-cache-fixtures"); Directory.CreateDirectory(fixtures);
        string Folder() => Path.Combine(fixtures, Guid.NewGuid().ToString("N"));
        check(new Settings().StreamingCacheEnabled && MediaBlockCache.DefaultCapacity == 2147483648L,
            "the requested streaming cache defaults to enabled with a 2 GiB total capacity");
        var persisted = JsonSerializer.Deserialize<Settings>(JsonSerializer.Serialize(new Settings { StreamingCacheEnabled = false, StreamingCacheBaseDirectory = fixtures }))!;
        check(!persisted.StreamingCacheEnabled && persisted.StreamingCacheDirectory.StartsWith(fixtures), "cache opt-out and chosen local folder survive settings serialization");
        string root = Folder(); int fetches = 0;
        async Task<byte[]> Fetch(CancellationToken ct) { Interlocked.Increment(ref fetches); await Task.Yield(); ct.ThrowIfCancellationRequested(); return await Data(128); }
        await using (var cache = new MediaBlockCache(root, CancellationToken.None, 512))
        {
            await cache.GetAsync("A", 0, 128, Fetch, true, CancellationToken.None);
            await cache.GetAsync("B", 0, 128, Fetch, true, CancellationToken.None);
            await cache.GetAsync("A", 0, 128, Fetch, true, CancellationToken.None);
            await cache.GetAsync("C", 0, 128, Fetch, true, CancellationToken.None);
            check(fetches == 3 && cache.Contains("A", 0, 128) && !cache.Contains("B", 0, 128) && cache.Contains("C", 0, 128),
                "cache hits reuse disk content and least-recently-used blocks are evicted first");
            check(cache.UsedBytes <= 512 && MediaBlockCache.Inspect(root) <= 512, "capacity includes block headers and actual cached files stay within the limit");
            bool exclusive = false; try { await using var duplicate = new MediaBlockCache(root, CancellationToken.None); } catch (IOException) { exclusive = true; }
            check(exclusive, "a second writer cannot open the same active cache folder");
            bool clearBlocked = false; try { MediaBlockCache.ClearStored(root); } catch (IOException) { clearBlocked = true; }
            check(clearBlocked && cache.Contains("A", 0, 128), "clearing an active cache is blocked instead of deleting data under playback");
        }
        await using (var reopened = new MediaBlockCache(root, CancellationToken.None, 512))
        {
            int before = fetches; await reopened.GetAsync("A", 0, 128, Fetch, true, CancellationToken.None);
            check(fetches == before, "cached blocks are reused after disconnect and restart");
            string block = Path.Combine(root, MediaBlockCache.Key("A", 0, 128) + ".block");
            var corrupt = File.ReadAllBytes(block); corrupt[^1] ^= 1; File.WriteAllBytes(block, corrupt);
            var bytes = await reopened.GetAsync("A", 0, 128, Fetch, true, CancellationToken.None);
            check(fetches == before + 1 && bytes.All(b => b == 7), "a corrupted cached block is rejected and downloaded again");
            string unrelated = Path.Combine(root, "user-note.txt"); File.WriteAllText(unrelated, "leave this alone");
        }
        MediaBlockCache.ClearStored(root);
        check(MediaBlockCache.Inspect(root) == 0 && File.Exists(Path.Combine(root, "user-note.txt")), "Clear cache removes owned blocks and preserves unrelated files");
        string unrelatedRoot = Folder(); Directory.CreateDirectory(unrelatedRoot); File.WriteAllText(Path.Combine(unrelatedRoot, "file.txt"), "original");
        bool refused = false; try { MediaBlockCache.ClearStored(unrelatedRoot); } catch (IOException) { refused = true; }
        check(refused && File.ReadAllText(Path.Combine(unrelatedRoot, "file.txt")) == "original", "cache cleanup refuses an unmarked folder");
        string partialRoot = Folder();
        await using (var initial = new MediaBlockCache(partialRoot, CancellationToken.None)) { }
        string partial = Path.Combine(partialRoot, new string('A', 64) + ".tmp." + new string('b', 32)); File.WriteAllText(partial, "incomplete");
        await using (var recovered = new MediaBlockCache(partialRoot, CancellationToken.None))
            check(!File.Exists(partial), "restart removes only recognized abandoned partial cache files");

        string sharingRoot = Folder();
        await using (var shared = new MediaBlockCache(sharingRoot, CancellationToken.None))
        {
            var started = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            var release = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously); int calls = 0;
            async Task<byte[]> Slow(CancellationToken ct) { Interlocked.Increment(ref calls); started.TrySetResult(); await release.Task.WaitAsync(ct); return await Data(128, 9); }
            using var firstCancel = new CancellationTokenSource();
            var first = shared.GetAsync("shared", 0, 128, Slow, true, firstCancel.Token);
            await started.Task.WaitAsync(Deadline);
            var second = shared.GetAsync("shared", 0, 128, Slow, true, CancellationToken.None);
            firstCancel.Cancel(); bool firstStopped = false; try { await first; } catch (OperationCanceledException) { firstStopped = true; }
            release.SetResult(); var secondData = await second.WaitAsync(Deadline);
            check(firstStopped && calls == 1 && secondData[0] == 9, "duplicate playback reads share one download; closing one reader does not cancel the other");
            var canceled = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            using var only = new CancellationTokenSource();
            var pending = shared.GetAsync("cancel", 0, 128, async ct =>
            { entered.SetResult(); try { await Task.Delay(Timeout.Infinite, ct); } catch (OperationCanceledException) { canceled.TrySetResult(); throw; } return new byte[128]; }, false, only.Token);
            await entered.Task.WaitAsync(Deadline); only.Cancel(); try { await pending; } catch (OperationCanceledException) { }
            await canceled.Task.WaitAsync(Deadline);
            check(!shared.Contains("cancel", 0, 128), "an abandoned background download is canceled and never installed as a complete block");
            var retry = await shared.GetAsync("cancel", 0, 128, _ => Data(128, 3), true, CancellationToken.None).WaitAsync(Deadline);
            check(retry[0] == 3, "a canceled in-flight block can be requested again without stale-job cleanup deleting its replacement");
        }
        MediaBlockCache.ClearStored(sharingRoot);

        string priorityRoot = Folder();
        await using (var cache = new MediaBlockCache(priorityRoot, CancellationToken.None))
        {
            int entered = 0; var bothStarted = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            using var cancelBackground = new CancellationTokenSource();
            async Task<byte[]> Hold(CancellationToken ct) { if (Interlocked.Increment(ref entered) == 2) bothStarted.SetResult(); await Task.Delay(Timeout.Infinite, ct); return new byte[64]; }
            var bg1 = cache.GetAsync("bg1", 0, 64, Hold, false, cancelBackground.Token);
            var bg2 = cache.GetAsync("bg2", 0, 64, Hold, false, cancelBackground.Token);
            await bothStarted.Task.WaitAsync(Deadline);
            int promotedCalls = 0; Task<byte[]> Promote(CancellationToken _) { Interlocked.Increment(ref promotedCalls); return Data(64, 6); }
            var queued = cache.GetAsync("priority", 0, 64, Promote, false, CancellationToken.None);
            var demand = cache.GetAsync("priority", 0, 64, Promote, true, CancellationToken.None);
            var demanded = await demand.WaitAsync(Deadline); await queued;
            check(demanded[0] == 6 && promotedCalls == 1, "a foreground seek promotes a queued preload and uses a reserved worker while both background workers are busy");
            cancelBackground.Cancel(); try { await Task.WhenAll(bg1, bg2); } catch (OperationCanceledException) { }
        }
        MediaBlockCache.ClearStored(priorityRoot);

        string aheadRoot = Folder();
        await using (var cache = new MediaBlockCache(aheadRoot, CancellationToken.None))
        {
            var blocks = new ConcurrentDictionary<long, byte>();
            int firstDemandBytes = 0;
            Task<byte[]> Download(long offset, int count, CancellationToken ct)
            { ct.ThrowIfCancellationRequested(); Interlocked.CompareExchange(ref firstDemandBytes, count, 0); blocks[offset / MediaBlockCache.BlockSize] = 1; return Data(count, (byte)(offset / MediaBlockCache.BlockSize)); }
            using (var reader = new CachedMediaReader(cache, "ahead", 50L * MediaBlockCache.BlockSize, _ => Task.CompletedTask, Download, CancellationToken.None))
            {
                var first = reader.Read(0, 4096);
                check(firstDemandBytes == CachedMediaReader.ProbeWindowBytes && cache.UsedBytes == 0 && cache.PendingCount == 0,
                    "a short first video read stays in a 64 KiB RAM probe without caching or preloading");
                reader.Read(4096, CachedMediaReader.ActivationBytes);
                await Until(() => blocks.Count == CachedMediaReader.ReadAheadBlocks + 1 && cache.PendingCount == 0);
                check(first[0] == 0 && blocks.Keys.Max() == CachedMediaReader.ReadAheadBlocks,
                    "video playback starts from the current block and preloads at most 256 MiB ahead without downloading the whole file");
                int before = blocks.Count; var next = reader.Read(MediaBlockCache.BlockSize, 4096);
                check(next[0] == 1 && cache.UsedBytes <= MediaBlockCache.DefaultCapacity, "playback consumes exact preloaded bytes while the shared disk cache remains bounded");
                var cross = reader.Read(MediaBlockCache.BlockSize * 2L - 50, 100);
                check(cross.Take(50).All(b => b == 1) && cross.Skip(50).All(b => b == 2), "cached playback reads crossing chunk boundaries return exact bytes");
            }
        }
        MediaBlockCache.ClearStored(aheadRoot);

        string seekRoot = Folder();
        await using (var cache = new MediaBlockCache(seekRoot, CancellationToken.None))
        {
            var started = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            var release = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            var canceled = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously); int held = 0;
            async Task<byte[]> Download(long offset, int count, CancellationToken ct)
            {
                long block = offset / MediaBlockCache.BlockSize;
                if (block is 1 or 2)
                {
                    using var notice = ct.Register(() => canceled.TrySetResult());
                    if (Interlocked.Increment(ref held) == 2) started.TrySetResult();
                    await release.Task; // Deliberately ignores cancellation to test the reserved foreground lane.
                }
                return await Data(count, (byte)block);
            }
            using var reader = new CachedMediaReader(cache, "seek", 40L * MediaBlockCache.BlockSize, _ => Task.CompletedTask, Download, CancellationToken.None);
            reader.Read(0, 32); reader.Read(32, CachedMediaReader.ActivationBytes); await started.Task.WaitAsync(Deadline);
            try
            {
                var sought = await Task.Run(() => reader.Read(10L * MediaBlockCache.BlockSize, 32)).WaitAsync(Deadline);
                await canceled.Task.WaitAsync(Deadline);
                check(sought[0] == 10, "seeking cancels the old preloading region and prioritizes the new position even with slow old downloads");
            }
            finally { reader.Dispose(); release.TrySetResult(); }
        }
        MediaBlockCache.ClearStored(seekRoot);
        await IntegrationAsync(check, settings, token, Folder());
    }
    private static async Task IntegrationAsync(Action<bool, string> check, Settings settings, string token, string rootFolder)
    {
        await using (var cache = new MediaBlockCache(rootFolder, CancellationToken.None))
        using (var remote = new MediaHandler())
        using (var api = new GoogleDriveApi(settings, remote, token))
        {
            var root = new DriveFile("root", "My Drive", "application/vnd.google-apps.folder", 0, DateTimeOffset.UtcNow, "1", "", Array.Empty<string>(), "", true);
            var tree = new GoogleTree(api, root, 15000000000, 10000000000, CancellationToken.None, streamingCache: cache, cacheAccount: "account-A");
            var image = tree.Resolve("\\photo.jpg");
            using (var mimeReader = tree.OpenRead(image with { Name = "no-extension" })!)
                check(mimeReader is CachedMediaReader, "Google image/video MIME types enable caching even without a recognized filename extension");
            using (var reader = tree.OpenRead(image)!) { var data = reader.Read(0, 1024); reader.Read(1024, CachedMediaReader.ActivationBytes); check(data.All(b => b == 17), "the Google-backed media reader verifies image data and starts caching after sustained reads"); }
            int downloaded = remote.MediaCalls;
            using (var reader = tree.OpenRead(image)!) reader.Read(0, 1024);
            check(remote.MediaCalls == downloaded && remote.MetadataCalls > 0, "reopening an image validates Google access and reuses its cached bytes without another media download");
            remote.Allowed = false; bool blocked = false;
            using (var reader = tree.OpenRead(image)!) { try { reader.Read(0, 16); } catch (UnauthorizedAccessException) { blocked = true; } }
            check(blocked, "fresh Google download restrictions prevent reopening cached media");
            remote.Allowed = true;
            var other = new GoogleTree(api, root, 1, 1, CancellationToken.None, streamingCache: cache, cacheAccount: "account-B");
            using (var reader = other.OpenRead(image)!) reader.Read(0, 1024);
            check(remote.MediaCalls == downloaded + 1, "cached content is isolated by Google account identity");
            remote.Version = "2"; bool changed = false;
            using (var reader = tree.OpenRead(image)!) { try { reader.Read(0, 10); } catch (IOException) { changed = true; } }
            check(changed, "a cloud file changed since opening cannot be served from an old cache key");
            remote.Version = "1";
            long cachedBeforeFailure = cache.UsedBytes; remote.ChangeDuringMedia = true;
            var changing = new GoogleTree(api, root, 1, 1, CancellationToken.None, streamingCache: cache, cacheAccount: "account-changing");
            bool rejected = false;
            using (var reader = changing.OpenRead(image)!) { try { reader.Read(0, 1024); } catch (IOException) { rejected = true; } }
            check(rejected && cache.UsedBytes == cachedBeforeFailure, "a file changed during download is rejected before its content can enter the disk cache");
            remote.ChangeDuringMedia = false; tree.Refresh();
            var newerImage = tree.Resolve("\\photo.jpg"); int mediaBeforeVersion = remote.MediaCalls;
            using (var reader = tree.OpenRead(newerImage)!) { reader.Read(0, 32); reader.Read(32, CachedMediaReader.ActivationBytes); }
            check(remote.MediaCalls == mediaBeforeVersion + 2, "a freshly resolved newer cloud version probes then caches current content under a new key");
            var store = new CloudFileStore(tree);
            using var reservation = new TcpListener(LocalSmbEndpoint.Address, 0); reservation.Start(); int port = ((IPEndPoint)reservation.LocalEndpoint).Port; reservation.Stop();
            var shares = new SMBShareCollection(); shares.Add(new FileSystemShare("Cloudlane", store, CachingPolicy.NoCaching));
            var server = new TestServer(shares, new GSSProvider(new CloudlaneAuthentication("cached-smb-password"))); server.Listen(port);
            var client = new TestSmbClient();
            try
            {
                check(client.Link(port) && client.Login("", "Cloudlane", "cached-smb-password") == NTStatus.STATUS_SUCCESS, "signed SMB authenticates for cached media playback");
                var share = client.TreeConnect("Cloudlane", out _);
                share.CreateFile(out var handle, out _, "photo.jpg", AccessMask.GENERIC_READ, 0, ShareAccess.Read, CreateDisposition.FILE_OPEN, 0, null!);
                int before = remote.MediaCalls;
                check(share.ReadFile(out var bytes, handle, 100, 4096) == NTStatus.STATUS_SUCCESS && bytes.All(b => b == 17) && remote.MediaCalls == before,
                    "actual signed SMB reads reuse verified cached media without refetching its content");
                share.CloseFile(handle); share.Disconnect(); client.Logoff();
            }
            finally { client.Disconnect(); server.Stop(); }
        }
        MediaBlockCache.ClearStored(rootFolder);
        check(MediaBlockCache.Inspect(rootFolder) == 0, "disconnect releases cache ownership so Clear cache can remove local media parts");
    }
    private sealed class MediaHandler : HttpMessageHandler
    {
        public int MediaCalls, MetadataCalls; public string Version = "1"; public bool ChangeDuringMedia, Allowed = true;
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
        {
            const int length = 2 * 1024 * 1024;
            if (request.Headers.Range != null)
            {
                Interlocked.Increment(ref MediaCalls); var r = request.Headers.Range.Ranges.Single(); int count = (int)(r.To!.Value - r.From!.Value + 1);
                var bytes = new byte[count]; Array.Fill(bytes, (byte)17);
                var response = new HttpResponseMessage(HttpStatusCode.PartialContent) { Content = new ByteArrayContent(bytes) };
                response.Content.Headers.ContentRange = new ContentRangeHeaderValue(r.From.Value, r.To.Value, length);
                if (ChangeDuringMedia) Version = "2";
                return Task.FromResult(response);
            }
            Interlocked.Increment(ref MetadataCalls);
            object Meta() => new { id = "photo", name = "photo.jpg", mimeType = "image/jpeg", size = length.ToString(), version = Version, modifiedTime = "2026-10-16T00:00:00Z", capabilities = new { canEdit = true, canDownload = Allowed } };
            object body = request.RequestUri!.AbsolutePath.EndsWith("/files") ? new { files = new[] { Meta() } } : Meta();
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json") });
        }
    }
}
