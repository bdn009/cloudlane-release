using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Security.Principal;
using System.Text.Json;
using Cloudlane;
internal static class MapperScriptChecks
{
    // Run the actual production script under Windows PowerShell 5.1, replacing
    // only the OS mapping/configuration cmdlets. This never creates a mapping.
    public static async Task<(bool Ok, string Error, int Reads, string[] Diagnostics)> RunAsync(bool fail)
    {
        using var listener = new TcpListener(LocalSmbEndpoint.Address, 0); listener.Start();
        int port = ((IPEndPoint)listener.LocalEndpoint).Port;
        string mocks = """
            $script:reads=0
            function ConvertTo-SecureString {
              [CmdletBinding()] param($String,[switch]$AsPlainText,[switch]$Force)
              $value=New-Object System.Security.SecureString
              foreach($character in $String.ToCharArray()){$value.AppendChar($character)}
              $value
            }
            function Get-SmbGlobalMapping {
              [CmdletBinding()] param($RemotePath)
              $script:reads++
              if($script:reads -gt 1){[pscustomobject]@{Status='OK';RemotePath=$RemotePath}}
            }
            function New-SmbGlobalMapping {
              [CmdletBinding()] param($RemotePath,$TcpPort,$TransportType,$Credential,$Persistent,$RequireIntegrity,$UseWriteThrough,$FullAccess)
              if($TransportType -ne 'TCP' -or $TcpPort -lt 1024 -or -not $RequireIntegrity -or $Persistent){throw 'Invalid transport/security parameters'}
              if($script:fail){Write-Error 'Simulated native mapper failure' -ErrorId 'Native64'}
            }
            function Get-SmbClientConfiguration {
              [CmdletBinding()] param()
              [pscustomobject]@{RequireSecuritySignature=$true;RequireEncryption=$false;BlockNTLM=$false}
            }
            function Get-WinEvent { [CmdletBinding()] param($FilterHashtable,$MaxEvents) }
            """;
        var start = new ProcessStartInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), @"System32\WindowsPowerShell\v1.0\powershell.exe"))
        { UseShellExecute = false, CreateNoWindow = true, RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true };
        string command = mocks + "\n$script:fail=$" + (fail ? "true" : "false") + "\n" + WindowsMapping.MapScript + "\nWrite-Output ('READS='+$script:reads)";
        foreach (var argument in new[] { "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", command }) start.ArgumentList.Add(argument);
        using var process = Process.Start(start)!;
        var request = new MountRequest("G:", port, "Cloudlane_" + new string('A', 16), "Cloudlane", new string('B', 64), WindowsIdentity.GetCurrent().User!.Value);
        await process.StandardInput.WriteAsync(JsonSerializer.Serialize(request)); process.StandardInput.Close();
        var outputTask = process.StandardOutput.ReadToEndAsync(); var errorTask = process.StandardError.ReadToEndAsync();
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(20));
        try { await process.WaitForExitAsync(timeout.Token); }
        catch { process.Kill(true); throw; }
        string output = await outputTask, error = await errorTask;
        if (process.ExitCode != 0 || error.Length > 0) throw new Exception("Mapper script check: " + error);
        var lines = output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
        using var result = JsonDocument.Parse(lines[0]); var value = result.RootElement;
        return (value.GetProperty("Ok").GetBoolean(), value.TryGetProperty("Error", out var message) ? message.GetString()! : "",
            int.Parse(lines[1][6..]), value.GetProperty("Diagnostics").EnumerateArray().Select(x => x.GetString()!).ToArray());
    }
}
