using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
namespace Cloudlane;
public static class Paths
{
    public static string UnderRoot(string root, string relative)
    {
        string basis = Path.GetFullPath(root).TrimEnd('\\') + "\\", result = Path.GetFullPath(Path.Combine(basis, relative));
        if (Path.IsPathRooted(relative) || relative.Split('\\', '/').Any(p => p == "..") || !result.StartsWith(basis, StringComparison.OrdinalIgnoreCase)) throw new IOException("A file path escaped the Google Drive folder.");
        return result;
    }
    public static string ShortId(string id) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(id)))[..10].ToLowerInvariant();
    public static string SafeName(string name)
    {
        var value = new StringBuilder();
        for (int i = 0; i < name.Length; i++)
        { char c = name[i]; bool bad = c < 32 || "<>:\"/\\|?*~".Contains(c) || (i == name.Length - 1 && (c == '.' || c == ' ')); value.Append(bad ? "~" + ((int)c).ToString("x4") : c); }
        string result = value.Length == 0 ? "~empty" : value.ToString();
        string stem = result.Split('.')[0];
        if (new[] { "CON", "PRN", "AUX", "NUL", "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9", "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9", ".", ".." }.Contains(stem, StringComparer.OrdinalIgnoreCase)) result = "~005f" + result;
        if (result.Length > 220) result = result[..190] + "~" + ShortId(name) + Path.GetExtension(result)[..Math.Min(12, Path.GetExtension(result).Length)];
        return result;
    }
    public static string CollisionName(string name, string id)
    { string extension = Path.GetExtension(name); return Path.GetFileNameWithoutExtension(name) + "~" + ShortId(id) + extension; }
    public static bool IsCloudDocument(string mime) => mime.StartsWith("application/vnd.google-apps.", StringComparison.Ordinal) && mime != "application/vnd.google-apps.folder";
}
