using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
namespace Cloudlane;
public static class UploadCoordinator
{
    public static async Task RunAsync(UploadQueue queue, GoogleDriveApi drive, Action persistMetadata, IProgress<UploadProgress>? progress, CancellationToken ct)
    {
        foreach (var job in queue.Jobs.Where(j => !j.Complete).ToList())
        {
            ct.ThrowIfCancellationRequested();
            string parentId = job.ParentRemoteId;
            if (job.ParentJobKey.Length > 0)
            {
                var parent = queue.Jobs.FirstOrDefault(p => p.Key == job.ParentJobKey);
                if (parent?.Complete != true) { job.State = "Waiting for folder"; continue; }
                parentId = parent.RemoteId;
            }
            try
            {
                job.Error = ""; job.State = "Uploading"; persistMetadata();
                DriveFile uploaded;
                if (job.IsFolder)
                {
                    if (!Directory.Exists(job.Source)) throw new DirectoryNotFoundException("The original folder is unavailable: " + job.Source);
                    if (job.RemoteId.Length == 0) { job.RemoteId = await drive.GenerateIdAsync(ct); persistMetadata(); }
                    uploaded = await drive.FolderAsync(job.RemoteId, job.Name, parentId, ct);
                }
                else uploaded = await drive.UploadOriginalAsync(job, parentId, persistMetadata, progress, ct);
                job.RemoteId = uploaded.Id; job.Complete = true; job.State = "Complete"; job.Session = "";
                if (!job.IsFolder) { job.ConfirmedBytes = uploaded.Size; progress?.Report(new(job.Name, uploaded.Size, uploaded.Size, "Upload complete")); }
                persistMetadata();
            }
            catch (OperationCanceledException) { job.State = "Paused"; persistMetadata(); throw; }
            catch (Exception ex) { job.State = "Needs attention"; job.Error = ex.Message; persistMetadata(); }
        }
    }
}
