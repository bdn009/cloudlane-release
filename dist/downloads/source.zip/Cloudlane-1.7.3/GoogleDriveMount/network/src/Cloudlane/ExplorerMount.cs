using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Cloudlane.Mount;
using SMBLibrary;
using SMBLibrary.Server;
using SMBLibrary.Authentication.GSSAPI;
using SMBLibrary.Authentication.NTLM;
namespace Cloudlane;
public sealed class ExplorerMount
{
    private ExplorerServerPool.Lease? server;
    private GoogleDriveApi? drive;
    private GoogleTree? tree;
    private CloudFileStore? fileStore;
    private CancellationTokenSource? lifetime;
    private NamedPipeServerStream? pipe;
    private StreamReader? reader;
    private StreamWriter? writer;
    private Process? helper;
    private ExplorerNetworkDrive? alias;
    private ExplorerAppearance? appearance;
    private Task? quotaRefresh;
    private DriveOverview? overview;
    private MediaBlockCache? mediaCache;
    private StreamingCachePool.Lease? cacheLease;
    private string appearanceJournal = AppearanceJournal;
    public long CachedBytes => mediaCache?.UsedBytes ?? 0;
    public int CacheDownloads => mediaCache?.PendingCount ?? 0;
    public string CacheWarning { get; private set; } = "";
    public string CacheProblem => mediaCache?.LastError.Length > 0 ? mediaCache.LastError : CacheWarning;
    public DriveOverview? Overview => Volatile.Read(ref overview);
    public string DisplayLabel => tree?.VolumeLabel ?? "Google Drive";
    public string AppearanceWarning { get; private set; } = "";
    public static string AppearanceJournal => Path.Combine(Settings.DataDir, "explorer-appearance.json");
    private readonly MountTrace trace = new();
    public string Diagnostics
    {
        get
        {
            if (IsMounted)
            {
                trace.Add("Drive state: letter=" + Letter + "; network-provider registration=" + (alias?.Registered == true) + "; DOS target present=" + (ExplorerDriveAlias.Target(Letter) != null) + "; helper running=" + (helper?.HasExited == false));
                if (tree != null) trace.Add(tree.ReadDiagnostics);
                if (fileStore != null) trace.Add(fileStore.ReadDiagnostics);
                if (mediaCache != null) trace.Add(mediaCache.Diagnostics);
                trace.Save();
            }
            return trace.Text;
        }
    }
    public string Letter { get; private set; } = "";
    public bool IsMounted => Letter.Length > 0;
    public string LastError { get; private set; } = "";
    public static bool LetterInUse(string letter) => ExplorerDriveAlias.Target(letter) != null || DriveInfo.GetDrives().Any(d => d.Name.StartsWith(letter, StringComparison.OrdinalIgnoreCase));
    public async Task MountAsync(Settings settings, string letter, CancellationToken ct)
    {
        if (!WindowsMapping.Supported) throw new IOException("The driver-free Explorer mount requires Windows 11 24H2 or newer (build 26100+).");
        if (server != null) throw new IOException("A drive connection is already running.");
        trace.Clear(); trace.Add("Starting local Explorer connection.");
        if (letter.Length != 2 || letter[0] < 'D' || letter[0] > 'Z' || letter[1] != ':' || LetterInUse(letter)) throw new IOException("Choose an unused drive letter from D: to Z:.");
        lifetime = new(); settings = settings.Snapshot();
        try
        {
            drive = new GoogleDriveApi(settings);
            Directory.CreateDirectory(settings.AccountDir);
            appearanceJournal = Path.Combine(settings.AccountDir, "explorer-appearance.json");
            trace.OutputPath = Path.Combine(settings.AccountDir, "mount-diagnostics.txt");
            var root = await drive.GetAsync("root", ct); overview = await drive.OverviewAsync(ct);
            AppearanceWarning = "";
            CacheWarning = "";
            if (settings.StreamingCacheEnabled)
            {
                try
                {
                    if (settings.StreamingCacheDirectory.StartsWith(letter, StringComparison.OrdinalIgnoreCase)) throw new IOException("The cache folder cannot be on Cloudlane's own drive. Choose another local disk folder.");
                    cacheLease = await StreamingCachePool.AcquireAsync(settings.StreamingCacheDirectory, ct, Settings.ProtectDirectory);
                    mediaCache = cacheLease.Cache;
                }
                catch (Exception ex) { CacheWarning = "Streaming cache unavailable; using RAM streaming. " + ex.Message; trace.Add(CacheWarning); }
            }
            string label = settings.DriveLabel(overview);
            tree = new GoogleTree(drive, root, overview.Capacity.TotalBytes, overview.Capacity.FreeBytes, lifetime.Token, label, mediaCache, settings.AccountId);
            await Task.Run(() => tree.Children(tree.Resolve("\\")), ct);
            fileStore = new CloudFileStore(tree) { Error = text => LastError = text };
            server = ExplorerServerPool.Acquire(fileStore, trace.AddProtocol);
            int port = server.Port; string password = server.Password, shareName = server.ShareName;
            trace.Add($"Local SMB listening on {LocalSmbEndpoint.Host}:{port}; starting signed protocol preflight.");
            await LocalSmbEndpoint.CheckAsync(port, shareName, password, ct);
            trace.Add("Signed local SMB authentication and root open passed. Starting Windows mapper.");
            string pipeName = "Cloudlane.Map." + Guid.NewGuid().ToString("N");
            pipe = new NamedPipeServerStream(pipeName, PipeDirection.InOut, 1, PipeTransmissionMode.Byte, PipeOptions.Asynchronous | PipeOptions.CurrentUserOnly);
            var start = new ProcessStartInfo(Environment.ProcessPath!) { UseShellExecute = true, Verb = "runas", WindowStyle = ProcessWindowStyle.Hidden };
            start.ArgumentList.Add("--map-helper"); start.ArgumentList.Add(pipeName);
            try { helper = Process.Start(start) ?? throw new IOException("Could not start the local drive helper."); }
            catch (Win32Exception ex) when (ex.NativeErrorCode == 1223) { throw new MappingApprovalCancelledException(); }
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct); timeout.CancelAfter(TimeSpan.FromMinutes(2));
            await pipe.WaitForConnectionAsync(timeout.Token);
            reader = new StreamReader(pipe, Encoding.UTF8, false, 1024, true);
            writer = new StreamWriter(pipe, new UTF8Encoding(false), 1024, true) { AutoFlush = true };
            var request = new MountRequest(letter, port, shareName, "Cloudlane", password, WindowsIdentity.GetCurrent().User!.Value);
            WindowsMapping.Validate(request); await writer.WriteLineAsync(JsonSerializer.Serialize(request));
            await ReadResultAsync(timeout.Token);
            trace.Add("Authenticated SMB connection created; checking access from the desktop user.");
            await ProbeDirectoryAsync(LocalSmbEndpoint.Remote(shareName) + "\\", "local SMB share", timeout.Token);
            alias = await Task.Run(() => new ExplorerNetworkDrive(letter, shareName));
            trace.Add("Registered temporary network drive with Windows in the desktop user's session.");
            await ProbeDirectoryAsync(letter + "\\", "Explorer drive letter", timeout.Token);
            Letter = letter; LastError = "";
            try { appearance = new ExplorerAppearance(letter, shareName, label, Path.Combine(AppContext.BaseDirectory, "Assets", "GoogleDrive.ico"), appearanceJournal); }
            catch (Exception ex) { AppearanceWarning = "Explorer appearance could not be applied: " + ex.Message; trace.Add(AppearanceWarning); }
            await Task.Run(() => ProbeSpace(letter));
            ct.ThrowIfCancellationRequested();
            quotaRefresh = RefreshQuotaAsync(drive, tree, lifetime.Token);
            trace.Add("Drive root enumeration passed."); trace.Save();
        }
        catch (Exception ex)
        {
            trace.Add("Connect failed: " + ex.Message); LastError = ex.Message;
            await CleanupAsync(); trace.Save();
            if (ex is OperationCanceledException || ex is MappingApprovalCancelledException) throw;
            throw new IOException(ex.Message + " Use Copy diagnostics if this repeats.", ex);
        }
    }
    internal static async Task ProbeDirectoryAsync(string path, string stage, CancellationToken ct)
    {
        Exception? last = null;
        for (int attempt = 0; attempt < 8; attempt++)
        {
            ct.ThrowIfCancellationRequested();
            try
            {
                await Task.Run(() => { using var items = Directory.EnumerateFileSystemEntries(path).GetEnumerator(); items.MoveNext(); }, ct);
                return; // An empty directory is a valid, accessible mount.
            }
            catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
            { last = ex; if (attempt < 7) await Task.Delay(400, ct); }
        }
        int win32 = last!.HResult & 0xffff;
        throw new IOException($"Windows cannot open the {stage} (error {win32}: {new Win32Exception(win32).Message}).", last);
    }
    private async Task ReadResultAsync(CancellationToken ct)
    {
        string json = await reader!.ReadLineAsync(ct) ?? throw new IOException("The Windows drive helper disconnected.");
        using var response = JsonDocument.Parse(json);
        if (response.RootElement.TryGetProperty("Diagnostics", out var diagnostics) && diagnostics.ValueKind == JsonValueKind.Array)
            foreach (var item in diagnostics.EnumerateArray()) trace.Add("Windows: " + item.GetString());
        if (response.RootElement.TryGetProperty("Mapping", out var mapping)) trace.Add("Windows mapper: " + mapping.GetString());
        if (!response.RootElement.GetProperty("Ok").GetBoolean()) throw new IOException(response.RootElement.GetProperty("Error").GetString());
    }
    public void Refresh() => tree?.Refresh();
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool GetDiskFreeSpaceEx(string path, out ulong available, out ulong total, out ulong free);
    private void ProbeSpace(string letter)
    {
        if (GetDiskFreeSpaceEx(letter + "\\", out var available, out var total, out _))
            trace.Add($"Windows disk-space query passed: total={total}; available={available} bytes.");
        else { int error = Marshal.GetLastPInvokeError(); trace.Add($"Windows disk-space query failed: error {error}. Google quota remains visible in Cloudlane."); }
    }
    private async Task RefreshQuotaAsync(GoogleDriveApi api, GoogleTree mountedTree, CancellationToken ct)
    {
        using var timer = new PeriodicTimer(TimeSpan.FromSeconds(60));
        try
        {
            while (await timer.WaitForNextTickAsync(ct))
            {
                try
                {
                    using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct); timeout.CancelAfter(TimeSpan.FromSeconds(20));
                    var quota = await api.StorageAsync(timeout.Token);
                    var space = new CloudCapacity(quota.Total, quota.Free); mountedTree.UpdateCapacity(space);
                    var current = Overview; if (current != null) Volatile.Write(ref overview, current with { Capacity = space });
                    if (Letter.Length > 0) ExplorerAppearance.NotifySpace(Letter);
                }
                catch (OperationCanceledException) when (ct.IsCancellationRequested) { break; }
                catch (Exception ex) { trace.Add("Quota refresh failed; retaining last confirmed values: " + ex.Message); }
            }
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested) { }
    }
    public async Task UnmountAsync()
    {
        lifetime?.Cancel(); fileStore?.AbortUploads();
        try { appearance?.Dispose(); appearance = null; } catch (Exception ex) { trace.Add("Explorer appearance cleanup: " + ex.Message); }
        alias?.Dispose(); alias = null;
        if (pipe?.IsConnected == true && writer != null)
        {
            await writer.WriteLineAsync("DISCONNECT");
            using var limit = new CancellationTokenSource(TimeSpan.FromSeconds(60)); await ReadResultAsync(limit.Token);
        }
        await CleanupAsync();
        trace.Add("Drive disconnected."); trace.Save();
    }
    private async Task CleanupAsync()
    {
        lifetime?.Cancel();
        if (quotaRefresh != null) { await quotaRefresh; quotaRefresh = null; }
        try { appearance?.Dispose(); appearance = null; } catch (Exception ex) { trace.Add("Explorer appearance cleanup: " + ex.Message); }
        try { alias?.Dispose(); } catch (Exception ex) { trace.Add("Letter cleanup: " + ex.Message); } alias = null;
        // Closing the owner pipe also causes the helper to remove only its exact mapping.
        writer?.Dispose(); reader?.Dispose(); pipe?.Dispose(); writer = null; reader = null; pipe = null;
        if (helper != null) { try { using var limit = new CancellationTokenSource(TimeSpan.FromSeconds(50)); await helper.WaitForExitAsync(limit.Token); } catch { } helper.Dispose(); helper = null; }
        lifetime?.Cancel(); fileStore?.AbortUploads(); server?.Dispose(); server = null; fileStore = null;
        if (cacheLease != null) { await cacheLease.DisposeAsync(); cacheLease = null; } mediaCache = null;
        drive?.Dispose(); drive = null; tree = null; lifetime?.Dispose(); lifetime = null; Letter = "";
    }
}
