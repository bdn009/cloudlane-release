using System;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using SMBLibrary;
using SMBLibrary.Client;
namespace Cloudlane;
internal static class LocalSmbEndpoint
{
    // Use the canonical IPv4 loopback endpoint consistently in the listener,
    // native Windows mapping, protocol preflight, and desktop drive alias.
    public const string Host = "127.0.0.1";
    public static IPAddress Address => IPAddress.Loopback;
    public static string Remote(string share) => @"\\" + Host + @"\" + share;
    public static Task CheckAsync(int port, string shareName, string password, CancellationToken ct) => Task.Run(() =>
    {
        ct.ThrowIfCancellationRequested();
        var client = new LocalClient();
        try
        {
            if (!client.Link(port)) throw new IOException("Cloudlane's local SMB listener did not answer its protocol check.");
            NTStatus status = client.Login("CLOUDLANE", "Cloudlane", password);
            if (status != NTStatus.STATUS_SUCCESS) throw new IOException("Local SMB authentication check failed: " + status);
            var share = client.TreeConnect(shareName, out status);
            if (status != NTStatus.STATUS_SUCCESS) throw new IOException("Local SMB share check failed: " + status);
            try
            {
                status = share.CreateFile(out var root, out _, "", AccessMask.GENERIC_READ, 0, ShareAccess.Read,
                    CreateDisposition.FILE_OPEN, CreateOptions.FILE_DIRECTORY_FILE, null!);
                if (status != NTStatus.STATUS_SUCCESS) throw new IOException("Local SMB root check failed: " + status);
                share.CloseFile(root);
            }
            finally { share.Disconnect(); }
            client.Logoff();
            ct.ThrowIfCancellationRequested();
        }
        finally { client.Disconnect(); }
    }, ct);
    private sealed class LocalClient() : SMB2Client(3000)
    { public bool Link(int port) => Connect(Address, SMBTransportType.DirectTCPTransport, port); }
}
