using System;
using System.IO;
namespace Cloudlane;

internal static class BundledGoogleClient
{
    private const string Resource = "Cloudlane.GoogleClient.json";
    internal static bool IsAvailable => typeof(Settings).Assembly.GetManifestResourceInfo(Resource) != null;
    internal static void Apply(Settings settings) => Apply(settings, () => typeof(Settings).Assembly.GetManifestResourceStream(Resource));
    // A Desktop OAuth registration identifies this app. It is not a user's token or a confidential desktop secret.
    internal static void Apply(Settings settings, Func<Stream?> open)
    {
        if (settings.HasClient) return;
        using var stream = open();
        if (stream == null) return;
        using var reader = new StreamReader(stream);
        var client = Settings.ParseClient(reader.ReadToEnd());
        settings.ClientId = client.Id; settings.ClientSecret = client.Secret;
    }
}
