using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
namespace Cloudlane;

public sealed class AccountProfile
{
    public string Id { get; set; } = "";
    public string Email { get; set; } = "";
    public string Letter { get; set; } = "G:";
    public string DriveName { get; set; } = "";
    public bool AutoConnect { get; set; }
    public override string ToString() => Email.Length == 0 ? "Google account" : Email;
}

public sealed partial class Settings
{
    public int AccountsVersion { get; set; }
    public List<AccountProfile> Accounts { get; set; } = new();
    internal static bool ValidAccountId(string? id) => id?.Length == 64 && id.All(Uri.IsHexDigit);
    internal static bool ValidLetter(string? letter) => letter?.Length == 2 && letter[0] >= 'D' && letter[0] <= 'Z' && letter[1] == ':';
    internal void InitializeAccounts()
    {
        Accounts = (Accounts ?? new()).Where(a => a != null && ValidAccountId(a.Id)).GroupBy(a => a.Id, StringComparer.OrdinalIgnoreCase).Select(g => g.First()).ToList();
        foreach (var a in Accounts)
        {
            a.Id = a.Id.ToUpperInvariant(); a.Email ??= "";
            a.DriveName = ExplorerAppearance.NormalizeCustomLabel(a.DriveName);
            if (!ValidLetter(a.Letter)) a.Letter = "G:";
        }
        if (ValidAccountId(AccountId)) { AccountId = AccountId.ToUpperInvariant(); RememberSelected(); }
        else if (Accounts.Count > 0) ApplyAccount(Accounts[0]);
    }
    internal void RememberSelected()
    {
        if (!ValidAccountId(AccountId)) return;
        var profile = Accounts.FirstOrDefault(a => a.Id.Equals(AccountId, StringComparison.OrdinalIgnoreCase));
        if (profile == null) { profile = new AccountProfile { Id = AccountId.ToUpperInvariant() }; Accounts.Add(profile); }
        profile.Email = AccountEmail; profile.Letter = ValidLetter(Letter) ? Letter : "G:";
        profile.DriveName = ExplorerAppearance.NormalizeCustomLabel(DriveName);
    }
    private void ApplyAccount(AccountProfile a)
    { AccountId = a.Id; AccountEmail = a.Email; Letter = a.Letter; DriveName = a.DriveName; }
    internal void SelectAccount(string id)
    {
        var profile = Accounts.FirstOrDefault(a => a.Id.Equals(id, StringComparison.OrdinalIgnoreCase)) ?? throw new IOException("That Google account is not saved.");
        RememberSelected(); ApplyAccount(profile);
    }
    internal static string NextLetter(IEnumerable<string> assigned, Func<string, bool> occupied)
    {
        var used = new HashSet<string>(assigned, StringComparer.OrdinalIgnoreCase);
        return Enumerable.Range('G', 20).Concat(Enumerable.Range('D', 3)).Select(c => ((char)c) + ":")
            .FirstOrDefault(l => !used.Contains(l) && !occupied(l)) ?? throw new IOException("No unused drive letter is available from D: to Z:.");
    }
    internal void AddAccount(string id, string email, Func<string, bool> occupied)
    {
        if (!ValidAccountId(id)) throw new IOException("Google returned an invalid account identity.");
        RememberSelected();
        var profile = Accounts.FirstOrDefault(a => a.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
        if (profile == null)
        {
            profile = new AccountProfile { Id = id.ToUpperInvariant(), Email = email, Letter = NextLetter(Accounts.Select(a => a.Letter), occupied) };
            Accounts.Add(profile);
        }
        else profile.Email = email;
        ApplyAccount(profile);
    }
    internal void RemoveSelected()
    {
        Accounts.RemoveAll(a => a.Id.Equals(AccountId, StringComparison.OrdinalIgnoreCase));
        AccountId = AccountEmail = DriveName = ""; Letter = "G:";
        if (Accounts.Count > 0) ApplyAccount(Accounts[0]);
    }
    internal void SaveAccountChange(Action<Settings> edit)
    {
        string id = AccountId, email = AccountEmail, letter = Letter, name = DriveName;
        var previous = Accounts.Select(a => new AccountProfile { Id = a.Id, Email = a.Email, Letter = a.Letter, DriveName = a.DriveName, AutoConnect = a.AutoConnect }).ToList();
        try { edit(this); Save(); }
        catch { Accounts = previous; AccountId = id; AccountEmail = email; Letter = letter; DriveName = name; throw; }
    }
    internal Settings Snapshot() => new()
    {
        AccountId = AccountId, AccountEmail = AccountEmail, Letter = Letter, DriveName = DriveName,
        ClientId = ClientId, ClientSecret = ClientSecret, CloseToTray = CloseToTray,
        StreamingCacheEnabled = StreamingCacheEnabled, StreamingCacheBaseDirectory = StreamingCacheBaseDirectory,
        AccountsVersion = 1
    };
    internal Settings ForAccount(AccountProfile profile)
    {
        var copy = Snapshot(); copy.AccountId = profile.Id; copy.AccountEmail = profile.Email;
        copy.Letter = profile.Letter; copy.DriveName = profile.DriveName; return copy;
    }
    // Copy the already encrypted legacy token; no plaintext or DPAPI conversion is needed.
    internal void MigrateLegacyToken()
    {
        if (AccountsVersion >= 1) return;
        if (ValidAccountId(AccountId) && File.Exists(ConfigPath))
        {
            Directory.CreateDirectory(AccountDir);
            if (!File.Exists(TokenPath)) File.Copy(ConfigPath, TokenPath);
            AccountsVersion = 1; Save();
            File.Delete(ConfigPath);
        }
        else AccountsVersion = 1;
    }
}
