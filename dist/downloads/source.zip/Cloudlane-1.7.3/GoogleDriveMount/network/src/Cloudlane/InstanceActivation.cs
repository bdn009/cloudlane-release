using System;
using System.IO;
using System.IO.Pipes;
using System.Security.Principal;
using System.Threading;
using System.Threading.Tasks;
namespace Cloudlane;

// A second ordinary launch restores the existing window, including when it is in the tray.
public sealed class InstanceActivation : IDisposable
{
    public static string UserPipeName => "Cloudlane.Production.Show." + WindowsIdentity.GetCurrent().User!.Value;
    private readonly CancellationTokenSource stop = new();
    private readonly NamedPipeServerStream pipe;
    public Task Completion { get; }
    public InstanceActivation(string name, Action show)
    {
        pipe = new NamedPipeServerStream(name, PipeDirection.InOut, 1, PipeTransmissionMode.Byte,
            PipeOptions.Asynchronous | PipeOptions.CurrentUserOnly);
        Completion = ListenAsync(show);
    }
    private async Task ListenAsync(Action show)
    {
        while (!stop.IsCancellationRequested)
        {
            try
            {
                await pipe.WaitForConnectionAsync(stop.Token).ConfigureAwait(false);
                using var timeout = CancellationTokenSource.CreateLinkedTokenSource(stop.Token);
                timeout.CancelAfter(TimeSpan.FromSeconds(2));
                byte[] request = new byte[1];
                if (await pipe.ReadAsync(request, timeout.Token).ConfigureAwait(false) == 1 && request[0] == 1)
                {
                    show();
                    await pipe.WriteAsync(new byte[] { 1 }, timeout.Token).ConfigureAwait(false);
                }
            }
            catch (Exception ex) when (ex is IOException || ex is OperationCanceledException || ex is ObjectDisposedException) { }
            finally
            {
                try { if (!stop.IsCancellationRequested && pipe.IsConnected) pipe.Disconnect(); }
                catch (Exception ex) when (ex is IOException || ex is ObjectDisposedException) { }
            }
        }
    }
    public static async Task<bool> ShowExistingAsync(string name)
    {
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(2));
        try
        {
            using var client = new NamedPipeClientStream(".", name, PipeDirection.InOut, PipeOptions.Asynchronous | PipeOptions.CurrentUserOnly);
            await client.ConnectAsync(timeout.Token).ConfigureAwait(false);
            await client.WriteAsync(new byte[] { 1 }, timeout.Token).ConfigureAwait(false);
            byte[] reply = new byte[1];
            return await client.ReadAsync(reply, timeout.Token).ConfigureAwait(false) == 1 && reply[0] == 1;
        }
        catch (Exception ex) when (ex is IOException || ex is OperationCanceledException || ex is UnauthorizedAccessException) { return false; }
    }
    public void Dispose() { stop.Cancel(); pipe.Dispose(); }
}
