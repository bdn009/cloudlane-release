using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Cloudlane;
public static class GoogleAuth
{
    public sealed record Result(string Token, string AccountId, string Email);
    private static string Random() => Convert.ToBase64String(RandomNumberGenerator.GetBytes(32)).TrimEnd('=').Replace('+', '-').Replace('/', '_');
    public static async Task<Result> SignInAsync(Settings settings, CancellationToken cancellation)
    {
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellation);
        timeout.CancelAfter(TimeSpan.FromMinutes(5));
        var ct = timeout.Token;
        using var socket = new TcpListener(IPAddress.Loopback, 0);
        socket.Start();
        int port = ((IPEndPoint)socket.LocalEndpoint).Port;
        string redirect = $"http://127.0.0.1:{port}/", state = Random(), verifier = Random();
        string challenge = Convert.ToBase64String(SHA256.HashData(Encoding.ASCII.GetBytes(verifier))).TrimEnd('=').Replace('+', '-').Replace('/', '_');
        string url = "https://accounts.google.com/o/oauth2/v2/auth?client_id=" + Uri.EscapeDataString(settings.ClientId)
            + "&redirect_uri=" + Uri.EscapeDataString(redirect) + "&response_type=code&scope="
            + Uri.EscapeDataString("https://www.googleapis.com/auth/drive")
            + "&access_type=offline&prompt=consent%20select_account&state=" + state + "&code_challenge_method=S256&code_challenge=" + challenge;
        Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
        string? code = null;
        while (code == null)
        {
            using var client = await socket.AcceptTcpClientAsync(ct);
            using var stream = client.GetStream();
            using var reader = new System.IO.StreamReader(stream, Encoding.UTF8, false, 1024, true);
            // A short per-request timeout prevents unrelated loopback requests blocking login.
            using var requestTimeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
            requestTimeout.CancelAfter(TimeSpan.FromSeconds(10));
            string? line;
            try { line = await reader.ReadLineAsync(requestTimeout.Token); } catch (OperationCanceledException) when (!ct.IsCancellationRequested) { continue; }
            var parts = line?.Split(' ');
            var args = new Dictionary<string, string>();
            if (parts?.Length >= 2 && parts[0] == "GET" && Uri.TryCreate(redirect.TrimEnd('/') + parts[1], UriKind.Absolute, out var callback))
                foreach (var pair in callback.Query.TrimStart('?').Split('&', StringSplitOptions.RemoveEmptyEntries))
                { var kv = pair.Split('=', 2); args[Uri.UnescapeDataString(kv[0])] = kv.Length > 1 ? Uri.UnescapeDataString(kv[1].Replace('+', ' ')) : ""; }
            bool valid = args.TryGetValue("state", out var received) && received == state;
            bool ok = valid && args.TryGetValue("code", out code);
            string body = ok ? "Google authorization received. Return to Cloudlane to finish connecting." : "Authorization was not completed. Return to Cloudlane.";
            byte[] bytes = Encoding.UTF8.GetBytes(body);
            await stream.WriteAsync(Encoding.ASCII.GetBytes($"HTTP/1.1 {(valid ? "200 OK" : "400 Bad Request")}\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: {bytes.Length}\r\nConnection: close\r\n\r\n"), ct);
            await stream.WriteAsync(bytes, ct);
            if (valid && args.ContainsKey("error")) throw new InvalidOperationException("Google sign-in was declined. You can try again.");
            if (!ok) code = null;
        }
        using var http = new HttpClient();
        using var response = await http.PostAsync("https://oauth2.googleapis.com/token", new FormUrlEncodedContent(new Dictionary<string, string>
        { ["client_id"] = settings.ClientId, ["client_secret"] = settings.ClientSecret, ["code"] = code,
          ["code_verifier"] = verifier, ["redirect_uri"] = redirect, ["grant_type"] = "authorization_code" }), ct);
        if (!response.IsSuccessStatusCode) throw new InvalidOperationException("Google could not complete sign-in. Check the Desktop OAuth client and try again.");
        using var token = JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct));
        var t = token.RootElement;
        if (!t.TryGetProperty("refresh_token", out var refresh)) throw new InvalidOperationException("Google did not grant offline access. Revoke Cloudlane's access in Google Account settings, then sign in again.");
        string access = t.GetProperty("access_token").GetString()!;
        http.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", access);
        using var about = await http.GetAsync("https://www.googleapis.com/drive/v3/about?fields=user(permissionId,emailAddress)", ct);
        if (!about.IsSuccessStatusCode) throw new InvalidOperationException("Google Drive API access failed. Enable Google Drive API in your Google Cloud project and sign in again.");
        using var account = JsonDocument.Parse(await about.Content.ReadAsStringAsync(ct));
        var user = account.RootElement.GetProperty("user");
        string accountId = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(user.GetProperty("permissionId").GetString()!)));
        string tokenJson = JsonSerializer.Serialize(new { access_token = access, token_type = "Bearer",
            refresh_token = refresh.GetString(), expiry = DateTimeOffset.UtcNow.AddSeconds(t.GetProperty("expires_in").GetInt32()).ToString("O") });
        return new Result(tokenJson, accountId, user.GetProperty("emailAddress").GetString() ?? "Google account");
    }
}
