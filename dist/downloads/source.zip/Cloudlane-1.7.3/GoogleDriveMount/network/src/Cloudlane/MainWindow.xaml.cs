using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Cloudlane.Mount;
using Forms = System.Windows.Forms;
namespace Cloudlane;
public partial class MainWindow : Window
{
    private Settings settings = new();
    private ExplorerMount explorer = new();
    private readonly Dictionary<string, ExplorerMount> mounts = new(StringComparer.OrdinalIgnoreCase);
    private bool updatingAccounts;
    private bool AnyMounted => mounts.Values.Any(m => m.IsMounted);
    private readonly DesktopLifetime lifetime;
    private readonly StartupRegistration startup = new(new UserStartupStore());
    private readonly StartupConnections startupConnections = new();
    private bool connectingAtStartup;
    private readonly bool startInTray;
    private bool previewMode;
    private bool initialized;
    private bool sessionEnding;
    private bool hiddenNoticeShown;
    private bool startupAvailable;
    private TrayIcon? tray;
    private Task activeOperation = Task.CompletedTask;
    public string DesktopWarning { get; set; } = "";
    private GoogleDriveApi? drive;
    private DriveOverview? accountOverview;
    private long offlineCachedBytes;
    private string cacheStatus = "";
    private UploadQueue queue = new();
    private readonly List<(string Id, string Name)> folders = new();
    private bool busy;
    private bool ready;
    private bool signingIn;
    private CancellationTokenSource? cancellation;
    private readonly DispatcherTimer timer = new() { Interval = TimeSpan.FromMilliseconds(400) };
    public MainWindow(bool startInTray = false)
    {
        this.startInTray = startInTray;
        lifetime = new DesktopLifetime(HideToTray, StopForExitAsync, FinishExit);
        InitializeComponent(); Loaded += LoadedAsync; Closing += OnClosing;
        if (startInTray) { ShowActivated = false; ShowInTaskbar = false; WindowState = WindowState.Minimized; }
        LetterPicker.ItemsSource = Enumerable.Range('D', 23).Select(c => ((char)c) + ":").ToList(); LetterPicker.SelectedItem = "G:";
        timer.Tick += (_, _) => { if (busy) RefreshQueue(); if (explorer.IsMounted && explorer.LastError.Length > 0) MountStatus.Text = explorer.LastError; UpdateDriveDisplay(); };
    }
    private async void LoadedAsync(object sender, RoutedEventArgs e)
    {
        if (initialized) return; initialized = true;
        var args = Environment.GetCommandLineArgs(); int render = Array.IndexOf(args, "--render-preview");
        previewMode = render >= 0;
        if (!previewMode)
        {
            try
            {
                tray = new TrayIcon(() => Dispatcher.BeginInvoke(ShowFromTray),
                    () => Dispatcher.BeginInvoke(() => OpenDrive_Click(this, new RoutedEventArgs())),
                    () => Dispatcher.BeginInvoke(() => { ShowFromTray(); if (MountButton.IsEnabled) Mount_Click(this, new RoutedEventArgs()); }),
                    () => Dispatcher.BeginInvoke(() => { if (UnmountButton.IsEnabled) Unmount_Click(this, new RoutedEventArgs()); }),
                    () => Dispatcher.BeginInvoke(() => Exit_Click(this, new RoutedEventArgs())));
            }
            catch (Exception ex) { DesktopWarning = "System tray is unavailable: " + ex.Message; }
        }
        try
        {
            if (!previewMode)
            {
                Settings.Prepare(); ready = true;
                try { ExplorerAppearance.RestoreAll(); }
                catch (Exception ex) { DesktopWarning = "Previous drive appearance cleanup needs attention: " + ex.Message; }
                settings = Settings.Load();
            }
            else
            {
                ready = true;
                BundledGoogleClient.Apply(settings);
                if (args.Contains("--drive-preview")) accountOverview = new("Example account", "", new(5L * 1024 * 1024 * 1024 * 1024, 4716904883159));
                if (args.Contains("--multi-preview"))
                {
                    settings.AddAccount(new string('A', 64), "personal@example.com", _ => false); settings.DriveName = "Personal Drive";
                    settings.AddAccount(new string('B', 64), "work@example.com", _ => false); settings.DriveName = "Work Drive";
                    settings.SelectAccount(new string('A', 64));
                }
            }
            if (Settings.ValidAccountId(settings.AccountId)) explorer = GetMount(settings.AccountId);
            CloseToTrayCheck.IsChecked = settings.CloseToTray;
            StreamingCacheCheck.IsChecked = settings.StreamingCacheEnabled;
            DriveNameBox.Text = settings.DriveName;
            CloseToTrayCheck.IsEnabled = tray != null || previewMode;
            if (!previewMode)
            {
                try
                {
                    startupAvailable = true;
                    StartupCheck.IsChecked = startup.IsEnabled;
                    if (startup.IsEnabled && !startup.UsesExecutable(Environment.ProcessPath!))
                        DesktopWarning = "Startup points to a different app folder. Turn Start with Windows off and on to use this copy.";
                }
                catch (Exception ex) { startupAvailable = false; DesktopWarning = "Could not read Windows startup settings: " + ex.Message; }
            }
            PreferencesStatus.Text = DesktopWarning.Length > 0 ? DesktopWarning : "Windows startup opens Cloudlane in the tray. Auto-connect reconnects the accounts you have enabled.";
            LetterPicker.SelectedItem = settings.Letter;
            QueueGrid.ItemsSource = queue.Jobs; UpdateUi(); timer.Start();
            StatusText.Text = settings.HasClient ? "Sign in with Google to connect your Drive. Use Add Google account for additional accounts." : "Open Google app setup to configure your Desktop OAuth client once.";
            if (render >= 0 && render + 1 < args.Length)
            {
                SetupWindow? preview = null;
                if (args.Contains("--setup-preview")) { preview = new SetupWindow(settings) { Owner = this }; preview.Show(); }
                await Task.Delay(250); UpdateLayout(); preview?.UpdateLayout(); var view = (FrameworkElement)(preview?.Content ?? Content);
                var image = new RenderTargetBitmap((int)view.ActualWidth, (int)view.ActualHeight, 96, 96, PixelFormats.Pbgra32); image.Render(view);
                var encoder = new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(image)); using (var file = File.Create(args[render + 1])) encoder.Save(file); preview?.Close(); Close(); return;
            }
            if (startInTray && tray != null) Hide();
            else if (startInTray) ShowFromTray();
            if (!previewMode) { await ReadCacheUsageAsync(); UpdateUi(); await RunAsync(AutoConnectAsync); }
            if (settings.IsSignedIn && settings.AccountId.Length == 64) await RunAsync(ConnectAsync);
        }
        catch (Exception ex)
        {
            StatusText.Text = "Could not open saved settings: " + ex.Message + (ready ? " Use Remove account to reset that account's local sign-in, or configure the Google app again." : " Extract Cloudlane into a writable folder for your Windows account.");
            if (startInTray) ShowFromTray(); UpdateUi();
        }
    }
    private void UpdateUi()
    {
        bool working = busy || lifetime.IsExiting;
        AccountLabel.Text = "Google accounts";
        RefreshAccounts();
        AccountPicker.IsEnabled = ready && !working;
        AutoConnectCheck.IsEnabled = ready && !working && settings.Accounts.Any(a => a.Id == settings.AccountId);
        AutoConnectCheck.IsChecked = settings.Accounts.FirstOrDefault(a => a.Id == settings.AccountId)?.AutoConnect == true;
        DisconnectAllButton.IsEnabled = !working && AnyMounted;
        ImportButton.IsEnabled = ready && !working && settings.Accounts.Count == 0; SignInButton.IsEnabled = ready && !working;
        ImportButton.Visibility = BundledGoogleClient.IsAvailable ? Visibility.Collapsed : Visibility.Visible;
        SignInButton.Content = settings.Accounts.Count == 0 && settings.HasClient ? "Sign in with Google" : "Add Google account";
        ForgetButton.IsEnabled = ready && !working && Settings.ValidAccountId(settings.AccountId) && !explorer.IsMounted;
        MountButton.IsEnabled = !busy && drive != null && !explorer.IsMounted && WindowsMapping.Supported;
        UnmountButton.IsEnabled = !busy && explorer.IsMounted; OpenDriveButton.IsEnabled = explorer.IsMounted; LetterPicker.IsEnabled = !busy && !explorer.IsMounted;
        if (!WindowsMapping.Supported) MountStatus.Text = "This driver-free mount needs Windows 11 24H2 or newer (build 26100+).";
        FilesButton.IsEnabled = FolderButton.IsEnabled = !busy && drive != null && folders.Count > 0;
        UpButton.IsEnabled = !busy && folders.Count > 1; RefreshButton.IsEnabled = ready && !busy && settings.IsSignedIn;
        NewFolderButton.IsEnabled = !busy && drive != null && folders.Count > 0;
        StartButton.IsEnabled = !busy && drive != null && queue.Jobs.Any(j => !j.Complete);
        PauseButton.IsEnabled = busy; PauseButton.Content = signingIn ? "Cancel sign-in" : connectingAtStartup ? "Cancel auto-connect" : "Pause";
        RemoveButton.IsEnabled = !busy && QueueGrid.SelectedItem is UploadJob;
        ClearButton.IsEnabled = !busy && queue.Jobs.Any(j => j.Complete);
        DropZone.Opacity = busy || drive == null ? 0.55 : 1;
        FolderLabel.Text = folders.Count == 0 ? "My Drive" : string.Join(" / ", folders.Select(f => f.Name));
        HideButton.IsEnabled = tray != null && !lifetime.IsExiting;
        ExitButton.IsEnabled = !lifetime.IsExiting;
        StartupCheck.IsEnabled = ready && (startupAvailable || previewMode) && !lifetime.IsExiting;
        CloseToTrayCheck.IsEnabled = ready && (tray != null || previewMode) && !lifetime.IsExiting;
        StreamingCacheCheck.IsEnabled = CacheFolderButton.IsEnabled = ClearCacheButton.IsEnabled = ready && !working && !AnyMounted;
        DriveNameBox.IsEnabled = SaveDriveNameButton.IsEnabled = ready && !working && !explorer.IsMounted;
        if (explorer.IsMounted) DriveNameStatus.Text = "Disconnect the drive to change its name, then reconnect to apply it in Explorer.";
        else if (DriveNameStatus.Text.StartsWith("Disconnect the drive", StringComparison.Ordinal)) DriveNameStatus.Text = "Leave blank to use your Google account name. Save before connecting.";
        tray?.Update(explorer.IsMounted, !working && drive != null && !explorer.IsMounted && WindowsMapping.Supported,
            working, lifetime.IsExiting, explorer.Letter, mounts.Values.Count(m => m.IsMounted));
        if (lifetime.IsExiting)
        {
            ImportButton.IsEnabled = SignInButton.IsEnabled = ForgetButton.IsEnabled = MountButton.IsEnabled = UnmountButton.IsEnabled = OpenDriveButton.IsEnabled = false;
            FilesButton.IsEnabled = FolderButton.IsEnabled = UpButton.IsEnabled = RefreshButton.IsEnabled = NewFolderButton.IsEnabled = false;
            StartButton.IsEnabled = PauseButton.IsEnabled = RemoveButton.IsEnabled = ClearButton.IsEnabled = LetterPicker.IsEnabled = false;
            DropZone.IsEnabled = StartupCheck.IsEnabled = CloseToTrayCheck.IsEnabled = false;
        }
        RefreshQueue();
        UpdateDriveDisplay();
    }
    private void UpdateDriveDisplay()
    {
        var info = explorer.IsMounted ? explorer.Overview : accountOverview;
        DriveDisplayLabel.Text = explorer.IsMounted ? explorer.DisplayLabel : settings.DriveLabel(info);
        StorageSummary.Text = info?.StorageText ?? "Sign in to see your Google storage.";
        StorageBar.Visibility = info?.Capacity.TotalBytes > 0 ? Visibility.Visible : Visibility.Collapsed;
        StorageBar.Value = info?.UsedPercent ?? 0;
        AppearanceStatus.Text = explorer.AppearanceWarning.Length > 0 ? explorer.AppearanceWarning : "Driver-free connection · Appears under Network locations in This PC";
        CacheBadge.Text = settings.StreamingCacheEnabled ? "2 GB STREAMING CACHE" : "NO UPLOAD STAGING";
        var cacheMount = mounts.Values.FirstOrDefault(m => m.IsMounted);
        long bytes = cacheMount?.CachedBytes ?? offlineCachedBytes;
        CacheUsageText.Text = explorer.CacheProblem.Length > 0 ? explorer.CacheProblem : cacheStatus.Length > 0 ? cacheStatus :
            (settings.StreamingCacheEnabled ? $"{bytes / 1048576d:F0} MB / 2 GB shared across drives · " + (cacheMount?.CacheDownloads > 0 ? "Preloading video data…" : "Preloads upcoming video data; older parts are removed automatically.") : "Streaming cache is off. Saved parts remain until you clear them.");
        try { CacheFolderText.Text = settings.StreamingCacheDirectory; } catch (Exception ex) { CacheFolderText.Text = ex.Message; }
    }
    private void RefreshQueue()
    {
        QueueGrid.Items.Refresh();
        QueueSummary.Text = $"{queue.Jobs.Count(j => j.Complete)} complete · {queue.Jobs.Count(j => !j.Complete)} pending · {queue.Jobs.Count(j => j.Error.Length > 0)} need attention";
        JobDetails.Text = QueueGrid.SelectedItem is UploadJob selected ? selected.Error : "";
    }
    private async Task RunAsync(Func<Task> action)
    {
        if (busy || lifetime.IsExiting) return;
        var complete = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        activeOperation = complete.Task;
        busy = true; cancellation = new CancellationTokenSource(); UpdateUi();
        try { await action(); }
        catch (OperationCanceledException) { StatusText.Text = signingIn ? "Sign-in cancelled or timed out. Use Add Google account to try again." : "Paused. Use Start / retry to continue from your original files."; }
        catch (Exception ex) { StatusText.Text = ex.Message; }
        finally { cancellation.Dispose(); cancellation = null; busy = false; complete.TrySetResult(); UpdateUi(); }
    }
    private async Task ConnectAsync()
    {
        drive?.Dispose(); drive = null; folders.Clear(); FilesGrid.ItemsSource = null;
        queue = UploadQueue.Load(settings); QueueGrid.ItemsSource = queue.Jobs;
        var connected = new GoogleDriveApi(settings);
        try
        {
            var root = await connected.GetAsync("root", cancellation!.Token);
            var children = await connected.ListFolderAsync(root.Id, cancellation.Token);
            var info = await connected.OverviewAsync(cancellation.Token);
            accountOverview = info;
            drive = connected; folders.Add((root.Id, "My Drive")); FilesGrid.ItemsSource = children;
            StatusText.Text = "Choose a destination folder, then select or drop your originals to upload.";
        }
        catch { connected.Dispose(); throw; }
    }
    private sealed record AccountChoice(string Id, string Caption)
    { public override string ToString() => Caption; }
    private ExplorerMount GetMount(string id)
    {
        if (!mounts.TryGetValue(id, out var mounted)) { mounted = new ExplorerMount(); mounts.Add(id, mounted); }
        return mounted;
    }
    private void RefreshAccounts()
    {
        updatingAccounts = true;
        try
        {
            var choices = settings.Accounts.Select(a =>
            {
                mounts.TryGetValue(a.Id, out var m);
                return new AccountChoice(a.Id, (m?.IsMounted == true ? m.Letter : a.Letter) + "  ·  " + a.Email + "  ·  " + (m?.IsMounted == true ? "Connected" : "Disconnected"));
            }).ToList();
            AccountPicker.ItemsSource = choices; AccountPicker.SelectedItem = choices.FirstOrDefault(a => a.Id == settings.AccountId);
            int count = mounts.Values.Count(m => m.IsMounted);
            AccountsSummary.Text = settings.Accounts.Count == 0 ? "Add an account, choose a drive letter, then connect. Each account can stay connected." :
                settings.Accounts.Count + " saved account(s) · " + count + " drive(s) connected. Switching accounts keeps other drives running.";
        }
        finally { updatingAccounts = false; }
    }
    private void ResetSelectedAccount()
    {
        drive?.Dispose(); drive = null; accountOverview = null; folders.Clear(); FilesGrid.ItemsSource = null;
        queue = new(); QueueGrid.ItemsSource = queue.Jobs;
        explorer = Settings.ValidAccountId(settings.AccountId) ? GetMount(settings.AccountId) : new ExplorerMount();
        DriveNameBox.Text = settings.DriveName; LetterPicker.SelectedItem = settings.Letter;
        DriveNameStatus.Text = "Leave blank to use your Google account name. Save before connecting.";
        AutoConnectStatus.Text = "Uses this account's saved drive letter. Windows may ask for administrator approval.";
        MountStatus.Text = explorer.IsMounted ? explorer.Letter + " connected. This account's drive stays available while you select another account." : explorer.LastError.Length > 0 ? explorer.LastError : "Choose this account's drive letter and connect.";
        TransferBar.Value = 0; TransferLabel.Text = "Ready for this account's uploads";
    }
    private async void Account_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
        if (!ready || updatingAccounts || previewMode || busy || lifetime.IsExiting || AccountPicker.SelectedItem is not AccountChoice choice || choice.Id == settings.AccountId) return;
        await RunAsync(async () =>
        {
            settings.SaveAccountChange(s => s.SelectAccount(choice.Id)); ResetSelectedAccount();
            if (settings.IsSignedIn) await ConnectAsync();
            else StatusText.Text = "This account needs sign-in. Click Add Google account and select the same email to sign in again.";
        });
    }
    private async Task DisconnectAllAsync()
    {
        var failures = new List<Exception>();
        foreach (var mount in mounts.Values.Where(m => m.IsMounted).ToArray())
            try { await mount.UnmountAsync(); } catch (Exception ex) { failures.Add(ex); }
        if (failures.Count > 0) throw new AggregateException("Some drives could not disconnect. Try disconnecting them again.", failures);
    }
    private async void DisconnectAll_Click(object sender, RoutedEventArgs e) => await RunAsync(async () =>
    { await DisconnectAllAsync(); await ReadCacheUsageAsync(); MountStatus.Text = "All drives disconnected."; });
    private void AutoConnect_Click(object sender, RoutedEventArgs e)
    {
        if (!ready || previewMode || busy || lifetime.IsExiting || !settings.Accounts.Any(a => a.Id == settings.AccountId)) return;
        bool enabled = AutoConnectCheck.IsChecked == true;
        try
        {
            settings.SaveAccountChange(s =>
            {
                s.Accounts.First(a => a.Id == s.AccountId).AutoConnect = enabled;
                s.Letter = explorer.IsMounted ? explorer.Letter : LetterPicker.SelectedItem as string ?? s.Letter;
            });
            AutoConnectStatus.Text = enabled ? "Saved. This account will reconnect when Cloudlane starts. Windows may ask for approval." : "Auto-connect is off for this account.";
        }
        catch (Exception ex) { AutoConnectStatus.Text = "Could not save auto-connect: " + ex.Message; }
        UpdateUi();
    }
    private async Task AutoConnectAsync()
    {
        if (previewMode || !settings.Accounts.Any(a => a.AutoConnect)) return;
        if (!settings.HasClient || !WindowsMapping.Supported)
        {
            StartupConnectionStatus.Text = settings.HasClient ? "Auto-connect requires Windows 11 24H2 or newer (build 26100+)." : "Auto-connect needs Google app setup. Your saved account preferences are retained.";
            if (startInTray) ShowFromTray(); return;
        }
        connectingAtStartup = true; UpdateUi();
        var completed = new List<StartupConnectionResult>();
        try
        {
            await startupConnections.RunAsync(settings, s => s.IsSignedIn, s => GetMount(s.AccountId).IsMounted,
                ExplorerMount.LetterInUse, async (account, ct) =>
                {
                    StartupConnectionStatus.Text = "Auto-connect: connecting " + account.AccountEmail + " (" + account.Letter + "). Windows may ask for administrator approval…";
                    await GetMount(account.AccountId).MountAsync(account, account.Letter, ct);
                }, result =>
                {
                    completed.Add(result);
                    StartupConnectionStatus.Text = "Auto-connect: " + string.Join(" · ", completed.Select(r => r.Letter + " " + r.Message));
                    if (result.AccountId == settings.AccountId) MountStatus.Text = result.Letter + ": " + result.Message;
                    UpdateUi();
                }, cancellation!.Token);
            if (startInTray && completed.Any(r => !r.Connected)) ShowFromTray();
        }
        catch (OperationCanceledException)
        { StartupConnectionStatus.Text = "Auto-connect cancelled. Connected drives stay available; use Connect drive to connect others."; throw; }
        finally { connectingAtStartup = false; UpdateUi(); }
    }
    private async Task RefreshAsync()
    {
        if (drive != null && folders.Count > 0)
        {
            FilesGrid.ItemsSource = await drive.ListFolderAsync(folders[^1].Id, cancellation!.Token);
            if (!explorer.IsMounted) accountOverview = await drive.OverviewAsync(cancellation.Token);
        }
        explorer.Refresh();
    }
    private void Import_Click(object sender, RoutedEventArgs e)
    {
        new SetupWindow(settings) { Owner = this }.ShowDialog();
        StatusText.Text = settings.HasClient ? "Google app configured. Click Add Google account to connect another account." : "Google app setup is needed before sign-in."; UpdateUi();
    }
    private async void SignIn_Click(object sender, RoutedEventArgs e)
    {
        if (busy || lifetime.IsExiting || previewMode) return;
        if (!settings.HasClient) { Import_Click(sender, e); if (!settings.HasClient) return; }
        signingIn = true;
        try
        {
            await RunAsync(async () =>
            {
                StatusText.Text = "Finish Google sign-in in your browser. Cancel sign-in stops waiting.";
                var result = await GoogleAuth.SignInAsync(settings, cancellation!.Token);
                // A selected browser account may already be connected. Keep its active token/store intact.
                if (mounts.TryGetValue(result.AccountId, out var active) && active.IsMounted)
                {
                    settings.SaveAccountChange(s => s.SelectAccount(result.AccountId)); ResetSelectedAccount();
                    signingIn = false; await ConnectAsync();
                    StatusText.Text = "That Google account is already connected. Its drive stays available."; return;
                }
                var candidate = settings.Snapshot(); candidate.AccountId = result.AccountId;
                Settings.SaveToken(candidate, result.Token);
                settings.SaveAccountChange(s => s.AddAccount(result.AccountId, result.Email, ExplorerMount.LetterInUse)); ResetSelectedAccount();
                signingIn = false; await ConnectAsync();
            });
        }
        finally { signingIn = false; UpdateUi(); }
    }
    private async void Forget_Click(object sender, RoutedEventArgs e)
    {
        if (busy || lifetime.IsExiting || previewMode || explorer.IsMounted || !Settings.ValidAccountId(settings.AccountId)) return;
        await RunAsync(async () =>
        {
            string id = settings.AccountId, tokenPath = settings.TokenPath;
            // Commit the removal before deleting only this account's encrypted sign-in.
            settings.SaveAccountChange(s => s.RemoveSelected()); mounts.Remove(id);
            string warning = "";
            try { File.Delete(tokenPath); } catch (Exception ex) { warning = " The old local sign-in file could not be removed: " + ex.Message; }
            ResetSelectedAccount();
            if (settings.IsSignedIn) await ConnectAsync();
            StatusText.Text = "Account removed locally. Its cloud files and saved upload references are retained." + warning;
        });
    }
    private async void Refresh_Click(object sender, RoutedEventArgs e) => await RunAsync(async () =>
    { if (drive == null && settings.IsSignedIn) await ConnectAsync(); else await RefreshAsync(); });
    private async void Up_Click(object sender, RoutedEventArgs e) => await RunAsync(async () =>
    {
        if (folders.Count <= 1 || drive == null) return;
        var children = await drive.ListFolderAsync(folders[^2].Id, cancellation!.Token);
        folders.RemoveAt(folders.Count - 1); FilesGrid.ItemsSource = children;
    });
    private async void Files_DoubleClick(object sender, MouseButtonEventArgs e)
    {
        if (busy || FilesGrid.SelectedItem is not DriveFile file) return;
        if (file.IsDirectory) await RunAsync(async () =>
        { var children = await drive!.ListFolderAsync(file.Id, cancellation!.Token); folders.Add((file.Id, file.Name)); FilesGrid.ItemsSource = children; });
        else TryLaunch("https://drive.google.com/open?id=" + Uri.EscapeDataString(file.Id));
    }
    private async Task QueueSourcesAsync(IEnumerable<string> sources)
    {
        if (drive == null || folders.Count == 0) throw new IOException("Sign in and choose a destination first.");
        string parent = folders[^1].Id, destination = string.Join("/", folders.Select(f => f.Name));
        StatusText.Text = "Reading the selected file and folder names…";
        var jobs = await Task.Run(() => UploadQueue.Plan(sources, parent, destination, cancellation!.Token), cancellation!.Token);
        cancellation!.Token.ThrowIfCancellationRequested();
        queue.Jobs.AddRange(jobs); queue.Save(settings); RefreshQueue(); await UploadAsync();
    }
    private async Task UploadAsync()
    {
        var progress = new Progress<UploadProgress>(p =>
        { TransferLabel.Text = $"{p.Name} · {p.Confirmed / 1048576d:F1} / {p.Total / 1048576d:F1} MB · {p.State}"; TransferBar.Value = p.Total > 0 ? p.Confirmed * 100d / p.Total : p.State == "Upload complete" ? 100 : 0; });
        StatusText.Text = "Uploading from original locations. No staging copies are made.";
        await UploadCoordinator.RunAsync(queue, drive!, () => queue.Save(settings), progress, cancellation!.Token);
        var failed = queue.Jobs.FirstOrDefault(j => !j.Complete && j.Error.Length > 0);
        StatusText.Text = failed != null ? failed.Name + ": " + failed.Error : queue.Jobs.All(j => j.Complete) ? "Google confirmed every queued upload. Your originals remain in place." : "Some uploads are waiting for their parent folder. Use Start / retry.";
        try { await RefreshAsync(); }
        catch (Exception ex) when (ex is not OperationCanceledException) { StatusText.Text += " Folder refresh failed: " + ex.Message; }
    }
    private async void Files_Click(object sender, RoutedEventArgs e)
    {
        var picker = new Microsoft.Win32.OpenFileDialog { Multiselect = true, Title = "Select original files to upload directly" };
        if (picker.ShowDialog(this) == true) await RunAsync(() => QueueSourcesAsync(picker.FileNames));
    }
    private async void Folder_Click(object sender, RoutedEventArgs e)
    {
        using var picker = new Forms.FolderBrowserDialog { Description = "Select the original folder to upload directly", UseDescriptionForTitle = true };
        if (picker.ShowDialog() == Forms.DialogResult.OK) await RunAsync(() => QueueSourcesAsync(new[] { picker.SelectedPath }));
    }
    private void Files_DragOver(object sender, DragEventArgs e)
    { e.Effects = !busy && drive != null && e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None; e.Handled = true; }
    private async void Files_Drop(object sender, DragEventArgs e)
    { e.Handled = true; if (!busy && drive != null && e.Data.GetData(DataFormats.FileDrop) is string[] sources) await RunAsync(() => QueueSourcesAsync(sources)); }
    private async void Start_Click(object sender, RoutedEventArgs e) => await RunAsync(UploadAsync);
    private void Pause_Click(object sender, RoutedEventArgs e) => cancellation?.Cancel();
    private void Remove_Click(object sender, RoutedEventArgs e)
    {
        if (QueueGrid.SelectedItem is not UploadJob job) return;
        try
        {
            var keys = new HashSet<string> { job.Key }; bool changed;
            do { changed = false; foreach (var child in queue.Jobs.Where(j => keys.Contains(j.ParentJobKey))) changed |= keys.Add(child.Key); } while (changed);
            queue.Jobs.RemoveAll(j => keys.Contains(j.Key)); queue.Save(settings); UpdateUi();
        }
        catch (Exception ex) { StatusText.Text = ex.Message; }
    }
    private void Clear_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            queue.ClearCompleted(); queue.Save(settings); UpdateUi();
        }
        catch (Exception ex) { StatusText.Text = ex.Message; }
    }
    private void Queue_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    { if (ready) { RemoveButton.IsEnabled = !busy && QueueGrid.SelectedItem is UploadJob; JobDetails.Text = QueueGrid.SelectedItem is UploadJob job ? job.Error : ""; } }
    private async void NewFolder_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new NameWindow { Owner = this }; if (dialog.ShowDialog() != true) return;
        await RunAsync(async () =>
        {
            string id = await drive!.GenerateIdAsync(cancellation!.Token);
            await drive.FolderAsync(id, dialog.FolderName, folders[^1].Id, cancellation.Token);
            await RefreshAsync(); StatusText.Text = "Folder created: " + dialog.FolderName;
        });
    }
    private void TryLaunch(string url)
    { try { Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); } catch (Exception ex) { StatusText.Text = ex.Message; } }
    private void Guide_Click(object sender, RoutedEventArgs e) => TryLaunch(Path.Combine(AppContext.BaseDirectory, "README.html"));
    private void CopyMountDiagnostics_Click(object sender, RoutedEventArgs e)
    { try { Clipboard.SetText(explorer.Diagnostics); MountStatus.Text = "Mount diagnostics copied to clipboard."; } catch (Exception ex) { StatusText.Text = ex.Message; } }
    private async void Mount_Click(object sender, RoutedEventArgs e) => await RunAsync(async () =>
    {
        cacheStatus = "";
        string letter = LetterPicker.SelectedItem as string ?? "G:";
        MountStatus.Text = "Connecting. Windows will ask for administrator approval to map this drive.";
        try
        {
            await explorer.MountAsync(settings, letter, cancellation!.Token); settings.Letter = letter; settings.Save();
            MountStatus.Text = letter + " connected. Copy files or folders into this drive to upload; open cloud files to stream them.";
        }
        catch (Exception ex) { MountStatus.Text = ex.Message; throw; }
    });
    private void OpenDrive_Click(object sender, RoutedEventArgs e) { if (explorer.IsMounted) TryLaunch(explorer.Letter + "\\"); }
    private void SaveDriveName_Click(object sender, RoutedEventArgs e)
    {
        if (!ready || previewMode || explorer.IsMounted || busy || lifetime.IsExiting) return;
        string previous = settings.DriveName;
        settings.DriveName = ExplorerAppearance.NormalizeCustomLabel(DriveNameBox.Text);
        try
        {
            settings.Save(); DriveNameBox.Text = settings.DriveName;
            DriveNameStatus.Text = settings.DriveName.Length == 0 ? "Automatic Google account name restored. Connect the drive to apply it in Explorer." : "Name saved. Connect the drive to apply it in Explorer.";
        }
        catch (Exception ex) { settings.DriveName = previous; DriveNameStatus.Text = "Could not save drive name: " + ex.Message; }
        UpdateUi();
    }
    private async void Unmount_Click(object sender, RoutedEventArgs e) => await RunAsync(async () =>
    { await explorer.UnmountAsync(); await ReadCacheUsageAsync(); MountStatus.Text = "Drive disconnected. Completed uploads remain in Google Drive."; });
    private async Task ReadCacheUsageAsync()
    {
        if (AnyMounted) { offlineCachedBytes = mounts.Values.First(m => m.IsMounted).CachedBytes; cacheStatus = ""; return; }
        try { offlineCachedBytes = await Task.Run(() => MediaBlockCache.Inspect(settings.StreamingCacheDirectory)); cacheStatus = ""; }
        catch (Exception ex) { cacheStatus = "Could not read cache usage: " + ex.Message; }
    }
    private void StreamingCache_Click(object sender, RoutedEventArgs e)
    {
        if (!ready || previewMode || AnyMounted) return;
        bool previous = settings.StreamingCacheEnabled; settings.StreamingCacheEnabled = StreamingCacheCheck.IsChecked == true;
        try { settings.Save(); cacheStatus = ""; }
        catch (Exception ex) { settings.StreamingCacheEnabled = previous; StreamingCacheCheck.IsChecked = previous; cacheStatus = ex.Message; }
        UpdateUi();
    }
    private async void CacheFolder_Click(object sender, RoutedEventArgs e)
    {
        if (!ready || previewMode || AnyMounted || busy) return;
        using var picker = new Forms.FolderBrowserDialog { Description = "Choose a local folder for the 2 GB streaming cache", UseDescriptionForTitle = true };
        if (picker.ShowDialog() != Forms.DialogResult.OK) return;
        await RunAsync(async () =>
        {
        string previous = settings.StreamingCacheBaseDirectory;
        string oldFolder;
        try { oldFolder = settings.StreamingCacheDirectory; } catch { oldFolder = ""; }
        settings.StreamingCacheBaseDirectory = picker.SelectedPath;
        try { _ = settings.StreamingCacheDirectory; settings.Save(); }
        catch (Exception ex) { settings.StreamingCacheBaseDirectory = previous; cacheStatus = ex.Message; }
        if (settings.StreamingCacheBaseDirectory == picker.SelectedPath)
        {
            string warning = "";
            if (oldFolder.Length > 0 && !oldFolder.Equals(settings.StreamingCacheDirectory, StringComparison.OrdinalIgnoreCase))
                try { await Task.Run(() => MediaBlockCache.ClearStored(oldFolder)); }
                catch (Exception ex) { warning = " Previous cache could not be cleared: " + ex.Message; }
            await ReadCacheUsageAsync(); cacheStatus = "Cache folder changed. New streams will use this location." + warning;
        }
        });
    }
    private async void ClearCache_Click(object sender, RoutedEventArgs e)
    {
        if (!ready || previewMode || AnyMounted) return;
        await RunAsync(async () =>
        {
            await Task.Run(() => MediaBlockCache.ClearStored(settings.StreamingCacheDirectory));
            await ReadCacheUsageAsync(); cacheStatus = "Cache cleared. Your Google Drive files are unchanged.";
        });
    }
    private void OnClosing(object? sender, CancelEventArgs e)
    {
        if (previewMode || lifetime.CanClose || sessionEnding) { DisposeDesktop(); return; }
        e.Cancel = true;
        // Defer visibility changes until WPF has finished cancelling this close request.
        Dispatcher.BeginInvoke(async () =>
        {
            if (lifetime.HideOnClose(settings.CloseToTray, tray != null)) return;
            await RequestExitAsync();
        });
    }
    public void ShowFromTray()
    {
        if (sessionEnding || lifetime.CanClose) return;
        ShowInTaskbar = true; ShowActivated = true; Show();
        if (WindowState == WindowState.Minimized) WindowState = WindowState.Normal;
        Activate();
    }
    private void HideToTray()
    {
        Hide();
        if (!hiddenNoticeShown) { hiddenNoticeShown = true; tray?.ExplainHidden(); }
    }
    private void Hide_Click(object sender, RoutedEventArgs e) { if (tray != null) HideToTray(); }
    private async void Exit_Click(object sender, RoutedEventArgs e) => await RequestExitAsync();
    private async Task RequestExitAsync()
    {
        try { await lifetime.ExitAsync(); }
        catch (Exception ex)
        {
            ShowFromTray(); StatusText.Text = "Could not finish exiting: " + ex.Message + " Try Disconnect, then Exit again.";
            DropZone.IsEnabled = true; StartupCheck.IsEnabled = ready; CloseToTrayCheck.IsEnabled = tray != null; UpdateUi();
        }
    }
    private async Task StopForExitAsync()
    {
        UpdateUi(); StatusText.Text = "Pausing app uploads and disconnecting the Explorer drive…";
        cancellation?.Cancel(); await activeOperation;
        await DisconnectAllAsync();
        DisposeDesktop();
    }
    private void FinishExit() { Close(); Application.Current.Shutdown(); }
    public void OnSessionEnding() { sessionEnding = true; cancellation?.Cancel(); DisposeDesktop(); }
    public void DisposeDesktop() { timer.Stop(); tray?.Dispose(); tray = null; drive?.Dispose(); drive = null; }
    private void Startup_Click(object sender, RoutedEventArgs e)
    {
        if (!ready || previewMode) return;
        bool enabled = StartupCheck.IsChecked == true;
        try
        {
            startup.SetEnabled(enabled, Environment.ProcessPath!);
            PreferencesStatus.Text = enabled ? "Startup enabled for your Windows account. Cloudlane will open in the tray after you sign in to Windows." : "Windows startup is off.";
        }
        catch (Exception ex) { StartupCheck.IsChecked = !enabled; PreferencesStatus.Text = "Could not change Windows startup: " + ex.Message; }
    }
    private void CloseToTray_Click(object sender, RoutedEventArgs e)
    {
        if (!ready || previewMode) return;
        bool previous = settings.CloseToTray; settings.CloseToTray = CloseToTrayCheck.IsChecked == true;
        try
        {
            settings.Save();
            PreferencesStatus.Text = settings.CloseToTray ? "Closing the window keeps the drive and uploads running. Use the tray menu to Exit." : "Closing the window will pause app uploads, disconnect the drive, and exit.";
        }
        catch (Exception ex) { settings.CloseToTray = previous; CloseToTrayCheck.IsChecked = previous; PreferencesStatus.Text = "Could not save the preference: " + ex.Message; }
    }
}
