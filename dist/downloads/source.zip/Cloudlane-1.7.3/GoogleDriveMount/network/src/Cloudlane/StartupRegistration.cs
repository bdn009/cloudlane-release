using System;
using System.IO;
using Microsoft.Win32;
namespace Cloudlane;

public interface IStartupStore
{
    string? Read();
    void Write(string command);
    void Remove();
}

// Only this application's current-user Run value is touched, on an explicit preference change.
public sealed class UserStartupStore : IStartupStore
{
    private const string KeyPath = @"Software\Microsoft\Windows\CurrentVersion\Run";
    private const string ValueName = "Cloudlane.GoogleDrive.Production";
    public string? Read()
    {
        using var key = Registry.CurrentUser.OpenSubKey(KeyPath);
        return key?.GetValue(ValueName, null, RegistryValueOptions.DoNotExpandEnvironmentNames) as string;
    }
    public void Write(string command)
    {
        using var key = Registry.CurrentUser.CreateSubKey(KeyPath, true);
        key.SetValue(ValueName, command, RegistryValueKind.String);
    }
    public void Remove()
    {
        using var key = Registry.CurrentUser.OpenSubKey(KeyPath, true);
        key?.DeleteValue(ValueName, false);
    }
}

public sealed class StartupRegistration
{
    private readonly IStartupStore store;
    public StartupRegistration(IStartupStore store) => this.store = store;
    public static string Command(string executable)
    {
        if (string.IsNullOrWhiteSpace(executable) || !Path.IsPathFullyQualified(executable) ||
            executable.IndexOfAny(new[] { '"', '\r', '\n', '\0' }) >= 0 ||
            !executable.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("Startup needs the full path to Cloudlane.exe.");
        string command = "\"" + executable + "\" --startup";
        if (command.Length > 260) throw new IOException("Move Cloudlane to a shorter folder path before enabling Windows startup.");
        return command;
    }
    public bool IsEnabled => !string.IsNullOrWhiteSpace(store.Read());
    public bool UsesExecutable(string executable) => string.Equals(store.Read(), Command(executable), StringComparison.OrdinalIgnoreCase);
    public void SetEnabled(bool enabled, string executable)
    {
        if (enabled) store.Write(Command(executable));
        else store.Remove();
    }
    public void RemoveIfOwned(string executable)
    { if (UsesExecutable(executable)) store.Remove(); }
}
