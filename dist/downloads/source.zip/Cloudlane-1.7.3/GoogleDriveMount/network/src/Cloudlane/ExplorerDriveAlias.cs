using System;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
namespace Cloudlane;
// Create the letter in the caller's unelevated DOS namespace, the one Explorer uses.
// The elevated helper establishes only the authenticated SMB connection.
internal sealed class ExplorerDriveAlias : IDisposable
{
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern bool DefineDosDevice(uint flags, string name, string target);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern uint QueryDosDevice(string name, StringBuilder target, int length);
    [DllImport("shell32.dll", CharSet = CharSet.Unicode)] private static extern void SHChangeNotify(uint change, uint flags, string item1, IntPtr item2);
    private readonly string letter, target;
    private readonly bool notify;
    private bool removed;
    public static string? Target(string letter)
    { var buffer = new StringBuilder(32768); return QueryDosDevice(letter, buffer, buffer.Capacity) == 0 ? null : buffer.ToString(); }
    public static string MakeTarget(string share)
    {
        if (share.Length != 26 || !share.StartsWith("Cloudlane_", StringComparison.Ordinal) || Array.Exists(share[10..].ToCharArray(), c => !Uri.IsHexDigit(c)))
            throw new IOException("Invalid Cloudlane share identity.");
        return @"\Device\Mup\" + LocalSmbEndpoint.Host + @"\" + share;
    }
    public ExplorerDriveAlias(string letter, string share) : this(letter, MakeTarget(share), true) { }
    // An internal raw target overload allows a real, isolated Windows namespace regression check.
    internal ExplorerDriveAlias(string letter, string rawTarget, bool notify)
    {
        if (letter.Length != 2 || letter[0] < 'D' || letter[0] > 'Z' || letter[1] != ':') throw new IOException("Invalid drive letter.");
        if (Target(letter) != null || Array.Exists(DriveInfo.GetDrives(), d => d.Name.StartsWith(letter, StringComparison.OrdinalIgnoreCase)))
            throw new IOException("That drive letter is already used. Choose another letter.");
        this.letter = letter; target = rawTarget; this.notify = notify;
        if (!DefineDosDevice(1 | 8, letter, target))
        { int error = Marshal.GetLastPInvokeError(); throw new Win32Exception(error, $"Windows could not create the desktop drive letter (error {error}: {new Win32Exception(error).Message})."); }
        if (notify) SHChangeNotify(0x100, 0x5, letter + "\\", IntPtr.Zero); // SHCNE_DRIVEADD, SHCNF_PATHW
    }
    public void Dispose()
    {
        if (removed) return;
        // Match the exact target; never remove someone else's replacement mapping.
        if (!DefineDosDevice(1 | 2 | 4 | 8, letter, target))
        { int error = Marshal.GetLastPInvokeError(); throw new Win32Exception(error, $"Windows could not remove Cloudlane's drive letter (error {error}: {new Win32Exception(error).Message})."); }
        removed = true; if (notify) SHChangeNotify(0x80, 0x5, letter + "\\", IntPtr.Zero);
    }
}
