using System;
using System.Collections.Concurrent;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using Cloudlane.Mount;
using SMBLibrary;
using SMBLibrary.Server;
using SMBLibrary.Authentication.GSSAPI;
namespace Cloudlane;

// One Windows server identity/credential, with separate share and store per account.
internal static class ExplorerServerPool
{
    private static readonly object gate = new();
    private static Host? current;
    private sealed class Host
    {
        internal readonly SMBShareCollection Shares = new();
        internal readonly ConcurrentDictionary<Action<string>, byte> Logs = new();
        internal readonly string Password = Convert.ToHexString(RandomNumberGenerator.GetBytes(32));
        internal readonly Server Listener;
        internal readonly int Port;
        internal int Users;
        internal Host()
        {
            Listener = new Server(Shares, new GSSProvider(new CloudlaneAuthentication(Password)));
            Listener.LogEntryAdded += (_, e) => { foreach (var log in Logs.Keys) log(e.Message); };
            for (int attempt = 0; ; attempt++)
            {
                using var reservation = new TcpListener(LocalSmbEndpoint.Address, 0); reservation.Start();
                Port = ((IPEndPoint)reservation.LocalEndpoint).Port; reservation.Stop();
                try { Listener.Listen(Port); break; }
                catch (SocketException) when (attempt < 4) { Listener.Stop(); }
                catch { Listener.Stop(); throw; }
            }
        }
    }
    private sealed class Server(SMBShareCollection shares, GSSProvider authentication) : SMBServer(shares, authentication)
    {
        internal void Listen(int port)
        {
            ConnectionRequested += (_, e) => e.Accept = IPAddress.IsLoopback(e.IPEndPoint.Address);
            Start(LocalSmbEndpoint.Address, SMBTransportType.DirectTCPTransport, port, false, true, true, null);
        }
    }
    internal sealed class Lease : IDisposable
    {
        private readonly Action release;
        internal int Port { get; }
        internal string Password { get; }
        internal string ShareName { get; }
        internal Lease(int port, string password, string shareName, Action release)
        { Port = port; Password = password; ShareName = shareName; this.release = release; }
        public void Dispose() => release();
    }
    internal static Lease Acquire(CloudFileStore store, Action<string> log)
    {
        lock (gate)
        {
            var host = current ??= new Host();
            string name = "Cloudlane_" + Convert.ToHexString(RandomNumberGenerator.GetBytes(8));
            var share = new FileSystemShare(name, store, CachingPolicy.NoCaching);
            share.AccessRequested += (_, e) => e.Allow = e.UserName.Equals("Cloudlane", StringComparison.OrdinalIgnoreCase) && IPAddress.IsLoopback(e.ClientEndPoint.Address);
            host.Shares.AddShare(share); host.Logs.TryAdd(log, 0); host.Users++;
            bool released = false;
            return new Lease(host.Port, host.Password, name, () =>
            {
                lock (gate)
                {
                    if (released) return; released = true;
                    host.Shares.RemoveShare(share); host.Logs.TryRemove(log, out _);
                    if (--host.Users == 0) { host.Listener.Stop(); current = null; }
                }
            });
        }
    }
}
