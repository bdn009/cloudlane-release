using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text.Json;
using System.Text.Json.Serialization;
namespace Cloudlane;
public sealed partial class Settings
{
    public string Letter { get; set; } = "G:";
    public string DriveName { get; set; } = "";
    internal string DriveLabel(DriveOverview? overview) => ExplorerAppearance.Label(overview?.DisplayName, overview?.Email, DriveName);
    public bool CloseToTray { get; set; } = true;
    public bool StreamingCacheEnabled { get; set; } = true;
    public string StreamingCacheBaseDirectory { get; set; } = "";
    [JsonIgnore] public string StreamingCacheDirectory
    {
        get
        {
            string folder = string.IsNullOrWhiteSpace(StreamingCacheBaseDirectory) ? DataDir : Path.GetFullPath(StreamingCacheBaseDirectory);
            string? root = Path.GetPathRoot(folder);
            if (root == null || root.Length != 3 || root[1] != ':') throw new IOException("Choose a local disk folder for the streaming cache.");
            if (new DriveInfo(root).DriveType == DriveType.Network) throw new IOException("Choose a local disk folder rather than a network drive for the cache.");
            return Path.Combine(folder, "CloudlaneStreamingCache-v1");
        }
    }
    public string AccountId { get; set; } = "";
    public string AccountEmail { get; set; } = "";
    [JsonIgnore] public string ClientId { get; set; } = "";
    [JsonIgnore] public string ClientSecret { get; set; } = "";
    [JsonIgnore] public bool HasClient => ClientId.Length > 0 && ClientSecret.Length > 0;
    public static string DataDir => Path.Combine(AppContext.BaseDirectory, "data-direct");
    public static string ConfigPath => Path.Combine(DataDir, "token.bin");
    [JsonIgnore] public string AccountDir => ValidAccountId(AccountId) ? Path.Combine(DataDir, "accounts", AccountId) : throw new IOException("Select a saved Google account first.");
    [JsonIgnore] public string TokenPath => Path.Combine(AccountDir, "token.bin");
    [JsonIgnore] public bool IsSignedIn => ValidAccountId(AccountId) && File.Exists(TokenPath);
    [JsonIgnore] public string QueuePath => Path.Combine(AccountDir, "uploads.bin");
    public static string SettingsPath => Path.Combine(DataDir, "settings.json");
    public static void Prepare()
    {
        Directory.CreateDirectory(DataDir);
        ProtectDirectory(DataDir);
    }
    public static void ProtectDirectory(string folder)
    {
        var acl = new DirectorySecurity(); acl.SetAccessRuleProtection(true, false);
        foreach (var sid in new[] { WindowsIdentity.GetCurrent().User!, new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null) })
            acl.AddAccessRule(new FileSystemAccessRule(sid, FileSystemRights.FullControl, InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow));
        new DirectoryInfo(folder).SetAccessControl(acl);
    }
    public static Settings Load()
    {
        var s = File.Exists(SettingsPath) ? JsonSerializer.Deserialize<Settings>(File.ReadAllText(SettingsPath)) ?? new() : new();
        if (s.AccountId == null || s.AccountId.Length != 64 || s.AccountId.Any(c => !Uri.IsHexDigit(c))) s.AccountId = "";
        s.AccountEmail ??= "";
        s.DriveName = ExplorerAppearance.NormalizeCustomLabel(s.DriveName);
        s.StreamingCacheBaseDirectory ??= "";
        s.InitializeAccounts();
        s.MigrateLegacyToken();
        string client = Path.Combine(DataDir, "client.bin");
        if (File.Exists(client)) { var parsed = ParseClient(SecretStore.Read(client)); s.ClientId = parsed.Id; s.ClientSecret = parsed.Secret; }
        else BundledGoogleClient.Apply(s);
        return s;
    }
    public void Save()
    {
        RememberSelected();
        AtomicWrite(SettingsPath, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
    }
    public void SaveClient(string json)
    {
        if (Accounts.Count > 0) throw new InvalidOperationException("Disconnect and forget all saved accounts before replacing the Google app registration. Then sign in again with your new client.");
        var client = ParseClient(json);
        SecretStore.Write(Path.Combine(DataDir, "client.bin"), json);
        ClientId = client.Id; ClientSecret = client.Secret;
    }
    public static void AtomicWrite(string path, string content)
    { string temp = path + ".tmp"; File.WriteAllText(temp, content); File.Move(temp, path, true); }
    public static void SaveToken(Settings settings, string token)
    { Directory.CreateDirectory(settings.AccountDir); SecretStore.Write(settings.TokenPath, token); }
    public static (string Id, string Secret) ParseClient(string json)
    {
        try
        {
            using var doc = JsonDocument.Parse(json);
            if (doc.RootElement.ValueKind != JsonValueKind.Object || !doc.RootElement.TryGetProperty("installed", out var app) || app.ValueKind != JsonValueKind.Object)
                throw new InvalidOperationException("Choose the JSON downloaded for a Desktop app OAuth client. Web and service-account credentials cannot be used.");
            string id = app.GetProperty("client_id").GetString()?.Trim() ?? "", secret = app.GetProperty("client_secret").GetString()?.Trim() ?? "";
            if (!id.EndsWith(".apps.googleusercontent.com", StringComparison.Ordinal) || id.Length <= ".apps.googleusercontent.com".Length || string.IsNullOrWhiteSpace(secret) || id.Any(char.IsWhiteSpace) || secret.Any(char.IsWhiteSpace))
                throw new InvalidOperationException("The Desktop OAuth client ID or secret is invalid. Download a fresh JSON from Google Cloud.");
            return (id, secret);
        }
        catch (Exception ex) when (ex is JsonException || ex is KeyNotFoundException || ex is InvalidOperationException && ex.Message.StartsWith("The requested operation"))
        { throw new InvalidOperationException("This file is not a valid Desktop OAuth client JSON. Download the Desktop app client from Google Cloud.", ex); }
    }
}
