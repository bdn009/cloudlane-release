using System.Threading;
using System.Linq;
using System.Windows;
namespace Cloudlane;
public partial class App : Application
{
    private Mutex? mutex;
    private InstanceActivation? activation;
    protected override async void OnStartup(StartupEventArgs e)
    {
        if (e.Args.Length == 1 && e.Args[0] == "--remove-owned-startup")
        {
            try { new StartupRegistration(new UserStartupStore()).RemoveIfOwned(System.Environment.ProcessPath!); Shutdown(0); }
            catch { Shutdown(1); }
            return;
        }
        if (e.Args.Length == 2 && e.Args[0] == "--map-helper")
        { await WindowsMapping.RunHelperAsync(e.Args[1]); Shutdown(); return; }
        if (!e.Args.Contains("--render-preview"))
        {
            mutex = new Mutex(true, @"Local\Cloudlane.GoogleDrive.Production.SingleInstance", out bool fresh);
            if (!fresh)
            {
                if (!e.Args.Contains("--startup") && !await InstanceActivation.ShowExistingAsync(InstanceActivation.UserPipeName))
                    MessageBox.Show("Cloudlane is already running. Open its tray icon. If the running copy is an older version, exit it before opening this version.", "Cloudlane");
                Shutdown(); return;
            }
        }
        base.OnStartup(e);
        bool preview = e.Args.Contains("--render-preview");
        if (!preview) ShutdownMode = ShutdownMode.OnExplicitShutdown;
        var window = new MainWindow(e.Args.Contains("--startup")); MainWindow = window;
        if (!preview)
        {
            try { activation = new InstanceActivation(InstanceActivation.UserPipeName, () => Dispatcher.BeginInvoke(window.ShowFromTray)); }
            catch (System.Exception ex) { window.DesktopWarning = "Opening a second copy may not restore the window: " + ex.Message; }
            SessionEnding += (_, _) => window.OnSessionEnding();
        }
        window.Show();
    }
    protected override void OnExit(ExitEventArgs e)
    { activation?.Dispose(); (MainWindow as MainWindow)?.DisposeDesktop(); mutex?.Dispose(); base.OnExit(e); }
}
