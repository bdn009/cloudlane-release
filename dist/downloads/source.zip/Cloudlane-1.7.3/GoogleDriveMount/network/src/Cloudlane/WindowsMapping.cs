using System;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
namespace Cloudlane;
internal sealed record MountRequest(string Letter, int Port, string Share, string User, string Password, string OwnerSid);
internal static class WindowsMapping
{
    public static bool Supported => OperatingSystem.IsWindowsVersionAtLeast(10, 0, 26100);
    public static void Validate(MountRequest r)
    {
        if (r.Letter.Length != 2 || r.Letter[0] < 'D' || r.Letter[0] > 'Z' || r.Letter[1] != ':' || r.Port < 1024 || r.Port > 65535
            || !r.Share.StartsWith("Cloudlane_", StringComparison.Ordinal) || r.Share.Length != 26 || r.Share.Skip(10).Any(c => !Uri.IsHexDigit(c))
            || r.User != "Cloudlane" || r.Password.Length != 64 || r.Password.Any(c => !Uri.IsHexDigit(c)) || !r.OwnerSid.StartsWith("S-1-5-21-", StringComparison.Ordinal))
            throw new IOException("Invalid local drive mapping request.");
    }
    // The elevated helper receives only a temporary LOCAL SMB credential, never Google tokens.
    // A pipe scoped to the current Windows user prevents another user supplying mapping requests.
    public static async Task RunHelperAsync(string pipeName)
    {
        if (!pipeName.StartsWith("Cloudlane.Map.", StringComparison.Ordinal) || pipeName.Length != 46) return;
        MountRequest? request = null; bool mapped = false;
        using var pipe = new NamedPipeClientStream(".", pipeName, PipeDirection.InOut, PipeOptions.Asynchronous | PipeOptions.CurrentUserOnly);
        try
        {
            await pipe.ConnectAsync(25000);
            using var reader = new StreamReader(pipe, Encoding.UTF8, false, 1024, true);
            using var writer = new StreamWriter(pipe, new UTF8Encoding(false), 1024, true) { AutoFlush = true };
            request = JsonSerializer.Deserialize<MountRequest>(await reader.ReadLineAsync() ?? "") ?? throw new IOException("Missing mapping request.");
            Validate(request);
            if (WindowsIdentity.GetCurrent().User?.Value != request.OwnerSid) throw new IOException("Approve the administrator prompt using this same Windows account.");
            mapped = true; string mapping = await ChangeAsync(request, true);
            await writer.WriteLineAsync(JsonSerializer.Serialize(new { Ok = true, Error = "", Mapping = mapping }));
            // Keep elevation only for this mapping's lifetime; disconnect on pipe/parent closure.
            await reader.ReadLineAsync();
            await ChangeAsync(request, false); mapped = false;
            await writer.WriteLineAsync(JsonSerializer.Serialize(new { Ok = true, Error = "" }));
        }
        catch (Exception ex)
        {
            try { using var writer = new StreamWriter(pipe, new UTF8Encoding(false), 1024, true) { AutoFlush = true }; await writer.WriteLineAsync(JsonSerializer.Serialize(new { Ok = false, Error = ex.Message, Diagnostics = (ex as MapperException)?.Diagnostics ?? Array.Empty<string>() })); } catch { }
        }
        finally { if (mapped && request != null) try { await ChangeAsync(request, false); } catch { } }
    }
    internal const string MapScript = """
        & {
          $ErrorActionPreference='Stop'
          $details=New-Object 'System.Collections.Generic.List[string]'
          $started=Get-Date
          $tcp=$null
          try {
            $r=[Console]::In.ReadToEnd() | ConvertFrom-Json
            $remote='\\127.0.0.1\'+$r.Share
            $tcp=New-Object System.Net.Sockets.TcpClient
            $pending=$tcp.BeginConnect('127.0.0.1',[int]$r.Port,$null,$null)
            if(-not $pending.AsyncWaitHandle.WaitOne(3000)){throw 'Elevated helper cannot reach the local SMB TCP listener.'}
            $tcp.EndConnect($pending); $tcp.Dispose(); $tcp=$null
            $details.Add('Elevated-helper TCP connection passed.')
            if(Get-SmbGlobalMapping -RemotePath $remote -ErrorAction SilentlyContinue){throw 'That local connection identity is already in use.'}
            $secure=ConvertTo-SecureString $r.Password -AsPlainText -Force
            $credential=New-Object System.Management.Automation.PSCredential(('CLOUDLANE\'+$r.User),$secure)
            $account=([System.Security.Principal.SecurityIdentifier]::new($r.OwnerSid)).Translate([System.Security.Principal.NTAccount]).Value
            New-SmbGlobalMapping -RemotePath $remote -TcpPort ([uint16]$r.Port) -TransportType TCP -Credential $credential -Persistent $false -RequireIntegrity $true -UseWriteThrough $true -FullAccess @($account) -ErrorAction Stop | Out-Null
            $mapping=Get-SmbGlobalMapping -RemotePath $remote -ErrorAction Stop
            if(-not $mapping -or [string]$mapping.Status -ne 'OK'){throw 'Windows did not retain a connected SMB mapping.'}
            @{Ok=$true; Mapping=($mapping | Select-Object Status,RemotePath | ConvertTo-Json -Compress); Diagnostics=@($details)} | ConvertTo-Json -Compress
          } catch {
            $original=$_.Exception.Message
            $details.Add('Mapper failure ID: '+$_.FullyQualifiedErrorId)
            try {
              $config=Get-SmbClientConfiguration -ErrorAction Stop
              $policy=$config | Select-Object RequireSecuritySignature,RequireEncryption,BlockNTLM,Smb2DialectMin,Smb2DialectMax
              $details.Add('SMB client policy (read only): '+($policy | ConvertTo-Json -Compress))
            } catch { $details.Add('SMB client policy query unavailable.') }
            foreach($channel in @('Connectivity','Security','Operational')) {
              try {
                $events=Get-WinEvent -FilterHashtable @{LogName=('Microsoft-Windows-SMBClient/'+$channel);StartTime=$started} -MaxEvents 4 -ErrorAction Stop
                foreach($event in $events) {
                  $xml=[xml]$event.ToXml(); $codes=@()
                  foreach($data in $xml.Event.EventData.Data) {
                    if([string]$data.Name -match '^(Status|ErrorCode|Reason|FailureCode|NTStatus|NTStatusCode)$' -and [string]$data.'#text' -match '^(0x)?[0-9a-fA-F]{1,16}$') {
                      $codes+=([string]$data.Name+'='+[string]$data.'#text')
                    }
                  }
                  $details.Add(('SMBClient/{0} event {1} {2}' -f $channel,$event.Id,($codes -join ' ')))
                }
              } catch { }
            }
            @{Ok=$false; Error=$original; Diagnostics=@($details)} | ConvertTo-Json -Compress -Depth 5
          } finally { if($tcp){$tcp.Dispose()} }
        }
        """;
    private sealed class MapperException(string message, string[] diagnostics) : IOException(message)
    { public string[] Diagnostics { get; } = diagnostics; }
    private static async Task<string> ChangeAsync(MountRequest request, bool mount)
    {
        // All values are JSON data on stdin; user input is never interpolated into PowerShell code.
        const string unmapScript = "& { $ErrorActionPreference='Stop'; $r=[Console]::In.ReadToEnd() | ConvertFrom-Json; $remote='\\\\127.0.0.1\\'+$r.Share; $m=Get-SmbGlobalMapping -RemotePath $remote -ErrorAction SilentlyContinue; if($m -and $m.RemotePath -ieq $remote){Remove-SmbGlobalMapping -RemotePath $remote -Force -Confirm:$false -ErrorAction Stop} }";
        var start = new ProcessStartInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), @"System32\WindowsPowerShell\v1.0\powershell.exe"))
        { UseShellExecute = false, CreateNoWindow = true, RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true };
        foreach (string a in new[] { "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", mount ? MapScript : unmapScript }) start.ArgumentList.Add(a);
        using var process = Process.Start(start) ?? throw new IOException("Could not start the Windows SMB mapper.");
        await process.StandardInput.WriteAsync(JsonSerializer.Serialize(request)); process.StandardInput.Close();
        var errors = process.StandardError.ReadToEndAsync(); var output = process.StandardOutput.ReadToEndAsync();
        using var limit = new CancellationTokenSource(TimeSpan.FromSeconds(45));
        try { await process.WaitForExitAsync(limit.Token); }
        catch { if (!process.HasExited) process.Kill(true); throw new IOException("Windows drive mapping timed out."); }
        string error = await errors; string result = await output;
        if (process.ExitCode != 0) throw new IOException("Windows could not " + (mount ? "map" : "disconnect") + " the drive: " + error.Trim());
        if (!mount) return result.Trim();
        using var response = JsonDocument.Parse(result);
        var value = response.RootElement;
        string[] diagnostics = value.GetProperty("Diagnostics").EnumerateArray().Select(item => item.GetString() ?? "").ToArray();
        if (!value.GetProperty("Ok").GetBoolean()) throw new MapperException("Windows could not map the drive: " + value.GetProperty("Error").GetString(), diagnostics);
        return value.GetProperty("Mapping").GetString() ?? "";
    }
}
