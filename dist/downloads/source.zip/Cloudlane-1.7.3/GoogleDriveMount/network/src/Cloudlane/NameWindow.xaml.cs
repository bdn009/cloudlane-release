using System.Linq;
using System.Windows;
namespace Cloudlane;
public partial class NameWindow : Window
{
    public string FolderName => NameInput.Text.Trim();
    public NameWindow() { InitializeComponent(); Loaded += (_, _) => NameInput.Focus(); }
    private void Create_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(FolderName) || FolderName.Any(char.IsControl))
        { MessageBox.Show(this, "Enter a folder name without control characters.", "Folder name"); return; }
        DialogResult = true;
    }
}
