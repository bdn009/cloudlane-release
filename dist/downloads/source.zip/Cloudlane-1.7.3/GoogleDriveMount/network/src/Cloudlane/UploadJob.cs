using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;
namespace Cloudlane;
public sealed class UploadJob
{
    public string Key { get; set; } = Guid.NewGuid().ToString("N");
    public string Source { get; set; } = "";
    public string Name { get; set; } = "";
    public string ParentRemoteId { get; set; } = "";
    public string ParentJobKey { get; set; } = "";
    public string Destination { get; set; } = "";
    public bool IsFolder { get; set; }
    public string RemoteId { get; set; } = "";
    public string Session { get; set; } = "";
    public long SourceSize { get; set; } = -1;
    public long SourceTicks { get; set; }
    public long ConfirmedBytes { get; set; }
    public bool Complete { get; set; }
    public string State { get; set; } = "Queued";
    public string Error { get; set; } = "";
    public string ProgressText => Complete ? "Complete" : IsFolder ? "Folder" : SourceSize < 0 ? "Ready" : $"{ConfirmedBytes / 1048576d:F1} / {SourceSize / 1048576d:F1} MB";
    public string DisplaySource => Source;
}
public sealed record UploadProgress(string Name, long Confirmed, long Total, string State);
public sealed class UploadQueue
{
    public List<UploadJob> Jobs { get; } = new();
    public static UploadQueue Load(Settings settings)
    {
        var queue = new UploadQueue();
        if (File.Exists(settings.QueuePath))
        {
            var list = JsonSerializer.Deserialize<List<UploadJob>>(SecretStore.Read(settings.QueuePath)) ?? throw new IOException("The upload queue could not be read. Your original files are unchanged.");
            if (list.Any(j => string.IsNullOrWhiteSpace(j.Source) || !Path.IsPathFullyQualified(j.Source))) throw new IOException("An upload queue source path is invalid.");
            foreach (var job in list) { if (!job.Complete) job.State = "Paused"; queue.Jobs.Add(job); }
        }
        return queue;
    }
    public void Save(Settings settings)
    { Directory.CreateDirectory(settings.AccountDir); SecretStore.Write(settings.QueuePath, JsonSerializer.Serialize(Jobs)); }
    public void ClearCompleted()
    {
        foreach (var child in Jobs.Where(j => !j.Complete && j.ParentJobKey.Length > 0))
        {
            var parent = Jobs.FirstOrDefault(p => p.Key == child.ParentJobKey);
            if (parent?.Complete == true) { child.ParentRemoteId = parent.RemoteId; child.ParentJobKey = ""; }
        }
        Jobs.RemoveAll(j => j.Complete);
    }
    public static List<UploadJob> Plan(IEnumerable<string> sources, string parentId, string destination, CancellationToken cancellation = default)
    {
        var jobs = new List<UploadJob>();
        var roots = sources.Select(Path.GetFullPath).Select(Path.TrimEndingDirectorySeparator).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        roots = roots.Where(p => !roots.Any(other => !string.Equals(p, other, StringComparison.OrdinalIgnoreCase) && p.StartsWith(other.TrimEnd('\\') + "\\", StringComparison.OrdinalIgnoreCase))).ToList();
        void Add(string path, string parentKey, string remoteParent, string dest, int depth)
        {
            cancellation.ThrowIfCancellationRequested();
            if (depth > 256) throw new IOException("The selected folder has too many nested levels. Select a folder nearer to the files.");
            string full = Path.GetFullPath(path);
            if (string.Equals(full.TrimEnd('\\'), Path.GetPathRoot(full)?.TrimEnd('\\'), StringComparison.OrdinalIgnoreCase)) throw new IOException("Select a folder inside the disk, rather than a whole drive.");
            var attributes = File.GetAttributes(full);
            if ((attributes & FileAttributes.ReparsePoint) != 0) throw new IOException("Links and junctions are skipped to avoid uploading files outside the selected folder: " + full);
            bool folder = (attributes & FileAttributes.Directory) != 0;
            var job = new UploadJob { Source = full, Name = Path.GetFileName(full.TrimEnd('\\')), IsFolder = folder, ParentRemoteId = remoteParent, ParentJobKey = parentKey, Destination = dest };
            if (!folder) { var info = new FileInfo(full); job.SourceSize = info.Length; job.SourceTicks = info.LastWriteTimeUtc.Ticks; }
            if (job.Name.Length == 0) throw new IOException("Select a folder inside the disk, rather than a whole drive.");
            jobs.Add(job);
            if (folder)
                foreach (var child in Directory.EnumerateFileSystemEntries(full).OrderBy(p => p, StringComparer.OrdinalIgnoreCase)) Add(child, job.Key, "", dest.TrimEnd('/') + "/" + job.Name, depth + 1);
        }
        foreach (string source in roots) Add(source, "", parentId, destination, 0);
        return jobs;
    }
}
