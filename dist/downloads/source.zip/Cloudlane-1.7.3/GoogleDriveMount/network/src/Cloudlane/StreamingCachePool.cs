using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Cloudlane.Mount;
namespace Cloudlane;

internal static class StreamingCachePool
{
    private sealed class Entry(MediaBlockCache cache) { internal readonly MediaBlockCache Cache = cache; internal int Users; }
    private static readonly SemaphoreSlim gate = new(1, 1);
    private static readonly Dictionary<string, Entry> entries = new(StringComparer.OrdinalIgnoreCase);
    internal sealed class Lease(MediaBlockCache cache, Func<ValueTask> release) : IAsyncDisposable
    {
        internal MediaBlockCache Cache => cache;
        public ValueTask DisposeAsync() => release();
    }
    internal static async Task<Lease> AcquireAsync(string folder, CancellationToken ct, Action<string>? secure = null)
    {
        folder = Path.GetFullPath(folder).TrimEnd(Path.DirectorySeparatorChar);
        await gate.WaitAsync(ct);
        try
        {
            if (!entries.TryGetValue(folder, out var entry))
            {
                entry = new Entry(new MediaBlockCache(folder, CancellationToken.None, secureDirectory: secure));
                entries.Add(folder, entry);
            }
            entry.Users++; bool released = false;
            return new Lease(entry.Cache, async () =>
            {
                await gate.WaitAsync();
                try
                {
                    if (released) return; released = true;
                    if (--entry.Users == 0)
                    {
                        try { await entry.Cache.DisposeAsync(); }
                        finally { entries.Remove(folder); }
                    }
                }
                finally { gate.Release(); }
            });
        }
        finally { gate.Release(); }
    }
}
