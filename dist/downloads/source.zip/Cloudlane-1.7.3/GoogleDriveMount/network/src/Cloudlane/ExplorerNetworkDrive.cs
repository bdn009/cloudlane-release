using System;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
namespace Cloudlane;
// WNet registers a network drive with Windows' network provider as well as
// creating its DOS letter. A bare DefineDosDevice alias is insufficient here.
internal sealed class ExplorerNetworkDrive : IDisposable
{
    internal interface IApi
    {
        bool LetterOccupied(string letter);
        int Add(string letter, string remote);
        string? Remote(string letter);
        int Remove(string letter);
    }
    private readonly IApi api;
    private readonly string letter, remote;
    private bool removed;
    public ExplorerNetworkDrive(string letter, string share) : this(letter, share, new WindowsApi()) { }
    internal ExplorerNetworkDrive(string letter, string share, IApi api)
    {
        if (letter.Length != 2 || letter[0] < 'D' || letter[0] > 'Z' || letter[1] != ':') throw new IOException("Invalid drive letter.");
        ExplorerDriveAlias.MakeTarget(share); // Only the app's exact local share identity is allowed.
        this.api = api; this.letter = letter; remote = LocalSmbEndpoint.Remote(share);
        if (api.LetterOccupied(letter)) throw new IOException("That drive letter is already used. Choose another letter.");
        int error = api.Add(letter, remote);
        if (error != 0) throw new Win32Exception(error, $"Windows could not register the Explorer network drive (error {error}: {new Win32Exception(error).Message}).");
        if (!Matches(api.Remote(letter), remote)) throw new IOException("Windows did not register the requested Explorer network drive.");
    }
    private static bool Matches(string? actual, string expected) => string.Equals(actual?.TrimEnd('\\'), expected, StringComparison.OrdinalIgnoreCase);
    public bool Registered => !removed && Matches(api.Remote(letter), remote);
    public void Dispose()
    {
        if (removed) return;
        // Never cancel a drive that has been replaced by another application.
        if (!Matches(api.Remote(letter), remote)) { removed = true; return; }
        int error = api.Remove(letter);
        if (error != 0 && error != 2250) throw new Win32Exception(error, $"Windows could not disconnect the Explorer network drive (error {error}: {new Win32Exception(error).Message}).");
        removed = true;
    }
    public static string? RegisteredRemote(string letter) => new WindowsApi().Remote(letter);
    private sealed class WindowsApi : IApi
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct NetResource
        {
            public uint Scope, Type, DisplayType, Usage;
            public string? LocalName, RemoteName, Comment, Provider;
        }
        [DllImport("mpr.dll", CharSet = CharSet.Unicode)] private static extern int WNetAddConnection2(ref NetResource resource, string? password, string? userName, uint flags);
        [DllImport("mpr.dll", CharSet = CharSet.Unicode)] private static extern int WNetGetConnection(string localName, StringBuilder remoteName, ref int length);
        [DllImport("mpr.dll", CharSet = CharSet.Unicode)] private static extern int WNetCancelConnection2(string name, uint flags, [MarshalAs(UnmanagedType.Bool)] bool force);
        public bool LetterOccupied(string letter) => ExplorerMount.LetterInUse(letter) || Remote(letter) != null;
        public int Add(string letter, string remote)
        {
            var resource = new NetResource { Type = 1, LocalName = letter, RemoteName = remote };
            // Reuse the authenticated global connection. No saved profile or credential.
            return WNetAddConnection2(ref resource, null, null, 4); // CONNECT_TEMPORARY
        }
        public string? Remote(string letter)
        {
            var result = new StringBuilder(32768); int length = result.Capacity;
            int error = WNetGetConnection(letter, result, ref length);
            return error == 0 || error == 1201 ? result.ToString() : null; // Includes remembered, disconnected mappings.
        }
        public int Remove(string letter) => WNetCancelConnection2(letter, 0, true);
    }
}
