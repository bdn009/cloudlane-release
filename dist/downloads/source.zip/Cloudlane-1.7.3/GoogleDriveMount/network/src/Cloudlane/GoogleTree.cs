using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;
using System.Text.Json;
using System.Threading.Tasks;
using Cloudlane.Mount;
namespace Cloudlane;
public sealed class GoogleTree : IWritableCloudTree
{
    private readonly GoogleDriveApi drive;
    private readonly CancellationToken lifetime;
    private readonly object gate = new();
    private readonly Dictionary<string, (DateTime Expires, List<CloudNode> Nodes)> cache = new();
    private readonly Dictionary<string, StreamingCloudUpload> uploads = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, (CloudNode Node, DateTime Until)> recentUploads = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, DateTime> recentlyTrashed = new();
    private readonly CloudNode root;
    private CloudCapacity capacity;
    private readonly MediaBlockCache? streamingCache;
    private readonly string cacheAccount;
    public CloudCapacity Capacity => Volatile.Read(ref capacity);
    public long TotalBytes => Capacity.TotalBytes;
    public long FreeBytes => Capacity.FreeBytes;
    public string VolumeLabel { get; }
    public bool IsCloudOnly(CloudNode file) => !file.Directory && file.Inline == null;
    public GoogleTree(GoogleDriveApi drive, DriveFile rootFile, long total, long free, CancellationToken lifetime, string label = "Google Drive - Cloudlane", MediaBlockCache? streamingCache = null, string cacheAccount = "")
    { this.drive = drive; this.lifetime = lifetime; this.streamingCache = streamingCache; this.cacheAccount = cacheAccount; capacity = new(total, free); VolumeLabel = label; root = new("\\", "", rootFile.Id, true, 0, rootFile.Modified.UtcDateTime, rootFile.Version); }
    public void UpdateCapacity(CloudCapacity value) => Volatile.Write(ref capacity, value);
    private long readBlocks, readBytes, readMilliseconds;
    public string ReadDiagnostics => $"Google read blocks={Interlocked.Read(ref readBlocks)}; bytes={Interlocked.Read(ref readBytes)}; total fetch/validation ms={Interlocked.Read(ref readMilliseconds)}; " +
        (streamingCache == null ? "RAM mode: 1 MiB per open reader, at most 16 retained windows." : "Media cache: brief probes use RAM; sustained reads activate caching. Video-only read-ahead up to 256 MiB; shared disk capacity 2 GiB.");
    private static readonly HashSet<string> MediaTypes = new(StringComparer.OrdinalIgnoreCase)
    { ".mp4", ".mkv", ".avi", ".mov", ".webm", ".m4v", ".wmv", ".flv", ".ts", ".m2ts", ".mpg", ".mpeg", ".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".tif", ".tiff", ".heic", ".avif", ".ico" };
    public ICloudReadSession? OpenRead(CloudNode file)
    {
        if (file.Inline != null) return null;
        if (streamingCache != null && (MediaTypes.Contains(Path.GetExtension(file.Name)) || file.MimeType.StartsWith("video/", StringComparison.OrdinalIgnoreCase) || file.MimeType.StartsWith("image/", StringComparison.OrdinalIgnoreCase)))
        {
            string identity = JsonSerializer.Serialize(new[] { cacheAccount, file.Id, file.Version, file.Size.ToString(System.Globalization.CultureInfo.InvariantCulture) });
            return new CachedMediaReader(streamingCache, identity, file.Size, async ct =>
            {
                using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct); timeout.CancelAfter(TimeSpan.FromSeconds(30));
                VerifyVersion(file, await drive.GetAsync(file.Id, timeout.Token).ConfigureAwait(false));
            }, async (offset, count, ct) =>
            {
                using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct); timeout.CancelAfter(TimeSpan.FromMinutes(3));
                var watch = Stopwatch.StartNew();
                var current = await drive.GetAsync(file.Id, timeout.Token).ConfigureAwait(false); VerifyVersion(file, current);
                var bytes = await drive.ReadCacheRangeAsync(current, offset, count, timeout.Token).ConfigureAwait(false);
                VerifyVersion(file, await drive.GetAsync(file.Id, timeout.Token).ConfigureAwait(false));
                Interlocked.Increment(ref readBlocks); Interlocked.Add(ref readBytes, bytes.Length); Interlocked.Add(ref readMilliseconds, watch.ElapsedMilliseconds);
                return bytes;
            }, lifetime, IsVideo(file));
        }
        return new CloudReadBuffer(file.Size, (offset, count, ct) =>
    {
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct); timeout.CancelAfter(TimeSpan.FromSeconds(60));
        var watch = Stopwatch.StartNew();
        var current = drive.GetAsync(file.Id, timeout.Token).GetAwaiter().GetResult(); VerifyVersion(file, current);
        var bytes = drive.ReadRangeAsync(current, offset, count, timeout.Token).GetAwaiter().GetResult();
        // Never combine a response with bytes from a different cloud version.
        VerifyVersion(file, drive.GetAsync(file.Id, timeout.Token).GetAwaiter().GetResult());
        Interlocked.Increment(ref readBlocks); Interlocked.Add(ref readBytes, bytes.Length); Interlocked.Add(ref readMilliseconds, watch.ElapsedMilliseconds);
        return bytes;
    }, lifetime);
    }
    private static void VerifyVersion(CloudNode opened, DriveFile current)
    {
        if (!current.CanDownload) throw new UnauthorizedAccessException("This Google account is not allowed to download this file.");
        if (current.Size != opened.Size || current.Version != opened.Version) throw new IOException("This Google Drive file changed while it was open. Close and reopen it.");
    }
    private static bool IsVideo(CloudNode file) => file.MimeType.StartsWith("video/", StringComparison.OrdinalIgnoreCase) ||
        new[] { ".mp4", ".mkv", ".avi", ".mov", ".webm", ".m4v", ".wmv", ".flv", ".ts", ".m2ts", ".mpg", ".mpeg" }.Contains(Path.GetExtension(file.Name), StringComparer.OrdinalIgnoreCase);
    public static string Normalize(string path)
    {
        var parts = new List<string>();
        foreach (string part in path.Replace('/', '\\').Split('\\', StringSplitOptions.RemoveEmptyEntries))
        {
            if (part == ".") continue;
            if (part == "..") { if (parts.Count == 0) throw new FileNotFoundException("Path is outside My Drive."); parts.RemoveAt(parts.Count - 1); }
            else { if (part.Contains(':') || part.Any(char.IsControl)) throw new FileNotFoundException(); parts.Add(part); }
        }
        return "\\" + string.Join("\\", parts);
    }
    public CloudNode Resolve(string path)
    {
        lock (gate)
        {
            var current = root;
            foreach (string part in Normalize(path).Split('\\', StringSplitOptions.RemoveEmptyEntries))
            {
                if (!current.Directory) throw new DirectoryNotFoundException();
                current = Children(current).FirstOrDefault(n => n.Name.Equals(part, StringComparison.OrdinalIgnoreCase)) ?? throw new FileNotFoundException("This item is no longer in My Drive. Refresh and try again.");
            }
            return current;
        }
    }
    public IReadOnlyList<CloudNode> Children(CloudNode directory)
    {
        lock (gate)
        {
            lifetime.ThrowIfCancellationRequested();
            if (cache.TryGetValue(directory.Id, out var found) && found.Expires > DateTime.UtcNow) return Overlay(directory, found.Nodes);
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(lifetime); timeout.CancelAfter(TimeSpan.FromSeconds(60));
            var files = drive.ListFolderAsync(directory.Id, timeout.Token).GetAwaiter().GetResult();
            var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var nodes = new List<CloudNode>();
            foreach (var file in files.OrderBy(f => f.Id, StringComparer.Ordinal))
            {
                string name = Paths.SafeName(file.Name) + (file.IsLink ? ".url" : "");
                if (!used.Add(name)) { name = Paths.CollisionName(name, file.Id); int suffix = 2; while (!used.Add(name)) name = Paths.CollisionName(Paths.SafeName(file.Name) + "~" + suffix++, file.Id) + (file.IsLink ? ".url" : ""); }
                byte[]? inline = file.IsLink ? Encoding.UTF8.GetBytes("[InternetShortcut]\r\nURL=https://drive.google.com/open?id=" + Uri.EscapeDataString(file.Id) + "\r\n") : null;
                nodes.Add(new(directory.Path.TrimEnd('\\') + "\\" + name, name, file.Id, file.IsDirectory, inline?.LongLength ?? file.Size, file.Modified.UtcDateTime, file.Version, inline, file.MimeType));
            }
            if (cache.Count >= 128) cache.Remove(cache.OrderBy(c => c.Value.Expires).First().Key);
            cache[directory.Id] = (DateTime.UtcNow.AddSeconds(10), nodes);
            return Overlay(directory, nodes);
        }
    }
    public void Refresh() { lock (gate) cache.Clear(); }
    private List<CloudNode> Overlay(CloudNode parent, List<CloudNode> nodes)
    {
        var result = nodes.ToDictionary(n => n.Name, StringComparer.OrdinalIgnoreCase);
        foreach (var recent in recentUploads.Values.Where(x => x.Until > DateTime.UtcNow))
            if (ParentPath(recent.Node.Path).Equals(parent.Path, StringComparison.OrdinalIgnoreCase)) result[recent.Node.Name] = recent.Node;
        foreach (var upload in uploads.Values)
        {
            var node = upload.Node;
            if (ParentPath(node.Path).Equals(parent.Path, StringComparison.OrdinalIgnoreCase)) result[node.Name] = node;
        }
        foreach (var id in recentlyTrashed.Where(x => x.Value <= DateTime.UtcNow).Select(x => x.Key).ToArray()) recentlyTrashed.Remove(id);
        return result.Values.Where(n => !recentlyTrashed.ContainsKey(n.Id)).OrderByDescending(n => n.Directory).ThenBy(n => n.Name, StringComparer.OrdinalIgnoreCase).ToList();
    }
    private static string ParentPath(string path) { int slash = path.LastIndexOf('\\'); return slash <= 0 ? "\\" : path[..slash]; }
    public StreamingCloudUpload? PendingUpload(string path)
    { lock (gate) return uploads.GetValueOrDefault(Normalize(path)); }
    public StreamingCloudUpload BeginUpload(string path, CloudNode? replaced)
    {
        lock (gate)
        {
            path = Normalize(path);
            if (path == "\\" || uploads.ContainsKey(path)) throw new IOException("Another upload is already writing that destination.");
            if (uploads.Count >= 8) throw new IOException("Eight Explorer uploads are active. Finish those copies before starting more.");
            var parent = Resolve(ParentPath(path));
            if (!parent.Directory) throw new DirectoryNotFoundException();
            string name = path[(path.LastIndexOf('\\') + 1)..];
            if (replaced?.Directory == true || replaced?.Inline != null) throw new NotSupportedException("Google documents and folders cannot be overwritten with file contents.");
            string id = replaced?.Id ?? drive.GenerateIdAsync(lifetime).GetAwaiter().GetResult();
            var node = new CloudNode(path, name, id, false, 0, DateTime.UtcNow);
            var upload = new StreamingCloudUpload(node, new GoogleUploadSink(drive, node, parent.Id, replaced != null, lifetime),
                current => { lock (gate) { if (recentUploads.ContainsKey(path)) recentUploads[path] = (current.Node, DateTime.UtcNow.AddSeconds(10)); } },
                current => { lock (gate) { if (current.Aborted) { if (uploads.TryGetValue(path, out var owned) && ReferenceEquals(owned, current)) uploads.Remove(path); recentUploads.Remove(path); } cache.Clear(); } }, replaced == null);
            uploads.Add(path, upload); return upload;
        }
    }
    public CloudNode CreateDirectory(string path)
    {
        lock (gate)
        {
            path = Normalize(path); var parent = Resolve(ParentPath(path));
            if (!parent.Directory) throw new DirectoryNotFoundException();
            string name = path[(path.LastIndexOf('\\') + 1)..];
            var file = drive.FolderAsync(drive.GenerateIdAsync(lifetime).GetAwaiter().GetResult(), name, parent.Id, lifetime).GetAwaiter().GetResult();
            cache.Clear(); return new(path, name, file.Id, true, 0, file.Modified.UtcDateTime, file.Version);
        }
    }
    public CloudNode SetModified(CloudNode node, DateTime modified)
    {
        var file = drive.SetModifiedAsync(node.Id, modified, lifetime).GetAwaiter().GetResult();
        var updated = node with { Modified = file.Modified.UtcDateTime, Version = file.Version };
        lock (gate) { if (recentUploads.ContainsKey(node.Path)) recentUploads[node.Path] = (updated, DateTime.UtcNow.AddSeconds(10)); cache.Clear(); }
        return updated;
    }
    public void ReleaseUpload(StreamingCloudUpload upload)
    {
        lock (gate)
        {
            if (uploads.TryGetValue(upload.Node.Path, out var owned) && ReferenceEquals(owned, upload)) uploads.Remove(upload.Node.Path);
            if (upload.Completed && !upload.Aborted && !recentlyTrashed.ContainsKey(upload.Node.Id))
            {
                if (recentUploads.Count >= 128) recentUploads.Remove(recentUploads.OrderBy(x => x.Value.Until).First().Key);
                recentUploads[upload.Node.Path] = (upload.Node, DateTime.UtcNow.AddSeconds(10));
            }
            cache.Clear();
        }
    }
    public void AbortUploads()
    {
        StreamingCloudUpload[] pending; lock (gate) pending = uploads.Values.ToArray();
        foreach (var upload in pending) try { upload.Abort(); } catch { }
    }
    public void SetTrashed(CloudNode node, bool trashed)
    {
        if (node.Id == root.Id || Normalize(node.Path) == "\\") throw new UnauthorizedAccessException("The Google Drive root cannot be deleted.");
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(lifetime); timeout.CancelAfter(TimeSpan.FromSeconds(60));
        drive.SetTrashedAsync(node.Id, trashed, timeout.Token).GetAwaiter().GetResult();
        lock (gate)
        {
            if (trashed)
            {
                if (recentlyTrashed.Count >= 1024) recentlyTrashed.Remove(recentlyTrashed.OrderBy(x => x.Value).First().Key);
                recentlyTrashed[node.Id] = DateTime.UtcNow.AddSeconds(60);
                foreach (var path in recentUploads.Where(x => x.Value.Node.Id == node.Id).Select(x => x.Key).ToArray()) recentUploads.Remove(path);
            }
            else recentlyTrashed.Remove(node.Id);
            cache.Clear();
        }
    }
    public byte[] Read(CloudNode file, long offset, int count)
    {
        if (file.Inline != null) return file.Inline.AsSpan((int)offset, Math.Min(count, file.Inline.Length - (int)offset)).ToArray();
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(lifetime); timeout.CancelAfter(TimeSpan.FromSeconds(60));
        var current = drive.GetAsync(file.Id, timeout.Token).GetAwaiter().GetResult();
        VerifyVersion(file, current);
        return drive.ReadRangeAsync(current, offset, count, timeout.Token).GetAwaiter().GetResult();
    }
}
