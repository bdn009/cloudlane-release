using System;
using System.Drawing;
using System.Windows.Forms;
namespace Cloudlane;

public sealed class TrayIcon : IDisposable
{
    private readonly NotifyIcon icon;
    private readonly Icon image;
    private readonly ContextMenuStrip menu;
    private readonly ToolStripMenuItem open;
    private readonly ToolStripMenuItem connect;
    private readonly ToolStripMenuItem disconnect;
    private readonly ToolStripMenuItem exit;
    public TrayIcon(Action show, Action openDrive, Action connectDrive, Action disconnectDrive, Action quit)
    {
        image = Icon.ExtractAssociatedIcon(Environment.ProcessPath!) ?? (Icon)SystemIcons.Application.Clone();
        menu = new ContextMenuStrip();
        menu.Items.Add("Show Cloudlane", null, (_, _) => show());
        menu.Items.Add(new ToolStripSeparator());
        open = new ToolStripMenuItem("Open selected drive in Explorer", null, (_, _) => openDrive());
        connect = new ToolStripMenuItem("Connect selected drive…", null, (_, _) => connectDrive());
        disconnect = new ToolStripMenuItem("Disconnect selected drive", null, (_, _) => disconnectDrive());
        exit = new ToolStripMenuItem("Exit (disconnect all drives)", null, (_, _) => quit());
        menu.Items.AddRange(new ToolStripItem[] { open, connect, disconnect, new ToolStripSeparator(), exit });
        icon = new NotifyIcon { Icon = image, Text = "Cloudlane", ContextMenuStrip = menu, Visible = true };
        icon.DoubleClick += (_, _) => show();
    }
    public void Update(bool mounted, bool canConnect, bool busy, bool exiting, string letter, int connectedCount = 0)
    {
        open.Enabled = mounted && !exiting; connect.Enabled = canConnect && !exiting;
        disconnect.Enabled = mounted && !busy && !exiting; exit.Enabled = !exiting;
        icon.Text = exiting ? "Cloudlane · Disconnecting…" : connectedCount > 0 ? "Cloudlane · " + connectedCount + " drive(s) connected" : mounted ? "Cloudlane · " + letter + " connected" : "Cloudlane · Drives disconnected";
    }
    public void ExplainHidden()
    {
        icon.BalloonTipTitle = "Cloudlane is still running";
        icon.BalloonTipText = "Your drive and uploads stay active. Right-click the Cloudlane tray icon to show the window or exit.";
        icon.ShowBalloonTip(5000);
    }
    public void Dispose() { icon.Visible = false; icon.Dispose(); menu.Dispose(); image.Dispose(); }
}
