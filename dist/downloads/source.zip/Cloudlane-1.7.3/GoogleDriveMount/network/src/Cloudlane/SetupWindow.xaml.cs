using System;
using System.Diagnostics;
using System.IO;
using System.Windows;
namespace Cloudlane;
public partial class SetupWindow : Window
{
    private readonly Settings settings;
    public SetupWindow(Settings settings)
    {
        InitializeComponent(); this.settings = settings;
        SetupStatus.Text = settings.HasClient ? "A Desktop client is already configured. You can replace it when no accounts are saved." : "No Google app registration has been configured yet.";
    }
    private void Import_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (settings.Accounts.Count > 0) throw new InvalidOperationException("Disconnect and forget all saved accounts before replacing your Google app registration.");
            var picker = new Microsoft.Win32.OpenFileDialog { Filter = "Google Desktop OAuth JSON|*.json", Title = "Choose your Google Desktop app client" };
            if (picker.ShowDialog(this) != true) return;
            if (new FileInfo(picker.FileName).Length > 64 * 1024) throw new InvalidOperationException("The client JSON is unexpectedly large. Choose the Desktop client downloaded from Google Cloud.");
            settings.SaveClient(File.ReadAllText(picker.FileName));
            SetupStatus.Text = "Google app configured. Click Done, then Add Google account.";
        }
        catch (Exception ex) { SetupStatus.Text = ex.Message; }
    }
    private static void Open(string target)
    { try { Process.Start(new ProcessStartInfo(target) { UseShellExecute = true }); } catch (Exception ex) { MessageBox.Show(ex.Message, "Could not open browser"); } }
    private void Cloud_Click(object sender, RoutedEventArgs e) => Open("https://console.cloud.google.com/auth/clients");
    private void Guide_Click(object sender, RoutedEventArgs e) => Open(Path.Combine(AppContext.BaseDirectory, "README.html"));
    private void Done_Click(object sender, RoutedEventArgs e) => Close();
}
