using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.Json;
using Microsoft.Win32;
namespace Cloudlane;

internal sealed record ShellText(string Text, RegistryValueKind Kind = RegistryValueKind.String);
internal interface IShellSettings
{
    ShellText? Read(string path, string name);
    void Write(string path, string name, ShellText value);
    void Remove(string path, string name);
}
internal sealed class UserShellSettings : IShellSettings
{
    public ShellText? Read(string path, string name)
    {
        using var key = Registry.CurrentUser.OpenSubKey(path);
        object? value = key?.GetValue(name, null, RegistryValueOptions.DoNotExpandEnvironmentNames);
        if (value == null) return null;
        if (value is not string text) throw new IOException("An existing Explorer appearance value has an unsupported format; it was left unchanged.");
        return new(text, key!.GetValueKind(name));
    }
    public void Write(string path, string name, ShellText value)
    { using var key = Registry.CurrentUser.CreateSubKey(path, true); key.SetValue(name, value.Text, value.Kind); }
    public void Remove(string path, string name)
    { using var key = Registry.CurrentUser.OpenSubKey(path, true); key?.DeleteValue(name, false); }
}

// Per-user shell decoration only. The mapped drive retains its network type.
internal sealed class ExplorerAppearance : IDisposable
{
    internal sealed record Change(string Path, string Name, ShellText? Before, ShellText After);
    internal sealed record Journal(string Letter, string Share, List<Change> Changes, string Owner);
    private const string Explorer = @"Software\Microsoft\Windows\CurrentVersion\Explorer\";
    private readonly IShellSettings registry;
    private readonly string journalPath;
    private readonly Action<string> notify;
    private readonly string owner = Guid.NewGuid().ToString("N");
    private bool disposed;
    internal static string NormalizeCustomLabel(string? value)
    {
        string label = new string((value ?? "").Where(c => !char.IsControl(c)).ToArray()).Trim();
        if (label.Length <= 96) return label;
        return label[..(char.IsHighSurrogate(label[95]) ? 95 : 96)];
    }
    internal static string Label(string? displayName, string? email, string? customName = null)
    {
        string custom = NormalizeCustomLabel(customName);
        if (custom.Length > 0) return custom;
        string account = string.IsNullOrWhiteSpace(displayName) ? email ?? "" : displayName;
        account = new string(account.Where(c => !char.IsControl(c)).ToArray()).Trim();
        string label = account.Length == 0 ? "Google Drive" : "Google Drive - " + account;
        if (label.Length <= 96) return label;
        return label[..(char.IsHighSurrogate(label[95]) ? 95 : 96)];
    }
    internal static string[] Paths(string letter, string share)
    {
        if (letter.Length != 2 || letter[0] < 'D' || letter[0] > 'Z' || letter[1] != ':') throw new IOException("Invalid appearance drive letter.");
        ExplorerDriveAlias.MakeTarget(share);
        string point = Explorer + @"MountPoints2\" + LocalSmbEndpoint.Remote(share).Replace('\\', '#');
        return new[] { point, Explorer + @"DriveIcons\" + letter[0] + @"\DefaultIcon", Explorer + @"DriveIcons\" + letter[0] + @"\DefaultLabel" };
    }
    public ExplorerAppearance(string letter, string share, string label, string icon, string journalPath)
        : this(letter, share, label, icon, journalPath, new UserShellSettings(), Notify) { }
    internal ExplorerAppearance(string letter, string share, string label, string icon, string journalPath, IShellSettings registry, Action<string> notify)
    {
        this.registry = registry; this.journalPath = journalPath; this.notify = notify;
        if (File.Exists(journalPath)) throw new IOException("An older Explorer appearance change still needs cleanup. Restart Cloudlane before reconnecting.");
        if (!Path.IsPathFullyQualified(icon) || icon.Contains('"') || !File.Exists(icon)) throw new IOException("The Google Drive icon is missing. Extract every update file, including Assets.");
        string[] paths = Paths(letter, share); string iconValue = "\"" + icon + "\",0";
        var changes = new List<Change>();
        void Add(string path, string name, string after) => changes.Add(new(path, name, registry.Read(path, name), new(after)));
        Add(paths[0], "_LabelFromReg", label); Add(paths[0], "_IconFromReg", iconValue);
        Add(paths[1], "", iconValue); Add(paths[2], "", label);
        Settings.AtomicWrite(journalPath, JsonSerializer.Serialize(new Journal(letter, share, changes, owner)));
        try { foreach (var change in changes) registry.Write(change.Path, change.Name, change.After); notify(letter); }
        catch { try { Restore(journalPath, registry, notify); } catch { } throw; }
    }
    public void Dispose()
    {
        if (disposed) return;
        Restore(journalPath, registry, notify, owner); disposed = true;
    }
    public static void Restore(string journalPath) => Restore(journalPath, new UserShellSettings(), Notify);
    internal static void RestoreAll()
    {
        var journals = new List<string> { ExplorerMount.AppearanceJournal };
        string accounts = Path.Combine(Settings.DataDir, "accounts");
        if (Directory.Exists(accounts))
            journals.AddRange(Directory.EnumerateDirectories(accounts).Where(p => Settings.ValidAccountId(Path.GetFileName(p))).Select(p => Path.Combine(p, "explorer-appearance.json")));
        var errors = new List<Exception>();
        foreach (var journal in journals) try { Restore(journal); } catch (Exception ex) { errors.Add(ex); }
        if (errors.Count > 0) throw new AggregateException("Previous drive appearance cleanup needs attention.", errors);
    }
    internal static void Restore(string journalPath, IShellSettings registry, Action<string> notify, string? owner = null)
    {
        if (!File.Exists(journalPath)) return;
        var saved = JsonSerializer.Deserialize<Journal>(File.ReadAllText(journalPath)) ?? throw new IOException("Invalid Explorer appearance recovery file.");
        if (owner != null && owner != saved.Owner) return;
        string[] allowed = Paths(saved.Letter, saved.Share);
        if (saved.Changes.Count != 4 || saved.Changes.Select(c => (c.Path, c.Name)).Distinct().Count() != 4 ||
            saved.Changes.Any(c => !(c.Path == allowed[0] && (c.Name == "_LabelFromReg" || c.Name == "_IconFromReg") ||
                (c.Path == allowed[1] || c.Path == allowed[2]) && c.Name == ""))) throw new IOException("Invalid Explorer appearance recovery paths.");
        foreach (var change in saved.Changes)
        {
            // Preserve a label/icon changed by the user or another application while mounted.
            if (registry.Read(change.Path, change.Name) != change.After) continue;
            if (change.Before == null) registry.Remove(change.Path, change.Name);
            else registry.Write(change.Path, change.Name, change.Before);
        }
        File.Delete(journalPath); notify(saved.Letter);
    }
    [DllImport("shell32.dll")] private static extern void SHChangeNotify(uint change, uint flags, IntPtr item1, IntPtr item2);
    [DllImport("shell32.dll", CharSet = CharSet.Unicode, EntryPoint = "SHChangeNotify")]
    private static extern void SHChangeNotifyPath(uint change, uint flags, string item1, IntPtr item2);
    public static void Notify(string letter)
    {
        SHChangeNotify(0x08000000, 0, IntPtr.Zero, IntPtr.Zero);
        NotifySpace(letter);
    }
    public static void NotifySpace(string letter) => SHChangeNotifyPath(0x00002000, 0x00002005, letter + "\\", IntPtr.Zero);
}
