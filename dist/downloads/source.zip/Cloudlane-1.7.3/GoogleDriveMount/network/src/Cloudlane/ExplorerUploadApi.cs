using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Cloudlane.Mount;
namespace Cloudlane;
public sealed partial class GoogleDriveApi
{
    internal async Task<string> BeginExplorerSessionAsync(CloudNode node, string parentId, bool replace, long? length, CancellationToken ct)
    {
        string url = "https://www.googleapis.com/upload/drive/v3/files" + (replace ? "/" + Uri.EscapeDataString(node.Id) : "") + "?uploadType=resumable&fields=" + Uri.EscapeDataString(Fields);
        using var response = await SendAsync(() =>
        {
            object metadata = replace ? new { } : new { id = node.Id, name = node.Name, parents = new[] { parentId } };
            var request = new HttpRequestMessage(replace ? HttpMethod.Patch : HttpMethod.Post, url)
            { Content = new StringContent(JsonSerializer.Serialize(metadata), Encoding.UTF8, "application/json") };
            request.Headers.Add("X-Upload-Content-Type", "application/octet-stream");
            if (length.HasValue) request.Headers.Add("X-Upload-Content-Length", length.Value.ToString());
            return request;
        }, ct);
        string session = response.Headers.Location?.AbsoluteUri ?? throw new IOException("Google did not return an Explorer upload session.");
        if (!Uri.TryCreate(session, UriKind.Absolute, out var uri) || uri.Scheme != "https" || uri.Host != "www.googleapis.com") throw new IOException("Untrusted Google upload session.");
        return session;
    }
    internal Task<HttpResponseMessage> ExplorerRangeAsync(string session, byte[] buffer, int index, int count, long offset, long? total, CancellationToken ct) => SendAsync(() =>
    {
        var request = new HttpRequestMessage(HttpMethod.Put, session) { Content = new ByteArrayContent(buffer, index, count) };
        request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
        string range = count == 0 ? "bytes */" + (total?.ToString() ?? "*") : $"bytes {offset}-{offset + count - 1}/" + (total?.ToString() ?? "*");
        request.Content.Headers.TryAddWithoutValidation("Content-Range", range); return request;
    }, ct, true, false);
    internal Task<HttpResponseMessage> ExplorerQueryAsync(string session, long? total, CancellationToken ct) => ExplorerRangeAsync(session, Array.Empty<byte>(), 0, 0, 0, total, ct);
    internal async Task<DriveFile> SetModifiedAsync(string id, DateTime modified, CancellationToken ct) => DriveFile.Parse(await JsonAsync(HttpMethod.Patch,
        "https://www.googleapis.com/drive/v3/files/" + Uri.EscapeDataString(id) + "?fields=" + Uri.EscapeDataString(Fields), new { modifiedTime = modified.ToUniversalTime().ToString("O") }, ct));
    internal async Task DeleteNewCopyAsync(string id, CancellationToken ct)
    {
        using var response = await SendAsync(() => new HttpRequestMessage(HttpMethod.Delete, "https://www.googleapis.com/drive/v3/files/" + Uri.EscapeDataString(id)), ct);
    }
}
internal sealed class GoogleUploadSink(GoogleDriveApi drive, CloudNode initial, string parentId, bool replace, CancellationToken lifetime) : ICloudUploadSink
{
    private string session = "";
    private bool committed;
    public CloudNode? Send(byte[] buffer, int count, long offset, long? total, string? finalMd5)
    {
        using var limit = CancellationTokenSource.CreateLinkedTokenSource(lifetime); limit.CancelAfter(TimeSpan.FromSeconds(60));
        var ct = limit.Token;
        if (session.Length == 0) session = drive.BeginExplorerSessionAsync(initial, parentId, replace, total, ct).GetAwaiter().GetResult();
        long position = offset, end = checked(offset + count); int retries = 0;
        for (;;)
        {
            HttpResponseMessage response;
            try { response = drive.ExplorerRangeAsync(session, buffer, (int)(position - offset), (int)(end - position), position, total, ct).GetAwaiter().GetResult(); }
            catch (Exception ex) when (Transient(ex, ct))
            {
                if (++retries > 4) throw new IOException("Explorer upload connection failed. Copy the original file again.", ex);
                try { response = drive.ExplorerQueryAsync(session, total, ct).GetAwaiter().GetResult(); }
                catch (DriveException missing) when (finalMd5 != null && total.HasValue && (missing.Status == 404 || missing.Status == 410))
                { return Verify(drive.GetAsync(initial.Id, ct).GetAwaiter().GetResult(), total.Value, finalMd5); }
            }
            using (response)
            {
                if ((int)response.StatusCode != 308)
                {
                    if (!total.HasValue || finalMd5 == null) throw new IOException("Google completed an Explorer upload before its final byte range.");
                    using var json = JsonDocument.Parse(response.Content.ReadAsStringAsync(ct).GetAwaiter().GetResult());
                    return Verify(DriveFile.Parse(json.RootElement), total.Value, finalMd5);
                }
                long acknowledged = GoogleDriveApi.Acknowledged(response, end == 0 ? 1 : end);
                if (acknowledged < offset || acknowledged > end) throw new IOException("Google returned an upload position outside the retained RAM buffer.");
                position = acknowledged;
                if (position == end && finalMd5 == null) return null;
                if (++retries > 5) throw new IOException("Google did not confirm the completed Explorer upload.");
                // A full nonfinal block is persisted before its RAM is reused.
                // A final 308 is queried, never treated as successful completion.
                if (position == end)
                {
                    using var final = drive.ExplorerQueryAsync(session, total, ct).GetAwaiter().GetResult();
                    if ((int)final.StatusCode == 308) throw new IOException("Google received the bytes but did not confirm the completed Explorer upload.");
                    using var json = JsonDocument.Parse(final.Content.ReadAsStringAsync(ct).GetAwaiter().GetResult());
                    return Verify(DriveFile.Parse(json.RootElement), total!.Value, finalMd5);
                }
            }
        }
    }
    private CloudNode Verify(DriveFile file, long length, string? checksum)
    {
        if (file.Id == initial.Id) committed = true;
        if (file.Id != initial.Id || file.Size != length || string.IsNullOrEmpty(checksum) || !string.Equals(file.Md5, checksum, StringComparison.OrdinalIgnoreCase))
            throw new IOException("Google's Explorer upload confirmation did not match the copied file's ID, length and checksum.");
        committed = true;
        return initial with { Size = file.Size, Modified = file.Modified.UtcDateTime, Version = file.Version };
    }
    private static bool Transient(Exception ex, CancellationToken ct) => !ct.IsCancellationRequested && (ex is HttpRequestException || ex is OperationCanceledException || ex is DriveException api && (api.Status == 429 || api.Status >= 500 || api.RateLimited));
    public CloudNode SetModified(CloudNode node, DateTime modified)
    {
        using var limit = CancellationTokenSource.CreateLinkedTokenSource(lifetime); limit.CancelAfter(TimeSpan.FromSeconds(60));
        var file = drive.SetModifiedAsync(node.Id, modified, limit.Token).GetAwaiter().GetResult();
        return node with { Modified = file.Modified.UtcDateTime, Version = file.Version };
    }
    public void Abort(bool completed)
    {
        // Uncommitted resumable sessions expire at Google; no partial local file exists.
        // Cancellation may remove only a new file created by this copy, never an old replacement target.
        if (committed && !replace && !lifetime.IsCancellationRequested)
        {
            using var limit = CancellationTokenSource.CreateLinkedTokenSource(lifetime); limit.CancelAfter(TimeSpan.FromSeconds(30));
            drive.DeleteNewCopyAsync(initial.Id, limit.Token).GetAwaiter().GetResult(); committed = false;
        }
    }
}
