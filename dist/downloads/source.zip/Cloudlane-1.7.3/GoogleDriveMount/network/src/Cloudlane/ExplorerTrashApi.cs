using System;
using System.IO;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
namespace Cloudlane;
public sealed partial class GoogleDriveApi
{
    internal async Task SetTrashedAsync(string id, bool trashed, CancellationToken ct)
    {
        try
        {
            var result = await JsonAsync(HttpMethod.Patch, "https://www.googleapis.com/drive/v3/files/" + Uri.EscapeDataString(id)
                + "?fields=id,trashed&supportsAllDrives=true", new { trashed }, ct);
            if (result.GetProperty("id").GetString() != id || result.GetProperty("trashed").GetBoolean() != trashed)
                throw new IOException("Google did not confirm the requested Trash change.");
        }
        catch (DriveException ex) when (ex.Status == 403)
        { throw new UnauthorizedAccessException("Google Drive denied the Trash change. Check this Google account's ownership and file permissions.", ex); }
    }
}
