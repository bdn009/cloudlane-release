using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using System.Text.Json;
using Cloudlane.Mount;
namespace Cloudlane;
public sealed record DriveOverview(string DisplayName, string Email, CloudCapacity Capacity)
{
    public string Label => ExplorerAppearance.Label(DisplayName, Email);
    public string StorageText => Capacity.TotalBytes > 0 ? Size(Capacity.FreeBytes) + " free of " + Size(Capacity.TotalBytes) : "Google did not provide a finite storage capacity.";
    public double UsedPercent => Capacity.TotalBytes > 0 ? Math.Clamp(100d * (Capacity.TotalBytes - Capacity.FreeBytes) / Capacity.TotalBytes, 0, 100) : 0;
    private static string Size(long bytes)
    {
        double value = Math.Max(0, bytes); string[] units = { "bytes", "KB", "MB", "GB", "TB", "PB" }; int unit = 0;
        while (value >= 1024 && unit < units.Length - 1) { value /= 1024; unit++; }
        return value.ToString(unit == 0 ? "F0" : "F2") + " " + units[unit];
    }
}
public sealed partial class GoogleDriveApi
{
    public async Task<byte[]> ReadRangeAsync(DriveFile file, long offset, int count, CancellationToken ct)
        => await ReadRangeCoreAsync(file, offset, count, 1024 * 1024, ct);
    internal async Task<byte[]> ReadCacheRangeAsync(DriveFile file, long offset, int count, CancellationToken ct)
        => await ReadRangeCoreAsync(file, offset, count, MediaBlockCache.BlockSize, ct);
    private async Task<byte[]> ReadRangeCoreAsync(DriveFile file, long offset, int count, int limit, CancellationToken ct)
    {
        if (offset < 0 || count < 0 || count > limit) throw new IOException("Invalid streaming range.");
        if (offset >= file.Size || count == 0) return Array.Empty<byte>();
        int wanted = (int)Math.Min(count, file.Size - offset);
        using var response = await SendAsync(() =>
        {
            var request = new HttpRequestMessage(HttpMethod.Get, "https://www.googleapis.com/drive/v3/files/" + Uri.EscapeDataString(file.Id) + "?alt=media");
            request.Headers.Range = new RangeHeaderValue(offset, offset + wanted - 1); return request;
        }, ct);
        var range = response.Content.Headers.ContentRange;
        bool partial = response.StatusCode == HttpStatusCode.PartialContent && range?.From == offset && range.To == offset + wanted - 1 && range.Length == file.Size;
        bool boundedWhole = response.StatusCode == HttpStatusCode.OK && offset == 0 && wanted == file.Size && response.Content.Headers.ContentLength == wanted;
        if (!partial && !boundedWhole)
            throw new IOException("Google did not return the requested file range. Reopen the file after refreshing Drive.");
        byte[] bytes = new byte[wanted];
        using var stream = await response.Content.ReadAsStreamAsync(ct);
        await stream.ReadExactlyAsync(bytes, ct); return bytes;
    }
    public async Task<(long Total, long Free)> StorageAsync(CancellationToken ct)
    {
        var json = await JsonAsync(HttpMethod.Get, "https://www.googleapis.com/drive/v3/about?fields=storageQuota(limit,usage)", null, ct);
        var capacity = ParseCapacity(json.GetProperty("storageQuota"));
        return (capacity.TotalBytes, capacity.FreeBytes);
    }
    public async Task<DriveOverview> OverviewAsync(CancellationToken ct)
    {
        var json = await JsonAsync(HttpMethod.Get, "https://www.googleapis.com/drive/v3/about?fields=user(displayName,emailAddress),storageQuota(limit,usage)", null, ct);
        string name = "", email = settings.AccountEmail;
        if (json.TryGetProperty("user", out var user))
        {
            if (user.TryGetProperty("displayName", out var n)) name = n.GetString() ?? "";
            if (user.TryGetProperty("emailAddress", out var e)) email = e.GetString() ?? email;
        }
        return new(name, email, json.TryGetProperty("storageQuota", out var quota) ? ParseCapacity(quota) : new(0, 0));
    }
    internal static CloudCapacity ParseCapacity(JsonElement quota)
    {
        static bool Number(JsonElement parent, string name, out long value)
        {
            value = 0;
            if (!parent.TryGetProperty(name, out var property)) return false;
            bool valid = property.ValueKind == JsonValueKind.String ? long.TryParse(property.GetString(), out value) :
                property.ValueKind == JsonValueKind.Number && property.TryGetInt64(out value);
            if (!valid || value < 0) throw new IOException("Google returned an invalid storage quota.");
            return true;
        }
        if (!Number(quota, "limit", out long total) || !Number(quota, "usage", out long used)) return new(0, 0);
        return new(total, Math.Max(0, total - used));
    }
}
