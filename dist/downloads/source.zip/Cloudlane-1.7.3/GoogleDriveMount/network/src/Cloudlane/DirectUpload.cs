using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
namespace Cloudlane;
public sealed partial class GoogleDriveApi
{
    public const int UploadBufferSize = 4 * 1024 * 1024;
    public async Task<List<DriveFile>> ListFolderAsync(string parentId, CancellationToken ct)
    {
        string q = "trashed=false and '" + parentId.Replace("\\", "\\\\").Replace("'", "\\'") + "' in parents";
        var files = new List<DriveFile>(); string? page = null;
        do
        {
            string url = "https://www.googleapis.com/drive/v3/files?pageSize=1000&spaces=drive&q=" + Uri.EscapeDataString(q)
                + "&fields=" + Uri.EscapeDataString("nextPageToken,files(" + Fields + ")");
            if (page != null) url += "&pageToken=" + Uri.EscapeDataString(page);
            var json = await JsonAsync(HttpMethod.Get, url, null, ct);
            files.AddRange(json.GetProperty("files").EnumerateArray().Select(DriveFile.Parse));
            page = json.TryGetProperty("nextPageToken", out var next) ? next.GetString() : null;
        } while (!string.IsNullOrEmpty(page));
        return files.OrderByDescending(f => f.IsDirectory).ThenBy(f => f.Name, StringComparer.OrdinalIgnoreCase).ToList();
    }
    private async Task<string> CreateSessionAsync(UploadJob job, string parentId, long length, CancellationToken ct)
    {
        using var response = await SendAsync(() =>
        {
            var request = new HttpRequestMessage(HttpMethod.Post, "https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields=" + Uri.EscapeDataString(Fields))
            { Content = new StringContent(JsonSerializer.Serialize(new { id = job.RemoteId, name = job.Name, parents = new[] { parentId } }), Encoding.UTF8, "application/json") };
            request.Headers.Add("X-Upload-Content-Type", "application/octet-stream"); request.Headers.Add("X-Upload-Content-Length", length.ToString()); return request;
        }, ct);
        return response.Headers.Location?.AbsoluteUri ?? throw new IOException("Google did not return an upload session.");
    }
    private async Task<HttpResponseMessage> QuerySessionAsync(string session, long length, CancellationToken ct) => await SendAsync(() =>
    {
        var request = new HttpRequestMessage(HttpMethod.Put, session) { Content = new ByteArrayContent(Array.Empty<byte>()) };
        request.Content.Headers.ContentRange = new ContentRangeHeaderValue(length); return request;
    }, ct, true);
    internal static long Acknowledged(HttpResponseMessage response, long length)
    {
        if (!response.Headers.TryGetValues("Range", out var values)) return 0;
        string range = values.First();
        if (!range.StartsWith("bytes=0-", StringComparison.OrdinalIgnoreCase) || !long.TryParse(range[8..], out long end) || end < 0 || end >= length)
            throw new IOException("Google returned an invalid upload offset.");
        return checked(end + 1);
    }
    private static async Task<DriveFile> CommittedAsync(HttpResponseMessage response, UploadJob job, long length, CancellationToken ct)
    {
        using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct)); var file = DriveFile.Parse(json.RootElement);
        if (file.Id != job.RemoteId || file.Size != length) throw new IOException("Google's upload confirmation did not match this file.");
        return file;
    }
    private async Task<DriveFile?> RecoverCommittedAsync(UploadJob job, long length, CancellationToken ct)
    {
        DriveFile current;
        try { current = await GetAsync(job.RemoteId, ct); } catch (DriveException ex) when (ex.Status == 404) { return null; }
        // Only used after an interrupted/uncertain completion, not for every ordinary upload.
        if (current.Size != length || string.IsNullOrEmpty(current.Md5) || current.Md5 != await HashAsync(job.Source, ct))
            throw new IOException("The existing upload ID does not match the original file. Queue the file as a new upload.");
        return current;
    }
    public async Task<DriveFile> UploadOriginalAsync(UploadJob job, string parentId, Action persistMetadata, IProgress<UploadProgress>? progress, CancellationToken ct)
    {
        // This is the only file-content handle: it reads the user's ORIGINAL path directly.
        // No staging file, cache file, temporary content file, or MemoryStream of the whole file is created.
        using var original = new FileStream(job.Source, FileMode.Open, FileAccess.Read, FileShare.Read, 64 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan);
        long length = original.Length, ticks = File.GetLastWriteTimeUtc(job.Source).Ticks;
        bool existingId = job.RemoteId.Length > 0;
        if (job.SourceSize >= 0 && (job.SourceSize != length || job.SourceTicks != ticks))
            throw new IOException("The original file changed since this upload was queued. Remove this job and queue the file again to avoid mixing versions.");
        job.SourceSize = length; job.SourceTicks = ticks;
        if (!existingId) { job.RemoteId = await GenerateIdAsync(ct); persistMetadata(); }
        else if (job.Session.Length == 0)
        {
            var complete = await RecoverCommittedAsync(job, length, ct); if (complete != null) return complete;
        }
        long offset = 0;
        if (job.Session.Length > 0)
        {
            try
            {
                using var status = await QuerySessionAsync(job.Session, length, ct);
                if ((int)status.StatusCode != 308) return await CommittedAsync(status, job, length, ct);
                offset = Acknowledged(status, length);
            }
            catch (DriveException ex) when (ex.Status == 404 || ex.Status == 410)
            {
                job.Session = ""; persistMetadata();
                var complete = await RecoverCommittedAsync(job, length, ct); if (complete != null) return complete;
            }
        }
        if (job.Session.Length == 0)
        {
            try { job.Session = await CreateSessionAsync(job, parentId, length, ct); persistMetadata(); }
            catch (DriveException ex) when (ex.Status == 409)
            { var complete = await RecoverCommittedAsync(job, length, ct); if (complete != null) return complete; throw; }
        }
        byte[] buffer = new byte[UploadBufferSize]; int recoveries = 0;
        job.ConfirmedBytes = offset;
        while (offset < length || length == 0)
        {
            ct.ThrowIfCancellationRequested(); original.Position = offset;
            int count = (int)Math.Min(buffer.Length, length - offset), got = 0;
            while (got < count)
            { int n = await original.ReadAsync(buffer.AsMemory(got, count - got), ct); if (n == 0) throw new EndOfStreamException("The original file ended unexpectedly."); got += n; }
            progress?.Report(new(job.Name, offset, length, "Uploading directly"));
            HttpResponseMessage result;
            try
            {
                result = await SendAsync(() =>
                {
                    var request = new HttpRequestMessage(HttpMethod.Put, job.Session) { Content = new ByteArrayContent(buffer, 0, count) };
                    request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
                    request.Content.Headers.ContentRange = count == 0 ? new ContentRangeHeaderValue(0) : new ContentRangeHeaderValue(offset, offset + count - 1, length);
                    return request;
                }, ct, true, false);
            }
            catch (Exception ex) when (ex is HttpRequestException || ex is OperationCanceledException && !ct.IsCancellationRequested || ex is DriveException api && (api.RateLimited || api.Status == 429 || api.Status >= 500))
            {
                if (++recoveries > 5) throw new IOException("The upload connection is interrupted. Keep the original file and use Retry to resume.", ex);
                await Task.Delay(TimeSpan.FromSeconds(Math.Pow(2, Math.Min(recoveries - 1, 4))), ct);
                result = await QuerySessionAsync(job.Session, length, ct);
            }
            using (result)
            {
                if ((int)result.StatusCode != 308)
                {
                    var uploaded = await CommittedAsync(result, job, length, ct);
                    job.ConfirmedBytes = length; persistMetadata(); progress?.Report(new(job.Name, length, length, "Upload complete")); return uploaded;
                }
                long next = Acknowledged(result, length);
                if (next < offset || next > offset + count) throw new IOException("Google returned an unexpected upload position. The source file is unchanged.");
                if (next == offset && ++recoveries > 5) throw new IOException("Google has not confirmed upload progress. Retry with the original file available.");
                if (next > offset) recoveries = 0;
                offset = next; job.ConfirmedBytes = offset; persistMetadata();
            }
            if (offset == length) throw new IOException("Google has received the bytes but has not confirmed the completed file yet. Retry to check the final result.");
        }
        throw new IOException("The upload was not confirmed.");
    }
}
