using System;
using SMBLibrary.Authentication.NTLM;
namespace Cloudlane;
// This endpoint has its own temporary account, separate from the Windows machine's SAM.
internal sealed class CloudlaneAuthentication(string password) : IndependentNTLMAuthenticationProvider(
    user => user.Equals("Cloudlane", StringComparison.OrdinalIgnoreCase) ? password : null!)
{
    public override string GetServerName() => "CLOUDLANE";
}
