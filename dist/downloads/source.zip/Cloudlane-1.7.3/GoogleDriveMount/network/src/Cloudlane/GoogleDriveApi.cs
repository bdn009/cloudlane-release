using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
namespace Cloudlane;

public sealed record DriveFile(string Id, string Name, string MimeType, long Size, DateTimeOffset Modified, string Version, string Md5, string[] Parents, string WebLink, bool CanEdit, bool CanDownload = true)
{
    public bool IsDirectory => MimeType == "application/vnd.google-apps.folder";
    public bool IsLink => Paths.IsCloudDocument(MimeType);
    public string Kind => IsDirectory ? "Folder" : IsLink ? "Google item" : "File";
    public string SizeText => IsDirectory || IsLink ? "—" : Size < 1048576 ? $"{Size / 1024d:F1} KB" : Size < 1073741824 ? $"{Size / 1048576d:F1} MB" : $"{Size / 1073741824d:F1} GB";
    public static DriveFile Parse(JsonElement f) => new(f.GetProperty("id").GetString()!, f.GetProperty("name").GetString() ?? "Untitled",
        f.GetProperty("mimeType").GetString()!, f.TryGetProperty("size", out var size) ? long.Parse(size.GetString()!) : 0,
        f.TryGetProperty("modifiedTime", out var time) ? DateTimeOffset.Parse(time.GetString()!) : DateTimeOffset.UtcNow,
        f.TryGetProperty("version", out var version) ? version.GetString() ?? "" : "",
        f.TryGetProperty("md5Checksum", out var md5) ? md5.GetString() ?? "" : "",
        f.TryGetProperty("parents", out var parents) ? parents.EnumerateArray().Select(x => x.GetString()!).ToArray() : Array.Empty<string>(),
        f.TryGetProperty("webViewLink", out var web) ? web.GetString() ?? "" : "",
        !f.TryGetProperty("capabilities", out var cap) || !cap.TryGetProperty("canEdit", out var edit) || edit.GetBoolean(),
        !f.TryGetProperty("capabilities", out var readCap) || !readCap.TryGetProperty("canDownload", out var download) || download.GetBoolean());
}
public sealed partial class GoogleDriveApi : IDisposable
{
    private readonly Settings settings;
    private readonly HttpClient http;
    private readonly SemaphoreSlim tokenLock = new(1, 1);
    private string access = "", refresh = "";
    private DateTimeOffset expiry;
    public const string Fields = "id,name,mimeType,size,modifiedTime,version,md5Checksum,parents,webViewLink,capabilities(canEdit,canDownload)";
    public GoogleDriveApi(Settings settings, HttpMessageHandler? handler = null) : this(settings, handler, SecretStore.Read(settings.TokenPath)) { }
    internal GoogleDriveApi(Settings settings, HttpMessageHandler? handler, string tokenJson)
    {
        this.settings = settings.Snapshot(); http = handler == null ? new HttpClient() : new HttpClient(handler);
        http.Timeout = TimeSpan.FromMinutes(15);
        using var doc = JsonDocument.Parse(tokenJson);
        access = doc.RootElement.GetProperty("access_token").GetString()!;
        refresh = doc.RootElement.GetProperty("refresh_token").GetString()!;
        expiry = DateTimeOffset.Parse(doc.RootElement.GetProperty("expiry").GetString()!);
    }
    private async Task<string> TokenAsync(bool force, CancellationToken ct)
    {
        await tokenLock.WaitAsync(ct);
        try
        {
            if (!force && expiry > DateTimeOffset.UtcNow.AddMinutes(2)) return access;
            using var response = await http.PostAsync("https://oauth2.googleapis.com/token", new FormUrlEncodedContent(new Dictionary<string, string>
            { ["client_id"] = settings.ClientId, ["client_secret"] = settings.ClientSecret, ["refresh_token"] = refresh, ["grant_type"] = "refresh_token" }), ct);
            if (!response.IsSuccessStatusCode) throw new IOException("Google sign-in expired or was revoked for this account. Click Add Google account and choose the same email to sign in again. Your upload references are retained.");
            using var token = JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct));
            access = token.RootElement.GetProperty("access_token").GetString()!;
            expiry = DateTimeOffset.UtcNow.AddSeconds(token.RootElement.GetProperty("expires_in").GetInt32());
            Settings.SaveToken(settings, JsonSerializer.Serialize(new { access_token = access, refresh_token = refresh, token_type = "Bearer", expiry = expiry.ToString("O") }));
            return access;
        }
        finally { tokenLock.Release(); }
    }
    private async Task<HttpResponseMessage> SendAsync(Func<HttpRequestMessage> make, CancellationToken ct, bool allowIncomplete = false, bool retry = true)
    {
        bool force = false;
        for (int attempt = 0; ; attempt++)
        {
            using var request = make();
            if (request.RequestUri?.Scheme != "https" || (request.RequestUri.Host != "www.googleapis.com" && request.RequestUri.Host != "oauth2.googleapis.com"))
                throw new IOException("Untrusted Google API address.");
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", await TokenAsync(force, ct)); force = false;
            HttpResponseMessage response;
            try { response = await http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct); }
            catch (HttpRequestException) when (retry && attempt < 4) { await Task.Delay(TimeSpan.FromSeconds(Math.Pow(2, attempt)), ct); continue; }
            catch (OperationCanceledException) when (!ct.IsCancellationRequested && retry && attempt < 4) { await Task.Delay(TimeSpan.FromSeconds(Math.Pow(2, attempt)), ct); continue; }
            if (response.StatusCode == HttpStatusCode.Unauthorized && attempt < 2) { response.Dispose(); force = true; continue; }
            string reason = response.StatusCode == HttpStatusCode.Forbidden ? await ErrorReasonAsync(response, ct) : "";
            bool rateLimited = response.StatusCode == HttpStatusCode.Forbidden && (reason == "userRateLimitExceeded" || reason == "rateLimitExceeded");
            if (retry && (rateLimited || (int)response.StatusCode == 429 || (int)response.StatusCode >= 500) && attempt < 4)
            {
                double delay = response.Headers.RetryAfter?.Delta?.TotalSeconds ?? Math.Pow(2, attempt) + Random.Shared.NextDouble();
                response.Dispose(); await Task.Delay(TimeSpan.FromSeconds(Math.Clamp(delay, 1, 60)), ct); continue;
            }
            if (!response.IsSuccessStatusCode && !(allowIncomplete && (int)response.StatusCode == 308))
            {
                int status = (int)response.StatusCode; response.Dispose();
                string message = reason switch
                {
                    "storageQuotaExceeded" => "Your Google Drive storage is full. Free space or change your Google storage plan, then retry.",
                    "accessNotConfigured" or "serviceDisabled" => "Enable Google Drive API in the Google Cloud project that owns your Desktop client, then retry.",
                    "insufficientFilePermissions" => "This Google account cannot write to the selected folder. Choose a writable destination.",
                    "dailyLimitExceeded" => "Google's daily API limit was reached. Retry after the limit resets.",
                    "userRateLimitExceeded" or "rateLimitExceeded" => "Google is limiting requests. Wait a little, then use Start / retry.",
                    _ => status == 401 ? "Google authorization failed for this account. Click Add Google account and choose the same email to sign in again." : status == 403 ? "Google Drive refused the request. Check folder permissions, storage space and API quota." : $"Google Drive request failed (HTTP {status}). Use Start / retry when the connection is available."
                };
                throw new DriveException(status, message, rateLimited);
            }
            return response;
        }
    }
    private static async Task<string> ErrorReasonAsync(HttpResponseMessage response, CancellationToken ct)
    {
        try
        {
            using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct));
            var error = json.RootElement.GetProperty("error");
            if (error.TryGetProperty("errors", out var errors) && errors.GetArrayLength() > 0 && errors[0].TryGetProperty("reason", out var reason)) return reason.GetString() ?? "";
            if (error.TryGetProperty("status", out var status) && status.GetString() == "SERVICE_DISABLED") return "serviceDisabled";
        }
        catch (Exception ex) when (ex is JsonException || ex is KeyNotFoundException || ex is InvalidOperationException) { }
        return "";
    }
    private async Task<JsonElement> JsonAsync(HttpMethod method, string url, object? body, CancellationToken ct)
    {
        using var response = await SendAsync(() => new HttpRequestMessage(method, url) { Content = body == null ? null : new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json") }, ct);
        using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct)); return json.RootElement.Clone();
    }
    public async Task<DriveFile> GetAsync(string id, CancellationToken ct) => DriveFile.Parse(await JsonAsync(HttpMethod.Get, "https://www.googleapis.com/drive/v3/files/" + Uri.EscapeDataString(id) + "?fields=" + Uri.EscapeDataString(Fields), null, ct));
    public async Task<string> GenerateIdAsync(CancellationToken ct)
    { var json = await JsonAsync(HttpMethod.Get, "https://www.googleapis.com/drive/v3/files/generateIds?count=1&space=drive&type=files", null, ct); return json.GetProperty("ids")[0].GetString()!; }
    public async Task<DriveFile> FolderAsync(string id, string name, string parent, CancellationToken ct)
    {
        try { return DriveFile.Parse(await JsonAsync(HttpMethod.Post, "https://www.googleapis.com/drive/v3/files?fields=" + Uri.EscapeDataString(Fields), new { id, name, mimeType = "application/vnd.google-apps.folder", parents = new[] { parent } }, ct)); }
        catch (DriveException ex) when (ex.Status == 409) { return await GetAsync(id, ct); }
    }
    public void Dispose() { http.Dispose(); tokenLock.Dispose(); }
    public static async Task<string> HashAsync(string path, CancellationToken ct)
    { using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 1024 * 1024, FileOptions.Asynchronous); return Convert.ToHexString(await MD5.HashDataAsync(stream, ct)).ToLowerInvariant(); }
}
public sealed class DriveException(int status, string message, bool rateLimited = false) : IOException(message) { public int Status { get; } = status; public bool RateLimited { get; } = rateLimited; }
