using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
namespace Cloudlane;

internal sealed class MappingApprovalCancelledException : IOException
{ internal MappingApprovalCancelledException() : base("Windows administrator approval was cancelled. No drive was mounted.") { } }

internal sealed record StartupConnectionResult(string AccountId, string Letter, bool Connected, string Message);

// Exactly one startup pass; each account owns a stable settings snapshot.
internal sealed class StartupConnections
{
    private int started;
    internal async Task<IReadOnlyList<StartupConnectionResult>> RunAsync(Settings preferences,
        Func<Settings, bool> hasToken, Func<Settings, bool> connected, Func<string, bool> occupied,
        Func<Settings, CancellationToken, Task> connect, Action<StartupConnectionResult> progress,
        CancellationToken ct, TimeSpan? accountTimeout = null)
    {
        if (Interlocked.Exchange(ref started, 1) != 0) return Array.Empty<StartupConnectionResult>();
        var plan = preferences.Accounts.Where(a => a.AutoConnect).Select(preferences.ForAccount).ToArray();
        var results = new List<StartupConnectionResult>();
        foreach (var account in plan)
        {
            ct.ThrowIfCancellationRequested();
            bool stop = false;
            StartupConnectionResult result;
            using var limit = CancellationTokenSource.CreateLinkedTokenSource(ct);
            limit.CancelAfter(accountTimeout ?? TimeSpan.FromSeconds(90));
            try
            {
                if (connected(account)) result = new(account.AccountId, account.Letter, true, "Already connected");
                else if (!hasToken(account)) result = new(account.AccountId, account.Letter, false, "Sign in again to this account");
                else if (!Settings.ValidLetter(account.Letter) || occupied(account.Letter)) result = new(account.AccountId, account.Letter, false, "Drive letter is already in use or invalid; choose another letter");
                else { await connect(account, limit.Token); result = new(account.AccountId, account.Letter, true, "Connected"); }
            }
            catch (MappingApprovalCancelledException ex) { result = new(account.AccountId, account.Letter, false, ex.Message + " Remaining automatic connections stopped."); stop = true; }
            catch (OperationCanceledException) when (!ct.IsCancellationRequested) { result = new(account.AccountId, account.Letter, false, "Connection timed out; use Connect drive when ready"); }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex) { result = new(account.AccountId, account.Letter, false, ex.Message); }
            results.Add(result); progress(result);
            if (stop) break;
        }
        return results;
    }
}
