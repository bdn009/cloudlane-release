using System;
using System.Threading.Tasks;
namespace Cloudlane;

// Shared close/exit behavior: hiding never cancels work; a real exit waits for cleanup.
public sealed class DesktopLifetime
{
    private readonly Action hide;
    private readonly Func<Task> stop;
    private readonly Action finish;
    private Task? exitTask;
    public bool IsExiting { get; private set; }
    public bool CanClose { get; private set; }
    public DesktopLifetime(Action hide, Func<Task> stop, Action finish)
    { this.hide = hide; this.stop = stop; this.finish = finish; }
    public bool HideOnClose(bool closeToTray, bool trayAvailable)
    {
        if (IsExiting || CanClose || !closeToTray || !trayAvailable) return false;
        hide(); return true;
    }
    public Task ExitAsync()
    {
        if (exitTask != null) return exitTask;
        var completion = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        exitTask = completion.Task; IsExiting = true;
        _ = StopAsync(completion); return completion.Task;
    }
    private async Task StopAsync(TaskCompletionSource completion)
    {
        try
        {
            await stop(); CanClose = true; finish(); completion.SetResult();
        }
        catch (Exception ex)
        {
            CanClose = false; IsExiting = false; exitTask = null; completion.SetException(ex);
        }
    }
}
